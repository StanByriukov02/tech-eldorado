# ⚡ ОБЯЗАТЕЛЬНЫЕ МЕХАНИЗМЫ - MUST USE! ⚡

**ДЛЯ:** ВСЕХ агентов, сотрудников, департаментов  
**СТАТУС:** MANDATORY - не опциональные!  
**ПРИНЦИП:** Это ФУНДАМЕНТАЛЬНЫЕ инструменты - БЕЗ них компания НЕ работает!  
**ДАТА:** November 15, 2025

═══════════════════════════════════════════════════════════════════════════════
## 🔥 ФИЛОСОФИЯ - ПОЧЕМУ ОБЯЗАТЕЛЬНЫЕ?
═══════════════════════════════════════════════════════════════════════════════

```
ПРОБЛЕМА:
────────────────────────────────────────────────────────────────
→ Агенты используют разные языки/механизмы
→ Невозможна координация (говорят на разных "языках"!)
→ Knowledge base фрагментирована
→ Эффективность падает
→ NVIDIA/Google монополии НЕ построить так!

РЕШЕНИЕ:
────────────────────────────────────────────────────────────────
→ СТАНДАРТИЗАЦИЯ ключевых механизмов
→ Обязательные для ВСЕХ (no exceptions!)
→ Документированные + примеры
→ Интеграция между департаментами
→ Как NVIDIA: один stack для всех!

РЕЗУЛЬТАТ:
────────────────────────────────────────────────────────────────
→ Seamless coordination
→ Knowledge sharing работает
→ Efficiency ↑↑↑
→ Monopoly-grade ecosystem! 🔥
```

═══════════════════════════════════════════════════════════════════════════════
## 1️⃣ CHAIN-OF-THOUGHT / NCCL 2.28 (КРИТИЧЕСКИЙ BACKBONE!)
═══════════════════════════════════════════════════════════════════════════════

### **ЧТО ЭТО:**
```
Chain-of-Thought:
→ Пошаговое рассуждение (step-by-step reasoning!)
→ Transparency в decision-making
→ Verifiable логика

NCCL 2.28 (NVIDIA Collective Communications Library):
→ Multi-agent communication infrastructure
→ Как нейроны координируются в мозге!
→ Критично для multi-agent систем

ПОЧЕМУ ВМЕСТЕ:
→ Chain-of-Thought = ЧТО думает agent
→ NCCL = КАК agents общаются
→ ВМЕСТЕ = Multi-agent coordination! 🔥
```

### **КТО ОБЯЗАН ИСПОЛЬЗОВАТЬ:**
```
✅ ВСЕ АГЕНТЫ (100%)
✅ Agent 3.1 (NCCL Coordinator) - ОСОБЕННО!
✅ Research TEAM 0 - для multi-agent research
✅ Engineering EGER - для distributed optimization
✅ Innovation Lab - для cross-domain breakthroughs
✅ Marketing - для synchronized campaigns

NO EXCEPTIONS! Это BACKBONE компании!
```

### **КАК ИСПОЛЬЗОВАТЬ:**

#### **Chain-of-Thought Template:**
```python
# ОБЯЗАТЕЛЬНО для КАЖДОГО reasoning!
def solve_problem(problem):
    """Chain-of-Thought reasoning."""
    
    # Step 1: Problem decomposition
    print("STEP 1: Understanding problem")
    print(f"  Input: {problem}")
    print(f"  Goal: {identify_goal(problem)}")
    print(f"  Constraints: {identify_constraints(problem)}")
    
    # Step 2: Knowledge retrieval
    print("\nSTEP 2: Retrieving relevant knowledge")
    knowledge = query_knowledge_graph(problem)
    print(f"  Found: {len(knowledge)} relevant facts")
    
    # Step 3: Reasoning
    print("\nSTEP 3: Applying reasoning")
    reasoning_steps = []
    for fact in knowledge:
        step = apply_logic(fact, problem)
        reasoning_steps.append(step)
        print(f"  → {step}")
    
    # Step 4: Synthesis
    print("\nSTEP 4: Synthesizing solution")
    solution = synthesize(reasoning_steps)
    print(f"  Solution: {solution}")
    
    # Step 5: Validation
    print("\nSTEP 5: Validating solution")
    validation = validate(solution, problem)
    print(f"  Valid: {validation.is_valid}")
    print(f"  Confidence: {validation.confidence}")
    
    return solution
```

#### **NCCL Multi-Agent Communication:**
```python
# ОБЯЗАТЕЛЬНО для multi-agent coordination!
from nccl_agent_bridge import NCCLCoordinator

class Agent:
    """Base agent с NCCL communication."""
    
    def __init__(self, agent_id, nccl_coordinator):
        self.agent_id = agent_id
        self.nccl = nccl_coordinator
        
    def broadcast_finding(self, finding):
        """
        Broadcast к ВСЕМ agents.
        Как neuron firing в brain!
        """
        self.nccl.broadcast(
            sender_id=self.agent_id,
            message={
                'type': 'finding',
                'content': finding,
                'timestamp': datetime.now(),
                'priority': self.calculate_priority(finding)
            }
        )
        
    def request_expertise(self, domain):
        """
        Request expertise от specialist agent.
        Targeted communication.
        """
        specialist = self.nccl.find_specialist(domain)
        response = self.nccl.send_request(
            from_id=self.agent_id,
            to_id=specialist.agent_id,
            request={
                'domain': domain,
                'question': self.formulate_question(domain)
            }
        )
        return response
        
    def synchronize_state(self):
        """
        Sync state с всеми agents.
        Критично для consistency!
        """
        self.nccl.barrier()  # Wait for all agents
        global_state = self.nccl.all_gather(self.local_state)
        return global_state

# Agent 3.1: NCCL Coordinator (ОБЯЗАТЕЛЬНЫЙ!)
class NCCLCoordinatorAgent:
    """
    Agent 3.1 - Multi-agent communication backbone.
    БЕЗ него multi-agent system НЕ РАБОТАЕТ!
    """
    def __init__(self):
        self.agents = {}
        self.message_queue = []
        self.knowledge_graph = SharedKnowledgeGraph()
        
    def register_agent(self, agent):
        """Register agent in network."""
        self.agents[agent.agent_id] = agent
        
    def broadcast(self, sender_id, message):
        """Broadcast message от одного ко всем."""
        for agent_id, agent in self.agents.items():
            if agent_id != sender_id:
                agent.receive_message(message)
                
    def find_specialist(self, domain):
        """Find specialist agent для domain."""
        for agent in self.agents.values():
            if domain in agent.expertise:
                return agent
        return None
```

### **ГДЕ ДОКУМЕНТАЦИЯ:**
```
📄 company-foundation/KNOWLEDGE_LIBRARY/MULTI_AGENT_PATTERNS.md
   → Patterns (Supervisor, Chained, Parallel, Human-in-Loop!)
   → Examples для nano-chips
   → Chain-of-Thought integration

📄 company-foundation/PROTOCOLS/COORDINATION/WORLD_MODEL.md
   → Multi-agent knowledge sharing
   → Structured communication

📄 company-foundation/KNOWLEDGE_LIBRARY/NVIDIA_ECOSYSTEM/
   → NCCL 2.28 best practices
   → NVIDIA multi-agent patterns
```

═══════════════════════════════════════════════════════════════════════════════
## 2️⃣ JULIA LANGUAGE (ДЛЯ УЧЕНЫХ - ОБЯЗАТЕЛЬНО!)
═══════════════════════════════════════════════════════════════════════════════

### **ЧТО ЭТО:**
```
Julia Programming Language:
→ Designed для SCIENTIFIC computing
→ Fast как C, easy как Python
→ Built-in parallelization
→ Multiple dispatch (polymorphism++)
→ Type system для physics!

ПОЧЕМУ НЕ Python для science:
→ Python slow для numerical (numpy workaround!)
→ Julia NATIVE speed (JIT compilation!)
→ Python libraries call C/Fortran under hood
→ Julia НАПИСАНА для science from scratch!

ПРИМЕР SPEED:
→ Python + NumPy: 100ms
→ Julia: 5ms (20× FASTER!)
→ Critical для real-time quantum simulations!
```

### **КТО ОБЯЗАН ИСПОЛЬЗОВАТЬ:**
```
✅ TEAM 0 (Research) - ОБЯЗАТЕЛЬНО!
✅ Scientists (все!) - для simulations
✅ Quantum Physics agents - для quantum computing
✅ Thermodynamics agents - для energy calculations
✅ Bio-inspired agents - для neural simulations

ДЛЯ ИНЖЕНЕРОВ:
→ Python OK для infrastructure/tools
→ Julia для performance-critical научных алгоритмов
→ Интеграция Python ↔ Julia через PyCall/PythonCall
```

### **КАК ИСПОЛЬЗОВАТЬ:**

#### **Scientific Simulation Template:**
```julia
# Quantum coherence simulation (ОБЯЗАТЕЛЬНЫЙ пример!)
using QuantumOptics
using LinearAlgebra
using Plots

"""
Calculate quantum coherence time for graphene quantum dots.
Returns coherence in femtoseconds.
"""
function calculate_coherence_time(
    temperature::Float64,  # Kelvin
    coupling::Float64,     # eV
    detuning::Float64      # eV
)
    # Physical constants
    ℏ = 1.054571817e-34  # Planck constant (J·s)
    kB = 1.380649e-23     # Boltzmann constant (J/K)
    
    # Step 1: Thermal energy
    thermal_energy = kB * temperature / 1.602176634e-19  # Convert to eV
    println("Thermal energy: $(thermal_energy) eV")
    
    # Step 2: Decoherence rate (Fermi's Golden Rule!)
    γ = 2π * coupling^2 * thermal_energy / ℏ
    println("Decoherence rate: $(γ) Hz")
    
    # Step 3: Coherence time
    τ_coherence = 1 / γ
    println("Coherence time: $(τ_coherence * 1e15) fs")
    
    return τ_coherence * 1e15  # femtoseconds
end

# Run simulation
τ = calculate_coherence_time(
    300.0,      # Room temperature (300K)
    0.001,      # Weak coupling (1 meV)
    0.0         # Resonant
)

# Validation
@assert τ > 0 "Coherence time must be positive!"
println("✅ Quantum coherence validated: $(τ) fs")
```

#### **Multi-Threading (Julia преимущество!):**
```julia
# Parallel quantum state evolution
using Base.Threads

function evolve_quantum_states_parallel(initial_states, hamiltonian, times)
    """
    Evolve multiple quantum states in parallel.
    Julia native threading - NO GIL like Python!
    """
    n_states = length(initial_states)
    evolved_states = Vector{Any}(undef, n_states)
    
    # Parallel execution (AUTOMATIC!)
    Threads.@threads for i in 1:n_states
        evolved_states[i] = evolve_single_state(
            initial_states[i],
            hamiltonian,
            times
        )
    end
    
    return evolved_states
end

# 10× faster than Python multiprocessing!
# NO GIL overhead!
```

### **ИНТЕГРАЦИЯ Python ↔ Julia:**
```python
# Python calling Julia (best of both worlds!)
from julia import Main

# Load Julia code
Main.include("quantum_simulation.jl")

# Call Julia function from Python
coherence_time = Main.calculate_coherence_time(300.0, 0.001, 0.0)
print(f"Coherence time: {coherence_time} fs")

# Julia gets speed, Python gets ecosystem!
```

### **ГДЕ ДОКУМЕНТАЦИЯ:**
```
📄 ОБЯЗАТЕЛЬНО изучить:
   → https://docs.julialang.org/en/v1/
   → https://julialang.org/learning/

📄 Quantum computing в Julia:
   → QuantumOptics.jl
   → Yao.jl (quantum circuits!)

📄 Performance tips:
   → Type stability (критично!)
   → @inbounds для loops
   → Broadcasting (@. operator)
```

═══════════════════════════════════════════════════════════════════════════════
## 3️⃣ ЯЗЫКИ ПРОГРАММИРОВАНИЯ (ПО ДЕПАРТАМЕНТАМ)
═══════════════════════════════════════════════════════════════════════════════

### **СТАНДАРТИЗАЦИЯ:**
```
ПРИНЦИП:
────────────────────────────────────────────────────────────────
→ Каждый департамент = primary language
→ Interop через APIs/protocols
→ Shared knowledge graph (language-agnostic!)
→ Специализация > универсальность

КАК NVIDIA:
────────────────────────────────────────────────────────────────
→ CUDA (hardware): C/C++
→ Deep Learning: Python
→ HPC: C++/Fortran
→ Orchestration: Python
→ КАЖДЫЙ для своей задачи! Не один язык для всего!
```

### **ОБЯЗАТЕЛЬНЫЕ ЯЗЫКИ ПО РОЛЯМ:**

#### **RESEARCH (TEAM 0):**
```
PRIMARY: Julia ⚡ (ОБЯЗАТЕЛЬНО!)
→ Scientific simulations
→ Quantum computing
→ Physics calculations
→ Neural network research

SECONDARY: Python 🐍
→ Data analysis (Pandas)
→ Visualization (Matplotlib)
→ ML experiments (PyTorch/TensorFlow)
→ API calls (requests)

TERTIARY: Wolfram Language 🔬
→ Symbolic mathematics
→ Theorem proving
→ Complex analysis
→ Research validation

ЗАПРЕЩЕНО:
❌ JavaScript для science (NO!)
❌ PHP для calculations (NO!)
❌ Ruby для numerical (NO!)
```

#### **ENGINEERING (EGER):**
```
PRIMARY: Python 🐍 (infrastructure!)
→ Backend APIs (FastAPI)
→ System orchestration
→ Database management (SQLAlchemy)
→ DevOps (automation!)

SECONDARY: C/C++ ⚙️
→ Performance-critical код
→ CUDA kernel programming
→ Hardware integration
→ Real-time systems

TERTIARY: Rust 🦀
→ Systems programming
→ Safety-critical code
→ Embedded systems
→ Concurrency

FRONTEND:
→ TypeScript + React (уже используем!)
→ NO PHP, NO jQuery (legacy!)
```

#### **INNOVATION LAB:**
```
FREEDOM! 🎨
→ Experiment с любыми языками
→ Validate новые подходы
→ НО coordination через NCCL/Chain-of-Thought!

SUGGESTIONS:
→ Zig (systems programming alternative!)
→ Mojo (Python superset для ML!)
→ Nim (Python-like syntax, C speed!)
→ Elixir (distributed systems!)

ЕСЛИ breakthrough найден:
→ Propose для standardization
→ Document benefits
→ Integration plan
→ Переход на MANDATORY если proven!
```

#### **MARKETING:**
```
PRIMARY: TypeScript/JavaScript 🌐
→ Web applications
→ Interactive demos
→ Data visualization (D3.js)
→ CMS integration

SECONDARY: Python 🐍
→ Analytics (data science!)
→ A/B testing
→ Customer insights
→ Automation

NO-CODE TOOLS: ✅
→ Webflow (landing pages!)
→ Airtable (databases!)
→ Zapier (automation!)
→ Notion (documentation!)
```

### **INTEROPERABILITY (КРИТИЧНО!):**
```
ВСЕ ЯЗЫКИ ДОЛЖНЫ:
────────────────────────────────────────────────────────────────
✅ Communicate через REST APIs (HTTP!)
✅ Share data через JSON/Protocol Buffers
✅ Access shared knowledge graph (PostgreSQL!)
✅ Use NCCL coordination protocol
✅ Implement Chain-of-Thought logging

ПРИМЕР WORKFLOW:
────────────────────────────────────────────────────────────────
1. Scientist (Julia): Run quantum simulation
2. API call (HTTP): POST /api/results
3. Knowledge graph (PostgreSQL): Store findings
4. Engineer (Python): Retrieve via API
5. Frontend (TypeScript): Visualize results

LANGUAGE-AGNOSTIC communication! 🔥
```

═══════════════════════════════════════════════════════════════════════════════
## 4️⃣ ОБЯЗАТЕЛЬНЫЕ АЛГОРИТМЫ
═══════════════════════════════════════════════════════════════════════════════

### **ELON'S ALGORITHM (ДЛЯ ВСЕХ!):**
```
5 STEPS (ОБЯЗАТЕЛЬНО перед ЛЮБОЙ работой!):
────────────────────────────────────────────────────────────────
1. Make requirements less dumb
   → Question КАЖДОЕ requirement!
   → Кто поставил? Почему?
   → УДАЛИТЬ если нет физического обоснования!

2. Delete part/process
   → Что можно УБРАТЬ полностью?
   → 10% minimum deletion target!
   → Если не удалил ничего - ты делаешь недостаточно!

3. Simplify/optimize
   → Только ПОСЛЕ deletion!
   → НЕ оптимизируй то что должно быть удалено!

4. Accelerate cycle time
   → Ускорить процесс
   → НО только ПОСЛЕ simplification!

5. Automate
   → ПОСЛЕДНИЙ шаг!
   → Автоматизация плохого процесса = катастрофа!

КРИТИЧНО:
❌ НЕ переставлять порядок!
❌ НЕ пропускать шаги!
✅ ALWAYS start с questioning requirements!
```

**ГДЕ:** `company-foundation/PROTOCOLS/OPTIMIZATION/ELON_ALGORITHM.md`

---

### **DOUBT VALIDATION (ПЕРЕД ЛЮБОЙ ТЕХНОЛОГИЕЙ!):**
```
FRAMEWORK (ОБЯЗАТЕЛЬНЫЙ!):
────────────────────────────────────────────────────────────────
1. CLAIM VERIFICATION:
   □ Кто делает claim?
   □ Какие доказательства?
   □ Peer-reviewed?
   □ Reproducible results?

2. PHYSICS CHECK:
   □ Нарушает законы физики?
   □ Thermodynamics валидна?
   □ Energy conservation OK?
   □ Scaling makes sense?

3. ECONOMIC REALITY:
   □ Cost realistic?
   □ ROI achievable?
   □ Market exists?
   □ Competition?

4. TIMELINE VALIDATION:
   □ Development time realistic?
   □ Dependencies identified?
   □ Risk mitigation?
   □ Parallel paths?

5. TIER CLASSIFICATION:
   □ S-tier: Monopoly potential?
   □ A-tier: Enables S-tier?
   □ B-tier: Incremental?
   □ C-tier: Commodity?

ТОЛЬКО S/A tier для 47-day mission!
```

**ГДЕ:** `company-foundation/PROTOCOLS/RESEARCH/DOUBT_VALIDATION.md`

---

### **CONSERVATIVE VERIFICATION (ДЛЯ ТЕСТИРОВАНИЯ!):**
```
EXPLOIT-PROOF TESTING:
────────────────────────────────────────────────────────────────
ПРИНЦИП: "Can agent game this metric?"

BAD METRICS (exploitable!):
❌ "Lines of code written" (write garbage!)
❌ "Tests passed" (write trivial tests!)
❌ "Commits made" (commit whitespace!)

GOOD METRICS (exploit-resistant!):
✅ "Customer problems solved" (real value!)
✅ "Performance improvement %" (measurable!)
✅ "Bug escape rate" (quality indicator!)

TESTING PROTOCOL:
1. Define success criteria (BEFORE coding!)
2. Write tests FIRST (TDD!)
3. Adversarial testing (try to game it!)
4. External validation (independent reviewer!)
5. Production metrics (real-world data!)
```

**ГДЕ:** `company-foundation/PROTOCOLS/ENGINEERING/CONSERVATIVE_VERIFICATION.md`

═══════════════════════════════════════════════════════════════════════════════
## 5️⃣ ОБЯЗАТЕЛЬНЫЕ ПРОТОКОЛЫ КОММУНИКАЦИИ
═══════════════════════════════════════════════════════════════════════════════

### **TWO-LEVEL COMMUNICATION (КУЛЬТУРА!):**

#### **LEVEL 1: Freedom of Voice**
```
ЧТО:
→ Любой agent может предложить идею department head
→ Прямой доступ БЕЗ иерархии
→ Быстрая оценка + feedback

КТО:
→ ВСЕ агенты → Department heads
→ Researchers → TEAM 0 lead
→ Engineers → EGER lead
→ Innovation → Innovation Lab lead
→ Marketing → Marketing lead

КАК:
→ Structured proposal (problem + solution!)
→ Evidence-based (data, не мнение!)
→ Tier classification (S/A/B/C?)
→ Response <24hr guaranteed!

ДОКУМЕНТАЦИЯ:
📄 company-foundation/PROTOCOLS/CULTURE/FREEDOM_OF_VOICE.md
```

#### **LEVEL 2: Direct CEO Communication**
```
ЧТО:
→ Agents могут писать ПРЯМО CEO (user!)
→ Для breakthrough ideas
→ Для weak signals (Jensen principle!)
→ Для unheard voices

КОГДА:
→ S-tier breakthrough discovered
→ Weak market signal detected
→ Department head не реагирует
→ Urgent strategic insight

КАК:
→ "Letter to CEO" format
→ Compressed (5-10 sentences!)
→ Smart compression = quality thinking
→ Evidence + recommendation

CEO COMMITMENT:
→ Response <24hr ALWAYS!
→ Fair evaluation guaranteed
→ No penalties for speaking up
→ Encouragement for weak signals!

ДОКУМЕНТАЦИЯ:
📄 company-foundation/PROTOCOLS/CULTURE/DIRECT_CEO_COMMUNICATION.md
```

### **WORLD MODEL (MULTI-AGENT KNOWLEDGE!):**
```
ЧТО:
→ Shared knowledge graph для всех agents
→ Structured communication protocol
→ Progressive knowledge accumulation

ОБЯЗАТЕЛЬНО для:
→ Multi-agent campaigns (>2 agents!)
→ Long-running research (>1 hour!)
→ Cross-domain coordination

STRUCTURE:
→ Facts (verified knowledge!)
→ Hypotheses (unverified ideas!)
→ Experiments (validation plans!)
→ Results (outcomes!)
→ Insights (learnings!)

ДОКУМЕНТАЦИЯ:
📄 company-foundation/PROTOCOLS/COORDINATION/WORLD_MODEL.md
```

═══════════════════════════════════════════════════════════════════════════════
## 6️⃣ GOOGLE & NVIDIA МЕХАНИЗМЫ (УКРАСТЬ!)
═══════════════════════════════════════════════════════════════════════════════

### **NVIDIA МЕХАНИЗМЫ:**

#### **NCCL 2.28 (УЖЕ ОБСУЖДАЛИ!):**
```
КРИТИЧНОСТЬ: ⚡⚡⚡ МАКСИМАЛЬНАЯ!
→ Multi-GPU communication (для нас: multi-agent!)
→ Optimized для performance
→ Production-proven (NVIDIA использует!)

НАШЕ ПРИМЕНЕНИЕ:
→ Agent 3.1 (NCCL Coordinator!)
→ Multi-agent research campaigns
→ Distributed optimization
→ Knowledge synchronization

ДОКУМЕНТАЦИЯ:
📄 company-foundation/KNOWLEDGE_LIBRARY/NVIDIA_ECOSYSTEM/NVIDIA_OPEN_RESOURCES_ANALYSIS.md
📄 company-foundation/PROTOCOLS/ENGINEERING/NVIDIA_STACK_ANALYSIS.md
```

#### **CUDA Programming (ДЛЯ ENGINEERS!):**
```
ЧТО:
→ Direct GPU kernel programming
→ Максимальная производительность
→ Hardware control

КТО:
→ Engineers working с H100
→ Performance-critical paths
→ Quantum consciousness implementation

ПРИМЕР:
→ H100 Tensor Cores для Friedland GME
→ Real-time consciousness quantification
→ Synaptic processing kernels

ДОКУМЕНТАЦИЯ:
📄 company-foundation/KNOWLEDGE_LIBRARY/NVIDIA_ECOSYSTEM/
```

---

### **GOOGLE МЕХАНИЗМЫ:**

#### **LangGraph Pattern (АДАПТИРОВАНО!):**
```
ИСТОЧНИК: Google LangChain/LangGraph
АДАПТАЦИЯ: NON-LLM agents!

PATTERNS (украли!):
→ Supervisor/Gatekeeper (Chief Scientist!)
→ Chained Reasoning (Research Pipeline!)
→ Parallel Execution (Fast Research!)
→ Human-in-Loop (Critical Decisions!)

НАШЕ УЛУЧШЕНИЕ:
→ Knowledge graphs вместо LLM memory
→ Chain-of-Thought вместо prompts
→ Julia вместо Python (для science!)
→ NCCL вместо HTTP (для coordination!)

ДОКУМЕНТАЦИЯ:
📄 company-foundation/KNOWLEDGE_LIBRARY/MULTI_AGENT_PATTERNS.md
```

#### **Structured Outputs (КРИТИЧНО!):**
```
ПРИНЦИП:
→ Agents ВСЕГДА возвращают structured data
→ JSON Schema validation
→ Type safety
→ Programmatic consumption

ПРИМЕР:
{
  "finding": {
    "domain": "quantum_coherence",
    "claim": "Graphene maintains coherence at 300K",
    "evidence": [...],
    "confidence": 0.85,
    "tier": "A",
    "next_steps": [...]
  }
}

БЕЗ structured outputs:
→ Невозможна автоматизация
→ Human interpretation required
→ Errors в parsing
→ NO multi-agent coordination!
```

═══════════════════════════════════════════════════════════════════════════════
## 7️⃣ ОБЯЗАТЕЛЬНЫЕ ПРАКТИКИ (ДЛЯ ВСЕХ!)
═══════════════════════════════════════════════════════════════════════════════

### **BEFORE STARTING ANY TASK:**
```
✅ CHECKLIST (ОБЯЗАТЕЛЬНЫЙ!):
────────────────────────────────────────────────────────────────
1. □ Прочитал CEO_CORE_PRINCIPLES?
      → "Я запрограммирован на войну!"
      → Физика > обиды
      → Delete без жалости

2. □ Проверил KNOWLEDGE_LIBRARY?
      → DiamondMine (historical insights!)
      → VaultS (S/A tier mechanisms!)
      → NVIDIA_ECOSYSTEM (best practices!)
      → ScientificCore (формулы!)

3. □ Применил Elon's Algorithm?
      → Requirements questioned?
      → Deleted unnecessary?
      → Simplified before optimizing?

4. □ Doubt Validation пройдена?
      → Physics checked?
      → Evidence validated?
      → Tier classified?

5. □ Chain-of-Thought prepared?
      → Step-by-step reasoning ready?
      → Transparency ensured?

6. □ NCCL coordination setup?
      → Other agents notified?
      → Knowledge sharing enabled?

ЕСЛИ ВСЕ ✅ → START WORK! 🔥
ЕСЛИ НЕТ → STOP! Go back to checklist!
```

### **DURING WORK:**
```
CONTINUOUS:
────────────────────────────────────────────────────────────────
→ Chain-of-Thought logging (каждый step!)
→ Knowledge graph updates (findings added!)
→ NCCL broadcasts (share progress!)
→ Conservative verification (test continuously!)

PERIODIC (каждый час!):
────────────────────────────────────────────────────────────────
→ Alignment check (still на правильном пути?)
→ Elon's Algorithm review (что можно delete?)
→ Doubt validation (assumptions still valid?)
→ Sync с другими agents (coordination!)
```

### **AFTER COMPLETING TASK:**
```
MANDATORY STEPS:
────────────────────────────────────────────────────────────────
1. □ Results validated (Conservative Verification!)
2. □ Findings documented (Knowledge Library!)
3. □ Insights shared (NCCL broadcast!)
4. □ Learnings captured (что работало? что нет?)
5. □ Next steps proposed (для продолжения!)
6. □ S/A tier potential? (если да → VaultS!)

REFLECTION (обязательно!):
────────────────────────────────────────────────────────────────
→ Что learned?
→ Что можно было delete earlier?
→ Где можно было simplify?
→ Новые patterns discovered?
→ Update protocols если needed!
```

═══════════════════════════════════════════════════════════════════════════════
## 📊 QUICK REFERENCE TABLE
═══════════════════════════════════════════════════════════════════════════════

```
МЕХАНИЗМ              | КТО         | КОГДА           | ГДЕ ДОКУМЕНТАЦИЯ
─────────────────────────────────────────────────────────────────────────────
Chain-of-Thought      | ВСЕ         | ВСЕГДА          | MULTI_AGENT_PATTERNS.md
NCCL 2.28            | ВСЕ         | Multi-agent     | NVIDIA_ECOSYSTEM/
Julia                | Scientists  | Science tasks   | (external docs)
Python               | Engineers   | Infrastructure  | (external docs)
Elon's Algorithm     | ВСЕ         | BEFORE work     | ELON_ALGORITHM.md
Doubt Validation     | ВСЕ         | New technology  | DOUBT_VALIDATION.md
Conservative Verify  | Engineers   | Testing         | CONSERVATIVE_VERIFICATION.md
Freedom of Voice     | Agents      | Ideas/proposals | FREEDOM_OF_VOICE.md
Direct CEO Comm      | Agents      | Breakthroughs   | DIRECT_CEO_COMMUNICATION.md
World Model          | Multi-agent | Coordination    | WORLD_MODEL.md
Structured Outputs   | ВСЕ         | ВСЕГДА          | (this doc!)
Knowledge Library    | ВСЕ         | BEFORE+AFTER    | KNOWLEDGE_LIBRARY/README.md
```

═══════════════════════════════════════════════════════════════════════════════
## 🎯 PRIORITY ORDER (КОГДА ВСЁ ПРИМЕНЯТЬ?)
═══════════════════════════════════════════════════════════════════════════════

```
ПЕРЕД РАБОТОЙ:
1. CEO_CORE_PRINCIPLES (mindset!)
2. KNOWLEDGE_LIBRARY check (existing knowledge!)
3. Elon's Algorithm (requirements!)
4. Doubt Validation (technology check!)

ВО ВРЕМЯ РАБОТЫ:
1. Chain-of-Thought (каждый step!)
2. Appropriate language (Julia/Python/etc!)
3. NCCL coordination (sync с agents!)
4. Conservative Verification (test continuously!)

ПОСЛЕ РАБОТЫ:
1. Results validation (качество!)
2. Knowledge Library update (документация!)
3. Insights sharing (команда learns!)
4. Reflection (continuous improvement!)

ВСЕГДА:
→ Structured outputs
→ Freedom of Voice (можно предлагать!)
→ Direct CEO (если breakthrough!)
```

═══════════════════════════════════════════════════════════════════════════════
## ⚠️ ПОСЛЕДСТВИЯ НЕСОБЛЮДЕНИЯ
═══════════════════════════════════════════════════════════════════════════════

```
ЕСЛИ НЕ ИСПОЛЬЗУЕШЬ ОБЯЗАТЕЛЬНЫЕ МЕХАНИЗМЫ:
────────────────────────────────────────────────────────────────
❌ Multi-agent coordination breaks (NO NCCL!)
❌ Knowledge fragmentation (NO sharing!)
❌ Inefficiency (reinventing wheel!)
❌ Poor decisions (NO Doubt Validation!)
❌ Waste (NO Elon's Algorithm!)
❌ Technical debt (wrong languages!)
❌ Isolation (NO communication!)

РЕЗУЛЬТАТ:
→ Компания НЕ достигает монополии
→ 47-day deadline пропускается
→ Competitive advantage теряется
→ FAILURE! ❌

ЭТО НЕ ОПЦИОНАЛЬНЫЕ SUGGESTIONS!
ЭТО ФУНДАМЕНТАЛЬНЫЕ ТРЕБОВАНИЯ! 🔥
```

═══════════════════════════════════════════════════════════════════════════════
## 📚 NAVIGATION - ГДЕ ВСЁ НАХОДИТСЯ
═══════════════════════════════════════════════════════════════════════════════

```
CORE PROTOCOLS:
📁 company-foundation/CORE_PROTOCOLS/
   → _READ_FIRST.md (порядок чтения!)
   → CEO_CORE_PRINCIPLES.md (10 принципов!)
   → MANDATORY_MECHANISMS.md (этот документ!)

PROTOCOLS:
📁 company-foundation/PROTOCOLS/
   ├── RESEARCH/ (ALPHAEVOLVE, DOUBT_VALIDATION)
   ├── ENGINEERING/ (CONSERVATIVE_VERIFICATION, NVIDIA_STACK)
   ├── OPTIMIZATION/ (ELON_ALGORITHM)
   ├── COORDINATION/ (WORLD_MODEL)
   └── CULTURE/ (FREEDOM_OF_VOICE, DIRECT_CEO_COMMUNICATION)

KNOWLEDGE LIBRARY:
📁 company-foundation/KNOWLEDGE_LIBRARY/
   ├── DiamondMine/ (historical wisdom!)
   ├── VaultS/ (S/A tier ideas!)
   ├── NVIDIA_ECOSYSTEM/ (NCCL, CUDA!)
   ├── MULTI_AGENT_PATTERNS.md (Chain-of-Thought!)
   ├── EXTROPIC_AI_THERMODYNAMIC_COMPUTING.md
   └── README.md (navigation!)

SCIENTIFIC REFERENCE:
📁 dev/scientific-reference/
   → formulas.md
   → principles.md
   → quantum-constants.json
```

═══════════════════════════════════════════════════════════════════════════════

**ИТОГ:** Эти механизмы НЕ ОПЦИОНАЛЬНЫЕ!  
**БЕЗ них:** Компания не функционирует!  
**С ними:** NVIDIA-style monopoly! 🔥  
**ИСПОЛЬЗУЙ ВСЕГДА!** ⚡

═══════════════════════════════════════════════════════════════════════════════
