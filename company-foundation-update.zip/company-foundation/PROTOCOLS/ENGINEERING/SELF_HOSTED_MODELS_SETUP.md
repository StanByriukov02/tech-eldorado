# SELF-HOSTED MODELS SETUP GUIDE

**СТАТУС:** PRODUCTION-READY  
**ДАТА:** November 20, 2025  
**НАЗНАЧЕНИЕ:** Инструкции по запуску open-source моделей на Hetzner CX42 ($0 cost!)  
**ПРИОРИТЕТ:** TIER S++ (экономит $200+/мес!)

═══════════════════════════════════════════════════════════════════════════════

## 🎯 QUICK REFERENCE

```
МОДЕЛИ НА HETZNER CX42 (FREE):
├─ VibeThinker-1.5B (Math validation - Agent 1.3)
├─ Qwen3-235B (H100 optimization - Agent 1.2)
└─ DeepSeek-V3 (Thermodynamics - Agent 2.1)

ПЛЮС BACKUP via HuggingFace Inference API ($10-20/мес if needed)
ПЛЮС FALLBACK via OpenRouter ($0.30-0.50/M if all else fails)
```

═══════════════════════════════════════════════════════════════════════════════

## 🚀 СПОСОБ 1: SELF-HOST НА HETZNER CX42 (PRIMARY - $0!)

### STEP 1: SSH into Hetzner CX42

```bash
# Предположим, что CX42 уже заказан (есть в инфраструктуре!)
ssh root@<hetzner_ip>

# Update system
apt update && apt upgrade -y

# Install Docker (simplest approach!)
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Verify
docker --version
```

---

### STEP 2a: Install Ollama (RECOMMENDED - simpler!)

```bash
# Download Ollama installer
curl -fsSL https://ollama.ai/install.sh | sh

# Start Ollama service
systemctl start ollama
systemctl enable ollama  # Auto-start on reboot

# Verify running
curl http://localhost:11434/api/tags
```

---

### STEP 2b: Install vLLM (ALTERNATIVE - faster for batching!)

```bash
# If you prefer vLLM instead (faster batch processing!)
docker pull vllm/vllm-openai:latest

# Run vLLM with GPU support (if GPU available!)
docker run --gpus all \
  -p 8000:8000 \
  -v ~/.cache/huggingface/hub:/root/.cache/huggingface/hub \
  vllm/vllm-openai:latest \
  --model Qwen/Qwen3-235B-A22B

# Or CPU-only (slower but works!)
docker run \
  -p 8000:8000 \
  -v ~/.cache/huggingface/hub:/root/.cache/huggingface/hub \
  vllm/vllm-openai:latest \
  --model Qwen/Qwen3-235B-A22B \
  --device cpu
```

---

### STEP 3: Deploy Models via Ollama

#### **Model 1: VibeThinker-1.5B (Math Validation)**

```bash
# Pull model (one-time, ~3GB download!)
ollama pull vibethinker-1.5b

# Verify download
ollama list  # Should show vibethinker-1.5b

# Test locally
curl -X POST http://localhost:11434/api/generate \
  -d '{"model": "vibethinker-1.5b", "prompt": "What is 2+2?", "stream": false}'

# Response should come back with "4"!
```

**Integration in Python (Agent 1.3):**

```python
import requests
import json

def validate_math(formula: str) -> dict:
    """Validate math formula using local VibeThinker"""
    
    response = requests.post(
        'http://localhost:11434/api/generate',
        json={
            'model': 'vibethinker-1.5b',
            'prompt': f'Validate this formula: {formula}. Show all steps.',
            'stream': False,
            'options': {
                'temperature': 0.1,  # Low temperature for precision!
                'top_p': 0.9,
                'num_predict': 2000  # Long response for detailed reasoning
            }
        },
        timeout=300
    )
    
    return {
        'formula': formula,
        'validation': response.json()['response'],
        'model': 'vibethinker-1.5b',
        'cost': '$0'
    }

# Usage
result = validate_math("E = m*c^2")
print(f"Validation: {result['validation']}")
```

---

#### **Model 2: Qwen3-235B (CUDA Optimization)**

```bash
# Pull model (one-time, ~135GB download! Take time!)
ollama pull qwen3-235b

# This will take 30-60 minutes on first pull
# But cached after first time!

# Verify
ollama list

# Test
curl -X POST http://localhost:11434/api/generate \
  -d '{"model": "qwen3-235b", "prompt": "Design CUDA kernel for matrix multiply", "stream": false}'
```

**Integration in Python (Agent 1.2):**

```python
import requests
import json

def design_cuda_kernel(algorithm: str, constraints: dict) -> dict:
    """Design CUDA kernel using local Qwen3-235B + Sakana AI"""
    
    # Step 1: Qwen designs algorithm
    response = requests.post(
        'http://localhost:11434/api/generate',
        json={
            'model': 'qwen3-235b',
            'prompt': f'''Design optimized CUDA algorithm for:
Algorithm: {algorithm}
Constraints: {json.dumps(constraints)}

Focus on:
1. Memory access patterns
2. Thread block organization  
3. Synchronization strategy
4. Optimization opportunities

Output pseudocode only (no actual CUDA code yet!)''',
            'stream': False,
            'options': {'temperature': 0.3, 'num_predict': 1000}
        },
        timeout=600
    )
    
    algorithm_design = response.json()['response']
    
    # Step 2: Send to Sakana AI for CUDA generation
    # (Sakana API call - see SAKANA_CUDA_OPTIMIZATION.md!)
    sakana_code = generate_cuda_with_sakana(algorithm_design)
    
    return {
        'algorithm': algorithm,
        'design': algorithm_design,
        'cuda_code': sakana_code,
        'model': 'qwen3-235b (local) + Sakana (auto-CUDA)',
        'cost': '$0 (local) + $0.01-0.05 (Sakana)'
    }
```

---

#### **Model 3: DeepSeek-V3 (Thermodynamics)**

```bash
# Pull DeepSeek
ollama pull deepseek-v3

# Verify
ollama list

# Test
curl -X POST http://localhost:11434/api/generate \
  -d '{"model": "deepseek-v3", "prompt": "Calculate energy efficiency of quantum system", "stream": false}'
```

---

### STEP 4: Setup Systemd Services (Auto-restart!)

```bash
# Create systemd service for Ollama
cat > /etc/systemd/system/ollama.service << 'EOF'
[Unit]
Description=Ollama Service
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/local/bin/ollama serve
Restart=on-failure
RestartSec=10
User=root
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin"

[Install]
WantedBy=multi-user.target
EOF

# Enable and start
systemctl enable ollama
systemctl start ollama
systemctl status ollama
```

---

### STEP 5: Monitoring & Logging

```bash
# Check Ollama status
systemctl status ollama

# View logs
journalctl -u ollama -f

# Monitor memory usage
free -h
top -p $(pgrep ollama)

# Check running models
curl http://localhost:11434/api/tags | jq
```

---

## 🔄 СПОСОБ 2: HUGGINGFACE INFERENCE API (BACKUP - $0.30-0.50/M!)

### When to use:

```
PRIMARY fails (Ollama down) OR
Need extreme scale (1000+ concurrent requests)
```

### Setup:

```python
from huggingface_hub import InferenceClient

# Initialize client
client = InferenceClient(
    api_key="hf_YOUR_API_KEY_HERE",  # Get from https://huggingface.co/settings/tokens
    timeout=60
)

# VibeThinker validation
def validate_math_hf(formula: str) -> dict:
    """Fallback to HuggingFace if local Ollama down"""
    
    try:
        # Try local first (PRIMARY!)
        response = requests.post(
            'http://localhost:11434/api/generate',
            json={'model': 'vibethinker-1.5b', 'prompt': f'Validate: {formula}'},
            timeout=5
        )
        return {'source': 'local', 'result': response.json()['response']}
    
    except requests.exceptions.ConnectionError:
        # Fallback to HuggingFace (BACKUP!)
        response = client.text_generation(
            prompt=f'Validate: {formula}',
            model="WeiboAI/VibeThinker-1.5B",
            max_new_tokens=1000
        )
        return {'source': 'huggingface', 'result': response}

# Qwen via HuggingFace
def design_cuda_hf(algorithm: str) -> dict:
    """CUDA design via HuggingFace (if local Ollama down)"""
    
    response = client.text_generation(
        prompt=f'Design CUDA kernel for: {algorithm}',
        model="Qwen/Qwen3-235B-A22B",
        max_new_tokens=2000
    )
    
    return {'source': 'huggingface', 'design': response}
```

### Cost:

```
VibeThinker: ~$0.001-0.005 per validation (5-10 validations/day = ~$0.05-0.50/день)
Qwen: ~$0.0005-0.002 per request
DeepSeek: ~$0.0003-0.001 per request

TOTAL fallback: ~$10-20/мес if using 10-20% of the time
```

---

## 🛡️ СПОСОБ 3: OPENROUTER FALLBACK ($0.30-0.50/M!)

### When to use:

```
Both local AND HuggingFace down (rare!)
OR need different model capabilities
```

### Setup:

```python
import openrouter

def validate_math_openrouter(formula: str) -> dict:
    """Triple fallback via OpenRouter"""
    
    response = openrouter.ChatCompletion.create(
        model="WeiboAI/VibeThinker-1.5B",  # Available on OpenRouter!
        messages=[{
            "role": "user",
            "content": f"Validate: {formula}"
        }],
        api_key="sk_YOUR_OPENROUTER_KEY"
    )
    
    return {
        'source': 'openrouter',
        'result': response.choices[0].message.content
    }
```

---

## 🎯 ROUTING LOGIC (Intelligent Fallback!)

```python
def get_math_validation(formula: str, timeout_ms: int = 5000) -> dict:
    """
    Intelligent routing:
    PRIMARY: Local Ollama ($0)
    BACKUP: HuggingFace ($0.0005/request)
    FALLBACK: OpenRouter ($0.001/request)
    """
    
    import time
    
    # LAYER 1: Try local Ollama (PRIMARY - $0!)
    try:
        start = time.time()
        response = requests.post(
            'http://localhost:11434/api/generate',
            json={'model': 'vibethinker-1.5b', 'prompt': f'Validate: {formula}'},
            timeout=timeout_ms / 1000
        )
        elapsed_ms = (time.time() - start) * 1000
        return {
            'result': response.json()['response'],
            'source': 'local-ollama',
            'latency_ms': elapsed_ms,
            'cost': '$0'
        }
    except Exception as e:
        print(f"Local Ollama failed: {e}")
    
    # LAYER 2: Try HuggingFace (BACKUP - $0.0005!)
    try:
        from huggingface_hub import InferenceClient
        client = InferenceClient(api_key="hf_...")
        response = client.text_generation(
            prompt=f'Validate: {formula}',
            model="WeiboAI/VibeThinker-1.5B",
            max_new_tokens=1000
        )
        return {
            'result': response,
            'source': 'huggingface-api',
            'latency_ms': 'N/A',
            'cost': '$0.0005'
        }
    except Exception as e:
        print(f"HuggingFace failed: {e}")
    
    # LAYER 3: Try OpenRouter (FALLBACK - $0.001!)
    try:
        import openrouter
        response = openrouter.ChatCompletion.create(
            model="WeiboAI/VibeThinker-1.5B",
            messages=[{"role": "user", "content": f"Validate: {formula}"}],
            api_key="sk_..."
        )
        return {
            'result': response.choices[0].message.content,
            'source': 'openrouter-fallback',
            'latency_ms': 'N/A',
            'cost': '$0.001'
        }
    except Exception as e:
        print(f"OpenRouter failed: {e}")
    
    # LAYER 4: Error
    return {
        'error': 'All layers exhausted!',
        'formula': formula,
        'recommendation': 'Check internet, restart Ollama, contact support'
    }
```

---

## 📊 COST COMPARISON

```
┌─────────────────────┬────────────┬─────────────────┬──────────────┐
│ Option              │ Per Month  │ Per Validation  │ Advantages   │
├─────────────────────┼────────────┼─────────────────┼──────────────┤
│ LOCAL (Ollama)      │ $0         │ $0              │ Unlimited!   │
│ HuggingFace API     │ $10-20     │ $0.0005-0.002   │ Reliable     │
│ OpenRouter Fallback │ $20-50     │ $0.001-0.003    │ Safe         │
│ vs Claude (ONLY!)   │ $300+      │ $0.015/token    │ Single point │
└─────────────────────┴────────────┴─────────────────┴──────────────┘

SAVINGS: 95-99% vs proprietary models! 🔥
```

---

## ✅ FINAL CHECKLIST

- [ ] Hetzner CX42 provisioned (check infrastructure!)
- [ ] Ollama installed (`ollama --version`)
- [ ] Models pulled:
  - [ ] VibeThinker-1.5B (`ollama pull vibethinker-1.5b`)
  - [ ] Qwen3-235B (`ollama pull qwen3-235b`)
  - [ ] DeepSeek-V3 (`ollama pull deepseek-v3`)
- [ ] Systemd service running (`systemctl status ollama`)
- [ ] API responding (`curl http://localhost:11434/api/tags`)
- [ ] HuggingFace API key configured (backup)
- [ ] OpenRouter API key configured (fallback)
- [ ] Intelligent routing implemented (all 3 layers)
- [ ] Monitoring setup (logs, memory, status)
- [ ] Documentation updated (this file!)

---

## 🚨 TROUBLESHOOTING

### Problem: Model download too slow

```bash
# Check available disk space
df -h

# Check download progress
ls -lh ~/.ollama/models/

# Increase download timeout
OLLAMA_TIMEOUT=3600 ollama pull qwen3-235b
```

### Problem: Ollama service won't start

```bash
# Check logs
journalctl -u ollama -n 50

# Manual start with debug
ollama serve --debug

# Check if port 11434 is in use
lsof -i :11434
```

### Problem: Out of memory

```bash
# Check memory usage
free -h
top

# If Qwen3-235B too large:
# - Use vLLM with quantization
# - Or use Qwen-72B instead
# - Or use 4-bit quantized version

ollama pull qwen3-70b-q4
```

### Problem: Connection timeout

```bash
# Verify Ollama is running
ps aux | grep ollama

# Test local connection
curl -v http://localhost:11434/api/tags

# If fails: restart service
systemctl restart ollama
```

═══════════════════════════════════════════════════════════════════════════════

**INTEGRATION REFERENCES:**

- Agent 1.3 (VibeThinker): See AGENT_1.3_MATHEMATICAL_VALIDATOR.md
- Agent 1.2 (Qwen3): See SAKANA_CUDA_OPTIMIZATION.md
- Agent 2.1 (DeepSeek): See PHYSICSNEMO_VALIDATION.md
- Model Selection: See MODEL_SELECTION.md
- Infrastructure: See TECH_ELDORADO_INFRASTRUCTURE.md

═══════════════════════════════════════════════════════════════════════════════
