# COMPANY PROTOCOLS

**PURPOSE:** Active frameworks for research, engineering, optimization  
**SCOPE:** Company-wide standards and methodologies  
**STATUS:** Living documents (updated continuously!)

═══════════════════════════════════════════════════════════════════════════════
## 📁 DIRECTORY STRUCTURE
═══════════════════════════════════════════════════════════════════════════════

```
PROTOCOLS/
├── RESEARCH/              # Research methodologies
│   ├── ALPHAEVOLVE.md    # Code evolution for optimization
│   └── DOUBT_VALIDATION.md # Critical analysis framework
│
├── ENGINEERING/           # Engineering standards
│   └── CONSERVATIVE_VERIFICATION.md # Exploit-proof testing
│
├── OPTIMIZATION/          # Process optimization
│   └── ELON_ALGORITHM.md # 5-step optimization framework
│
├── COORDINATION/          # Multi-agent coordination (NEW!)
│   └── WORLD_MODEL.md    # Structured knowledge sharing
│
└── README.md             # This file
```

═══════════════════════════════════════════════════════════════════════════════
## 🎯 QUICK REFERENCE (When to Use What!)
═══════════════════════════════════════════════════════════════════════════════

### RESEARCH Protocols

**ALPHAEVOLVE** - Use when:
✅ Optimizing complex functions (agent architecture, nano-chip configurations)
✅ Need interpretable solutions (understand WHY it works)
✅ Creating self-tuning systems (hyperparameters determined automatically)
✅ Systematic exploration required (variants of known problems)

**DOUBT_VALIDATION** - Use when:
✅ Evaluating new technology (ALWAYS before integration!)
✅ Assessing scientific claims (vendor promises, paper claims)
✅ Making architecture decisions (which framework? which approach?)
✅ Strategic technology choices (what to build company on?)

---

### ENGINEERING Protocols

**CONSERVATIVE_VERIFICATION** - Use when:
✅ Designing agent metrics (prevent gaming!)
✅ Creating automated tests (exploit-proof validation)
✅ Quality assurance systems (rigorous correctness)
✅ Production deployment (mission-critical verification)

---

### OPTIMIZATION Protocols

**ELON_ALGORITHM** - Use when:
✅ Designing new processes (ANY new workflow!)
✅ System bottleneck identified (performance issues)
✅ Cost reduction needed (efficiency improvements)
✅ Before adding complexity (question if needed first!)

---

### COORDINATION Protocols

**WORLD_MODEL** - Use when:
✅ Multi-agent systems (>2 agents working together!)
✅ Long-running campaigns (>1 hour research!)
✅ Knowledge accumulation needed (progressive discovery!)
✅ Agent-to-agent communication (information sharing!)
✅ Cross-team coordination (scientists + engineers!)

═══════════════════════════════════════════════════════════════════════════════
## 🔥 PROTOCOL HIERARCHY (When Multiple Apply!)
═══════════════════════════════════════════════════════════════════════════════

**Priority Order:**

1. **DOUBT_VALIDATION** - FIRST (validate technology exists/works!)
2. **WORLD_MODEL** - SECOND (setup multi-agent coordination!)
3. **ELON_ALGORITHM** - THIRD (optimize process design!)
4. **ALPHAEVOLVE** - FOURTH (optimize specific parameters!)
5. **CONSERVATIVE_VERIFICATION** - ALWAYS (verify results!)

**Example Workflow:**
```
New optimization approach proposed
    ↓
1. DOUBT_VALIDATION (is this real? proven? tier S?)
    ↓
2. ELON_ALGORITHM (make requirements less dumb, delete unnecessary!)
    ↓
3. ALPHAEVOLVE (evolve code for optimal implementation!)
    ↓
4. CONSERVATIVE_VERIFICATION (exploit-proof testing!)
    ↓
DEPLOY!
```

═══════════════════════════════════════════════════════════════════════════════
## 👥 WHO USES WHAT
═══════════════════════════════════════════════════════════════════════════════

**Research Agents:**
- WORLD_MODEL (campaign coordination!)
- ALPHAEVOLVE (automated optimization!)
- DOUBT_VALIDATION (technology assessment!)
- CONSERVATIVE_VERIFICATION (rigorous validation!)

**Scientists:**
- WORLD_MODEL (multi-agent research!)
- DOUBT_VALIDATION (critical analysis!)
- ALPHAEVOLVE (experimental design!)
- CONSERVATIVE_VERIFICATION (result validation!)

**Engineers:**
- WORLD_MODEL (distributed optimization!)
- ELON_ALGORITHM (process optimization!)
- CONSERVATIVE_VERIFICATION (QA testing!)
- ALPHAEVOLVE (architecture search!)

**Multi-Agent Orchestrators:**
- WORLD_MODEL (coordination framework!)
- CONSERVATIVE_VERIFICATION (system validation!)

**Decision Makers:**
- DOUBT_VALIDATION (strategic choices!)
- ELON_ALGORITHM (process design!)

**ALL Team Members:**
- ELON_ALGORITHM (daily decisions!)
- DOUBT_VALIDATION (technology questions!)

═══════════════════════════════════════════════════════════════════════════════
## 🚀 GETTING STARTED
═══════════════════════════════════════════════════════════════════════════════

**New to protocols?**

1. **Read DOUBT_VALIDATION first** (foundation for critical thinking!)
2. **Read ELON_ALGORITHM second** (applies to everything!)
3. **Read CONSERVATIVE_VERIFICATION** (before any testing!)
4. **Read ALPHAEVOLVE** (when doing research/optimization!)

**First task?**

1. **Identify which protocol applies** (see "When to Use" triggers!)
2. **Read that protocol completely**
3. **Apply step-by-step** (don't skip steps!)
4. **Document results** (what worked? what didn't?)
5. **Share learnings** (update protocol if needed!)

═══════════════════════════════════════════════════════════════════════════════
## 📊 PROTOCOL TIERS
═══════════════════════════════════════════════════════════════════════════════

**S++:** Company Core (applied everywhere!)
- DOUBT_VALIDATION

**S:** Critical Frameworks (production essential!)
- ELON_ALGORITHM
- CONSERVATIVE_VERIFICATION  
- ALPHAEVOLVE

**A:** Recommended (best practices!)
- (Future protocols here!)

═══════════════════════════════════════════════════════════════════════════════
## 🔄 CONTINUOUS IMPROVEMENT
═══════════════════════════════════════════════════════════════════════════════

**Protocols are LIVING documents!**

**Update when:**
- New learnings from application
- Community discovers better methods
- Edge cases identified
- Integration patterns emerge

**Process:**
1. Identify improvement needed
2. Test new approach
3. Document results
4. Update protocol
5. Notify team

**Ownership:**
- Research protocols → Research team
- Engineering protocols → Engineering team
- Optimization protocols → Process team
- Everyone contributes!

═══════════════════════════════════════════════════════════════════════════════
## ✅ QUICK DECISION TREE
═══════════════════════════════════════════════════════════════════════════════

```
NEED TO:

Evaluate technology? → DOUBT_VALIDATION
Coordinate agents? → WORLD_MODEL
Design new process? → ELON_ALGORITHM  
Optimize function? → ALPHAEVOLVE
Test system? → CONSERVATIVE_VERIFICATION

Multiple apply? → Use priority order (see above!)
Unsure? → Start with DOUBT_VALIDATION (always safe!)
```

═══════════════════════════════════════════════════════════════════════════════

**Remember:** Protocols save time by preventing mistakes!  
**Time to read protocol << Time to fix mistake!**

**Questions?** Consult protocol owner or ask in team chat!
