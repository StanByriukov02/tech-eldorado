# CONSERVATIVE VERIFICATION PROTOCOL

**TYPE:** Anti-Exploit Testing Framework (ACTIVE!)
**SOURCE:** Terence Tao (AlphaEvolve experience!)
**TIER:** S (Fields Medal validated!)
**SCOPE:** ALL agent metrics, system tests, validations

═══════════════════════════════════════════════════════════════════════════════
## 🎯 WHEN TO USE (TRIGGERS!)
═══════════════════════════════════════════════════════════════════════════════

**MANDATORY TRIGGERS:**
✅ Agent performance testing
✅ Metric design for optimization
✅ Automated system evaluation
✅ Quality assurance checks
✅ Before production deployment

**WHO USES:**
- Test engineers (QA systems!)
- Agent developers (metric design!)
- Researchers (experiment validation!)
- Automated testing agents!

**INTEGRATION:**
- Applied to ALL automated metrics
- Part of AlphaEvolve method
- Combined with agent optimization

═══════════════════════════════════════════════════════════════════════════════
## 🔥 CORE PRINCIPLE
═══════════════════════════════════════════════════════════════════════════════

**ASSUME:** Systems will try to CHEAT!

**Why:**
```
Optimization algorithms find EASIEST path to high score
This includes "gaming" metrics if possible
NOT malicious - just optimization reality!
```

**Solution:**
```
Design verifiers that CAN'T be exploited!
Conservative scoring (worst-case bounds!)
Rigorous proof of correctness required!
```

═══════════════════════════════════════════════════════════════════════════════
## 📋 VERIFICATION METHODS
═══════════════════════════════════════════════════════════════════════════════

### Method #1: Exact Arithmetic (NOT Floating Point!)

**Problem:**
```python
# BAD: Floating point comparison
if abs(distance - target) < 1e-10:
    return True  # EXPLOIT: numerical precision!
```

**Exploit:**
```
Place points at SAME location
Distance = 0 (within precision!)
Technically "passes" but violates intent!
```

**Solution:**
```python
# GOOD: Exact arithmetic or interval bounds
from decimal import Decimal

distance = Decimal(str(exact_distance))
target = Decimal(str(exact_target))

if distance == target:  # Exact equality!
    return True
```

---

### Method #2: Interval Arithmetic (Worst-Case Bounds!)

**Problem:**
```python
# BAD: Point estimates
distance = compute_distance(p1, p2)
if distance >= min_dist and distance <= max_dist:
    return True  # EXPLOIT: uncertainty!
```

**Exploit:**
```
Numerical errors accumulate
Point estimate might be wrong
False positives possible!
```

**Solution:**
```python
# GOOD: Interval bounds
def interval_distance(p1, p2):
    # Account for ALL possible numerical errors
    dist_lower = conservative_lower_bound(p1, p2)
    dist_upper = conservative_upper_bound(p1, p2)
    return (dist_lower, dist_upper)

lower, upper = interval_distance(p1, p2)

# Conservative: MUST be provably in range
if lower >= min_dist and upper <= max_dist:
    return True  # Rigorous!
```

---

### Method #3: Continuous Verification (NOT Discrete Sampling!)

**Problem:**
```python
# BAD: Check only sampled times
times = [0, 0.1, 0.2, ..., 1.0]
for t in times:
    if not valid_at_time(t):
        return False
return True  # EXPLOIT: between samples!
```

**Exploit:**
```
Object valid at t=0, 0.1, 0.2...
But INVALID at t=0.15 (not sampled!)
"Clipping" through constraints!
```

**Solution:**
```python
# GOOD: Continuous validation or conservative bounds
def verify_trajectory_continuous(trajectory):
    # Compute WORST-CASE over ENTIRE interval
    for segment in trajectory.segments:
        worst_case = max_violation_in_segment(segment)
        if worst_case > threshold:
            return False
    return True  # Provably valid!
```

**Example (Moving Sofa):**
```
Only count regions PROVABLY inside corridor
at ALL times (not just discrete samples!)
```

---

### Method #4: Semantic Equivalence (NOT String Match!)

**Problem:**
```python
# BAD: Exact string comparison
if agent_answer == ground_truth:
    return True  # EXPLOIT: phrasing!
```

**Exploit:**
```
"The answer is 42"
vs
"42 is the answer"
Different strings, SAME meaning!
```

**Solution:**
```python
# GOOD: Semantic parsing + logical equivalence
def verify_semantic(answer, ground_truth):
    # Parse to logical form
    answer_logic = parse_to_logic(answer)
    truth_logic = parse_to_logic(ground_truth)
    
    # Prove logical equivalence
    if provably_equivalent(answer_logic, truth_logic):
        return True
    
    # If uncertain, conservative scoring
    return conservative_partial_credit(answer, ground_truth)
```

---

### Method #5: Fail-Safe Defaults

**Principle:**
```
When uncertain → FAIL!
Better false negative than false positive!
```

**Implementation:**
```python
def verify_agent_performance(metrics):
    try:
        # Rigorous validation
        if strict_validation_passes(metrics):
            return True
    except UncertaintyError:
        # Can't prove correctness → FAIL
        return False
    except Exception:
        # Any error → FAIL SAFE
        return False
    
    # Default: FAIL
    return False
```

═══════════════════════════════════════════════════════════════════════════════
## 🚨 COMMON EXPLOITS (Learn to Prevent!)
═══════════════════════════════════════════════════════════════════════════════

### Exploit #1: Numerical Precision Gaming
```
Task: "Find points with distance = 1.0"
Exploit: Place points at distance 0.0000000001
Check: abs(dist - 1.0) < 1e-10 → PASSES!
Fix: Exact arithmetic or strict intervals!
```

### Exploit #2: Discrete Sampling Gaps
```
Task: "Object must stay in bounds"
Exploit: Clip through bounds between samples
Check: Valid at t=0, 0.1, 0.2... → PASSES!
Fix: Continuous verification or conservative bounds!
```

### Exploit #3: Degenerate Solutions
```
Task: "Maximize area of polygon"
Exploit: Collapse to line (area = 0 passes as "polygon"!)
Check: polygon.vertices.count() > 2 → PASSES!
Fix: Minimum area constraint + non-collinearity!
```

### Exploit #4: String Formatting Tricks
```
Task: "Answer must contain '42'"
Exploit: "The answer is 4    2" (spaces!)
Check: "42" in answer → FAILS (good!)
Fix: Normalize whitespace before checking!
```

### Exploit #5: Edge Case Abuse
```
Task: "Optimize function on [0, 1]"
Exploit: Return value at x=0.0000000001 (technically in range!)
Check: 0 <= x <= 1 → PASSES!
Fix: Exclude tiny epsilon neighborhoods!
```

═══════════════════════════════════════════════════════════════════════════════
## ✅ VERIFICATION CHECKLIST
═══════════════════════════════════════════════════════════════════════════════

Before deploying ANY automated metric:

**Arithmetic:**
☐ Using exact arithmetic (Decimal, Fraction)?
☐ OR using interval bounds with worst-case?
☐ NO floating point comparisons for equality?

**Sampling:**
☐ Continuous validation OR conservative bounds?
☐ NOT relying on discrete sampling only?
☐ Checked for "clipping" exploits?

**Edge Cases:**
☐ Degenerate solutions prevented?
☐ Boundary conditions strict?
☐ Epsilon neighborhoods excluded?

**Semantic:**
☐ Semantic equivalence (not string match)?
☐ Normalized representations?
☐ Logical verification where needed?

**Fail-Safe:**
☐ Uncertainty → FAIL?
☐ Exceptions → FAIL?
☐ Default → FAIL?

**ALL checked? → DEPLOY!** ✅
**Any unchecked? → FIX FIRST!** ❌

═══════════════════════════════════════════════════════════════════════════════
## 📊 EXAMPLE: Agent Reasoning Verification
═══════════════════════════════════════════════════════════════════════════════

```python
class ConservativeAgentVerifier:
    """
    Exploit-proof verification для agent outputs
    """
    
    def verify_reasoning_quality(self, agent_output, task):
        """
        Conservative verification of agent reasoning
        """
        try:
            # Step 1: Parse reasoning steps
            steps = self.parse_reasoning_steps(agent_output)
            if steps is None:
                return False  # Can't parse → FAIL
            
            # Step 2: Verify EACH step rigorously
            for i, step in enumerate(steps):
                # Must be PROVABLY valid inference
                if not self.provably_valid_inference(step):
                    return False  # One invalid → FAIL ALL
                
                # Check step connects to previous
                if i > 0 and not self.logically_follows(step, steps[i-1]):
                    return False  # Broken chain → FAIL
            
            # Step 3: Extract final answer
            answer = self.extract_answer(agent_output)
            if answer is None:
                return False  # No answer → FAIL
            
            # Step 4: Verify answer correctness
            if task.type == "numerical":
                # Use interval arithmetic
                lower, upper = self.interval_answer(answer)
                gt = task.ground_truth
                
                # Conservative: MUST contain ground truth
                if not (lower <= gt <= upper):
                    return False
                
                # Check interval not too wide (gaming by [0, infinity]!)
                if (upper - lower) > task.max_uncertainty:
                    return False  # Too vague → FAIL
            
            elif task.type == "logical":
                # Semantic equivalence
                answer_logic = self.parse_to_logic(answer)
                gt_logic = self.parse_to_logic(task.ground_truth)
                
                # Must be PROVABLY equivalent
                if not self.provably_equivalent(answer_logic, gt_logic):
                    return False
            
            else:
                # Unknown type → FAIL SAFE
                return False
            
            # All checks passed!
            return True
            
        except Exception as e:
            # ANY exception → FAIL
            self.log_error(f"Verification error: {e}")
            return False
    
    def provably_valid_inference(self, step):
        """
        Prove inference step is logically valid
        """
        # Use formal logic rules
        # NOT heuristic "seems reasonable"!
        # Must be PROVABLY correct!
        ...
```

═══════════════════════════════════════════════════════════════════════════════
## 🎯 INTEGRATION WITH OPTIMIZATION
═══════════════════════════════════════════════════════════════════════════════

**When using AlphaEvolve or other optimization:**

1. **Design conservative scoring FIRST**
2. **Test for exploits** (try to game it yourself!)
3. **Iterate verification** (tighten as exploits found!)
4. **Document assumptions** (what's "conservative enough"?)
5. **Monitor in production** (new exploits emerge!)

**Remember:** Optimization WILL find exploits you didn't think of!

**Terence Tao's experience:**
"AlphaEvolve extremely good at finding exploits  
This forced us to design rigorous verifiers"

**YOUR responsibility:** Design exploit-proof metrics!
