# TECH ELDORADO ECOSYSTEM FRONTEND SPECIFICATION
**ПОЛНАЯ СПЕЦИФИКАЦИЯ ФРОНТЕНДА ДЛЯ 22-АГЕНТНОЙ ЭКОСИСТЕМЫ**

**СОЗДАНО:** November 25, 2025  
**ВЕРСИЯ:** 1.0.0  
**ЦЕЛЬ:** Полное руководство для воссоздания фронтенда в Cursor/Gemini/Claude  
**DEADLINE:** 31 декабря 2025, 23:59:59 UTC

═══════════════════════════════════════════════════════════════════════════════
## 📋 СОДЕРЖАНИЕ
═══════════════════════════════════════════════════════════════════════════════

1. [Технический стек и инфраструктура](#технический-стек)
2. [Архитектура приложения](#архитектура)
3. [22 агента — полный список](#агенты)
4. [Дизайн-система и цвета](#дизайн)
5. [Компоненты UI](#компоненты)
6. [Страницы приложения](#страницы)
7. [Real-time функциональность](#realtime)
8. [Система доступа и приватности](#доступ)
9. [Библиотека и категории](#библиотека)
10. [Репорты и прототипы](#репорты)
11. [PWA и деплой](#pwa)
12. [API эндпоинты](#api)

═══════════════════════════════════════════════════════════════════════════════
## 🛠️ ТЕХНИЧЕСКИЙ СТЕК
═══════════════════════════════════════════════════════════════════════════════

```yaml
FRONTEND:
  framework: React 18+ (Vite)
  language: TypeScript
  styling: TailwindCSS + shadcn/ui
  state: Zustand (lightweight) + TanStack Query (server state)
  routing: React Router v6
  forms: React Hook Form + Zod
  icons: Lucide React
  animations: Framer Motion
  charts: Recharts / Tremor
  realtime: Socket.io-client
  pwa: Vite PWA Plugin

BACKEND:
  runtime: Node.js 20+
  framework: Express.js / Hono
  database: PostgreSQL (Neon)
  orm: Drizzle ORM
  cache: Redis (Upstash)
  queue: BullMQ
  auth: Clerk / Auth.js
  
INFRASTRUCTURE:
  hosting: Local + Cloudflare Tunnel
  cdn: Cloudflare
  pwa: Service Worker (Workbox)
  ssl: Cloudflare (automatic)
  domain: *.eldorado.tech (или custom)
  
AI MODELS:
  primary: Gemini 2.5 Pro (Google AI Studio)
  secondary: Claude 3.7 Sonnet, Kimi K2, DeepSeek R1
  self-hosted: Qwen3-235B, DeepSeek R1 (Ollama)
  
MOBILE:
  type: PWA (Progressive Web App)
  install: Add to Home Screen
  offline: Service Worker caching
  notifications: Web Push API
```

═══════════════════════════════════════════════════════════════════════════════
## 🏗️ АРХИТЕКТУРА ПРИЛОЖЕНИЯ
═══════════════════════════════════════════════════════════════════════════════

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         TECH ELDORADO ECOSYSTEM                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │   CEO       │  │   CTO 1     │  │   CTO 2     │  │ INNOVATION  │        │
│  │  DASHBOARD  │  │  QUANTUM    │  │   ENERGY    │  │    LEAD     │        │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘        │
│         │                │                │                │                │
│         ▼                ▼                ▼                ▼                │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        AGENT WORKSPACE                               │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐       │   │
│  │  │ Agent   │ │ Agent   │ │ Agent   │ │ Agent   │ │ Agent   │  ...  │   │
│  │  │  0.1    │ │  1.1    │ │  2.1    │ │  3.1    │ │  4.1    │       │   │
│  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         SHARED RESOURCES                             │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                  │   │
│  │  │  LIBRARY    │  │  REPORTS    │  │ PROTOTYPES  │                  │   │
│  │  │ (Knowledge) │  │  (Outputs)  │  │  (Demos)    │                  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     ⏰ DEADLINE COUNTDOWN ⏰                          │   │
│  │              DAYS : HOURS : MINUTES : SECONDS                        │   │
│  │               XX  :  XX   :   XX    :   XX                           │   │
│  │                   Until December 31, 2025                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

**ДИРЕКТОРИЯ ПРОЕКТА:**

```
/eldorado-ecosystem/
├── client/                          # Frontend
│   ├── src/
│   │   ├── components/
│   │   │   ├── ui/                  # shadcn components
│   │   │   ├── agents/              # Agent cards, status
│   │   │   ├── chat/                # Chat interface
│   │   │   ├── dashboard/           # Dashboard widgets
│   │   │   ├── library/             # Knowledge library
│   │   │   ├── reports/             # Reports viewer
│   │   │   ├── countdown/           # Deadline timer
│   │   │   └── layout/              # Navigation, sidebar
│   │   ├── pages/
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Agents.tsx
│   │   │   ├── Agent/[id].tsx
│   │   │   ├── Library.tsx
│   │   │   ├── Reports.tsx
│   │   │   ├── Prototypes.tsx
│   │   │   ├── Chat.tsx
│   │   │   ├── Settings.tsx
│   │   │   └── Hackathon.tsx
│   │   ├── hooks/
│   │   │   ├── useAgents.ts
│   │   │   ├── useChat.ts
│   │   │   ├── useCountdown.ts
│   │   │   └── useLibrary.ts
│   │   ├── stores/
│   │   │   ├── agentStore.ts
│   │   │   ├── chatStore.ts
│   │   │   └── uiStore.ts
│   │   ├── lib/
│   │   │   ├── api.ts
│   │   │   ├── socket.ts
│   │   │   └── utils.ts
│   │   ├── types/
│   │   │   └── index.ts
│   │   ├── App.tsx
│   │   └── main.tsx
│   ├── public/
│   │   ├── icons/
│   │   └── manifest.json
│   └── index.html
├── server/                          # Backend
│   ├── routes/
│   ├── services/
│   ├── db/
│   └── index.ts
├── shared/                          # Shared types
│   └── schema.ts
└── package.json
```

═══════════════════════════════════════════════════════════════════════════════
## 🤖 22 АГЕНТА — ПОЛНЫЙ СПИСОК
═══════════════════════════════════════════════════════════════════════════════

```typescript
// types/agents.ts

export type AgentStatus = 'active' | 'idle' | 'blocked' | 'completed';
export type AgentPriority = 'critical' | 'high' | 'medium' | 'low';

export interface Agent {
  id: string;
  name: string;
  role: string;
  team: TeamType;
  model: AIModel;
  status: AgentStatus;
  currentTask: string | null;
  progress: number; // 0-100
  avatar: string;
  color: string;
  tools: string[];
  lastUpdate: Date;
}

export type TeamType = 'team0' | 'team1' | 'team2' | 'team3' | 'team4' | 'leadership';

export interface AIModel {
  name: string;
  provider: string;
  cost: string;
  icon: string;
}
```

### ПОЛНЫЙ СПИСОК 22 АГЕНТОВ:

```typescript
export const AGENTS: Agent[] = [
  // ═══════════════════════════════════════════════════════════════
  // LEADERSHIP (3 heads)
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'cto-1',
    name: 'CTO 1 - Quantum',
    role: 'CTO/Engineering Lead - Vacancy Hunting',
    team: 'leadership',
    model: { name: 'Claude 4 Opus', provider: 'Anthropic', cost: '$150-250', icon: '🧠' },
    avatar: '/avatars/cto1.png',
    color: '#8B5CF6', // Purple
    tools: ['Strategic Planning', 'Team Coordination', 'Physics Validation'],
  },
  {
    id: 'cto-2',
    name: 'CTO 2 - Energy',
    role: 'CTO/Engineering Lead - Partnership Technology',
    team: 'leadership',
    model: { name: 'Claude 4 Opus', provider: 'Anthropic', cost: '$150-250', icon: '🧠' },
    avatar: '/avatars/cto2.png',
    color: '#10B981', // Green
    tools: ['NVIDIA Integration', 'Partnership Strategy', 'Technical Validation'],
  },
  {
    id: 'innovation-lead',
    name: 'Innovation Lead',
    role: 'Innovation Lead - Breakthrough Development',
    team: 'leadership',
    model: { name: 'GPT-5', provider: 'OpenAI', cost: '$100-200', icon: '🚀' },
    avatar: '/avatars/innovation.png',
    color: '#F59E0B', // Orange
    tools: ['Vacancy Detection', 'Synthesis', 'Prototyping'],
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 0: RESEARCH FOUNDATION (3 agents)
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-0.1',
    name: 'Agent 0.1',
    role: 'Breakthrough Research Scientist',
    team: 'team0',
    model: { name: 'Claude 3.7 Sonnet', provider: 'Anthropic', cost: '$105', icon: '📚' },
    avatar: '/avatars/researcher.png',
    color: '#3B82F6', // Blue
    tools: ['arXiv Scanner', 'Paper Analysis', 'Insight Extraction'],
  },
  {
    id: 'agent-0.2',
    name: 'Agent 0.2',
    role: 'Applied Technology Researcher',
    team: 'team0',
    model: { name: 'Kimi K2 Thinking', provider: 'Moonshot AI', cost: '$8', icon: '🔍' },
    avatar: '/avatars/applied.png',
    color: '#6366F1', // Indigo
    tools: ['Multi-step Research', 'Pattern Detection', 'Gap Finding'],
  },
  {
    id: 'designer-0.d',
    name: 'Designer 0.D',
    role: 'Visual Designer (B2B)',
    team: 'team0',
    model: { name: 'Gemini 2.5 Pro', provider: 'Google', cost: '$0.14', icon: '🎨' },
    avatar: '/avatars/designer.png',
    color: '#EC4899', // Pink
    tools: ['Presentation Design', 'Visual Diagrams', 'Slide Layouts'],
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 1: QUANTUM CONSCIOUSNESS (4 agents)
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-1.1',
    name: 'Agent 1.1',
    role: 'Quantum Physics Specialist',
    team: 'team1',
    model: { name: 'Gemini 2.5 Pro', provider: 'Google', cost: '$20-40', icon: '⚛️' },
    avatar: '/avatars/quantum.png',
    color: '#8B5CF6', // Purple
    tools: ['Genesis', 'PhysicsNeMo', 'Newton', 'Qiskit'],
  },
  {
    id: 'agent-1.2',
    name: 'Agent 1.2',
    role: 'H100 Optimization Expert',
    team: 'team1',
    model: { name: 'Qwen3-235B', provider: 'Self-hosted', cost: 'FREE', icon: '⚡' },
    avatar: '/avatars/cuda.png',
    color: '#76B900', // NVIDIA Green
    tools: ['Sakana AI', 'CUDA-L1', 'Nsight', 'Triton'],
  },
  {
    id: 'agent-1.3',
    name: 'Agent 1.3',
    role: 'Consciousness Emergence Architect',
    team: 'team1',
    model: { name: 'Claude 4 Opus', provider: 'Anthropic', cost: '$150-250', icon: '🧬' },
    avatar: '/avatars/consciousness.png',
    color: '#7C3AED', // Violet
    tools: ['System Architecture', 'Emergence Patterns', 'Integration Strategy'],
  },
  {
    id: 'designer-1.d',
    name: 'Designer 1.D',
    role: 'Industrial Designer (Nano-chip)',
    team: 'team1',
    model: { name: 'Gemini 2.5 Pro', provider: 'Google', cost: '$10-30', icon: '🔧' },
    avatar: '/avatars/industrial.png',
    color: '#64748B', // Slate
    tools: ['Genesis 3D', 'Newton Physics', 'Blender'],
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 2: ENERGY & PARTNERSHIP (5 agents)
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-2.1',
    name: 'Agent 2.1',
    role: 'Thermodynamic Computing Specialist',
    team: 'team2',
    model: { name: 'DeepSeek R1', provider: 'Self-hosted', cost: 'FREE', icon: '🔥' },
    avatar: '/avatars/thermo.png',
    color: '#EF4444', // Red
    tools: ['ElmerFEM', 'Energy2D', 'Extropic Docs'],
  },
  {
    id: 'agent-2.2',
    name: 'Agent 2.2',
    role: 'USC Memristor Expert',
    team: 'team2',
    model: { name: 'Gemini 2.5 Pro', provider: 'Google', cost: '$15-25', icon: '💾' },
    avatar: '/avatars/memristor.png',
    color: '#06B6D4', // Cyan
    tools: ['MemTorch', 'NeuroSim', 'PyMOL'],
  },
  {
    id: 'agent-2.3',
    name: 'Agent 2.3',
    role: 'Power Architecture Engineer',
    team: 'team2',
    model: { name: 'Qwen3-235B', provider: 'Self-hosted', cost: 'FREE', icon: '⚡' },
    avatar: '/avatars/power.png',
    color: '#FBBF24', // Amber
    tools: ['PowerSensor3', 'Energy Profiler', 'RAPL'],
  },
  {
    id: 'agent-2.4',
    name: 'Agent 2.4',
    role: 'Neuromorphic Architecture Expert',
    team: 'team2',
    model: { name: 'Gemini 2.5 Pro', provider: 'Google', cost: '$15-25', icon: '🧠' },
    avatar: '/avatars/neuro.png',
    color: '#A855F7', // Fuchsia
    tools: ['Brian2', 'NEST', 'SNN Toolbox'],
  },
  {
    id: 'designer-2.d',
    name: 'Designer 2.D',
    role: 'Visual + Technical Designer',
    team: 'team2',
    model: { name: 'Gemini 2.5 Flash', provider: 'Google', cost: '$0.05', icon: '🎨' },
    avatar: '/avatars/visual.png',
    color: '#F472B6', // Pink
    tools: ['Technical Diagrams', 'Partnership Decks'],
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 3: INNOVATION LAB (4 agents)
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-3.1',
    name: 'Agent 3.1',
    role: 'Cross-Company Analyst',
    team: 'team3',
    model: { name: 'Kimi K2 Thinking', provider: 'Moonshot AI', cost: '$15', icon: '🔎' },
    avatar: '/avatars/analyst.png',
    color: '#14B8A6', // Teal
    tools: ['cuGraph', 'Company Intel', 'Gap Analysis'],
  },
  {
    id: 'agent-3.2',
    name: 'Agent 3.2',
    role: 'Innovation Synthesist',
    team: 'team3',
    model: { name: 'Claude 3.7 Sonnet', provider: 'Anthropic', cost: '$30', icon: '💡' },
    avatar: '/avatars/synthesis.png',
    color: '#F97316', // Orange
    tools: ['Combination Engine', 'A+B+C Testing', 'Synthesis'],
  },
  {
    id: 'agent-3.3',
    name: 'Agent 3.3',
    role: 'Technical Prototyper',
    team: 'team3',
    model: { name: 'Claude 3.7 Sonnet', provider: 'Anthropic', cost: '$30', icon: '🔨' },
    avatar: '/avatars/prototyper.png',
    color: '#0EA5E9', // Sky
    tools: ['Triton Server', 'Nsight', 'PoC Builder'],
  },
  {
    id: 'agent-3.4',
    name: 'Agent 3.4',
    role: 'Business Validator',
    team: 'team3',
    model: { name: 'GPT-5', provider: 'OpenAI', cost: '$10', icon: '💼' },
    avatar: '/avatars/business.png',
    color: '#22C55E', // Green
    tools: ['TAM/SAM/SOM', 'Partnership Pitch', 'Business Case'],
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 4: MARKETING & SALES (3 agents)
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-4.1',
    name: 'Agent 4.1',
    role: 'PoC Demo Creator',
    team: 'team4',
    model: { name: 'Claude 3.7 Sonnet + Veo 3.1', provider: 'Anthropic + Google', cost: '$13-23', icon: '🎬' },
    avatar: '/avatars/demo.png',
    color: '#EF4444', // Red
    tools: ['Veo 3.1', 'NVIDIA Omniverse', 'Genesis'],
  },
  {
    id: 'agent-4.2',
    name: 'Agent 4.2',
    role: 'CEO Presentation Coach',
    team: 'team4',
    model: { name: 'Gemini 2.5 Pro', provider: 'Google', cost: '$2-3', icon: '🎤' },
    avatar: '/avatars/coach.png',
    color: '#8B5CF6', // Purple
    tools: ['Demo Narration', 'Q&A Prep', 'Live Coaching'],
  },
  {
    id: 'agent-4.3',
    name: 'Agent 4.3',
    role: 'Strategic Marketing Coordinator',
    team: 'team4',
    model: { name: 'Kimi K2 Thinking', provider: 'Moonshot AI', cost: '$114-223', icon: '📊' },
    avatar: '/avatars/marketing.png',
    color: '#10B981', // Emerald
    tools: ['cuGraph', 'LinkedIn Sales Navigator', 'HubSpot'],
  },
];
```

═══════════════════════════════════════════════════════════════════════════════
## 🎨 ДИЗАЙН-СИСТЕМА И ЦВЕТА
═══════════════════════════════════════════════════════════════════════════════

### ЦВЕТОВАЯ ПАЛИТРА:

```css
/* styles/colors.css */

:root {
  /* ═══════════════════════════════════════════════════════════════
     BRAND COLORS
     ═══════════════════════════════════════════════════════════════ */
  
  /* Primary - Quantum Purple (основной) */
  --primary-50: #F5F3FF;
  --primary-100: #EDE9FE;
  --primary-200: #DDD6FE;
  --primary-300: #C4B5FD;
  --primary-400: #A78BFA;
  --primary-500: #8B5CF6;  /* MAIN */
  --primary-600: #7C3AED;
  --primary-700: #6D28D9;
  --primary-800: #5B21B6;
  --primary-900: #4C1D95;
  
  /* Secondary - NVIDIA Green */
  --nvidia-green: #76B900;
  --nvidia-dark: #1A1A1A;
  
  /* Accent - Energy Orange */
  --accent-50: #FFF7ED;
  --accent-100: #FFEDD5;
  --accent-500: #F97316;
  --accent-600: #EA580C;
  
  /* ═══════════════════════════════════════════════════════════════
     TEAM COLORS
     ═══════════════════════════════════════════════════════════════ */
  
  --team-leadership: #8B5CF6;  /* Purple */
  --team-0: #3B82F6;           /* Blue - Research */
  --team-1: #8B5CF6;           /* Purple - Quantum */
  --team-2: #10B981;           /* Green - Energy */
  --team-3: #F59E0B;           /* Orange - Innovation */
  --team-4: #EF4444;           /* Red - Marketing */
  
  /* ═══════════════════════════════════════════════════════════════
     STATUS COLORS
     ═══════════════════════════════════════════════════════════════ */
  
  --status-active: #22C55E;    /* Green - working */
  --status-idle: #6B7280;      /* Gray - waiting */
  --status-blocked: #EF4444;   /* Red - needs help */
  --status-completed: #3B82F6; /* Blue - done */
  
  /* ═══════════════════════════════════════════════════════════════
     URGENCY COLORS (based on deadline)
     ═══════════════════════════════════════════════════════════════ */
  
  --urgency-critical: #DC2626; /* 0-10 days */
  --urgency-high: #F97316;     /* 11-25 days */
  --urgency-moderate: #EAB308; /* 26-50 days */
  --urgency-normal: #22C55E;   /* 51+ days */
  
  /* ═══════════════════════════════════════════════════════════════
     BACKGROUND & SURFACE
     ═══════════════════════════════════════════════════════════════ */
  
  /* Dark Theme (PRIMARY) */
  --bg-dark: #0A0A0F;
  --bg-surface: #12121A;
  --bg-card: #1A1A25;
  --bg-hover: #252530;
  --bg-active: #2D2D3A;
  
  /* Light Theme */
  --bg-light: #FAFAFA;
  --bg-surface-light: #FFFFFF;
  --bg-card-light: #F5F5F5;
  
  /* ═══════════════════════════════════════════════════════════════
     TEXT COLORS
     ═══════════════════════════════════════════════════════════════ */
  
  --text-primary: #F9FAFB;
  --text-secondary: #9CA3AF;
  --text-muted: #6B7280;
  --text-inverse: #111827;
  
  /* ═══════════════════════════════════════════════════════════════
     BORDERS & SHADOWS
     ═══════════════════════════════════════════════════════════════ */
  
  --border-default: #27272A;
  --border-hover: #3F3F46;
  --border-active: #52525B;
  
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.5);
  --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.5);
  --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.5);
  --shadow-glow: 0 0 20px rgba(139, 92, 246, 0.3);
}
```

### ТИПОГРАФИЯ:

```css
/* styles/typography.css */

:root {
  /* Font Families */
  --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
  --font-display: 'Space Grotesk', var(--font-sans);
  
  /* Font Sizes */
  --text-xs: 0.75rem;     /* 12px */
  --text-sm: 0.875rem;    /* 14px */
  --text-base: 1rem;      /* 16px */
  --text-lg: 1.125rem;    /* 18px */
  --text-xl: 1.25rem;     /* 20px */
  --text-2xl: 1.5rem;     /* 24px */
  --text-3xl: 1.875rem;   /* 30px */
  --text-4xl: 2.25rem;    /* 36px */
  --text-5xl: 3rem;       /* 48px */
  --text-6xl: 3.75rem;    /* 60px - Countdown */
  
  /* Font Weights */
  --font-normal: 400;
  --font-medium: 500;
  --font-semibold: 600;
  --font-bold: 700;
  
  /* Line Heights */
  --leading-tight: 1.25;
  --leading-normal: 1.5;
  --leading-relaxed: 1.75;
}
```

### SPACING & LAYOUT:

```css
/* styles/spacing.css */

:root {
  /* Spacing Scale */
  --space-0: 0;
  --space-1: 0.25rem;   /* 4px */
  --space-2: 0.5rem;    /* 8px */
  --space-3: 0.75rem;   /* 12px */
  --space-4: 1rem;      /* 16px */
  --space-5: 1.25rem;   /* 20px */
  --space-6: 1.5rem;    /* 24px */
  --space-8: 2rem;      /* 32px */
  --space-10: 2.5rem;   /* 40px */
  --space-12: 3rem;     /* 48px */
  --space-16: 4rem;     /* 64px */
  --space-20: 5rem;     /* 80px */
  
  /* Border Radius */
  --radius-sm: 0.25rem;
  --radius-md: 0.5rem;
  --radius-lg: 0.75rem;
  --radius-xl: 1rem;
  --radius-2xl: 1.5rem;
  --radius-full: 9999px;
  
  /* Sidebar */
  --sidebar-width: 280px;
  --sidebar-collapsed: 72px;
  
  /* Header */
  --header-height: 64px;
  
  /* Breakpoints */
  --breakpoint-sm: 640px;
  --breakpoint-md: 768px;
  --breakpoint-lg: 1024px;
  --breakpoint-xl: 1280px;
  --breakpoint-2xl: 1536px;
}
```

═══════════════════════════════════════════════════════════════════════════════
## 🧩 КОМПОНЕНТЫ UI
═══════════════════════════════════════════════════════════════════════════════

### 1. DEADLINE COUNTDOWN (КРИТИЧЕСКИ ВАЖЕН!)

```tsx
// components/countdown/DeadlineCountdown.tsx

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

const DEADLINE = new Date('2025-12-31T23:59:59Z');

export function DeadlineCountdown() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>(calculateTimeLeft());
  const [urgencyLevel, setUrgencyLevel] = useState<'critical' | 'high' | 'moderate' | 'normal'>('moderate');

  useEffect(() => {
    const timer = setInterval(() => {
      const newTime = calculateTimeLeft();
      setTimeLeft(newTime);
      setUrgencyLevel(getUrgencyLevel(newTime.days));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  function calculateTimeLeft(): TimeLeft {
    const difference = DEADLINE.getTime() - new Date().getTime();
    
    return {
      days: Math.floor(difference / (1000 * 60 * 60 * 24)),
      hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((difference / 1000 / 60) % 60),
      seconds: Math.floor((difference / 1000) % 60),
    };
  }

  function getUrgencyLevel(days: number) {
    if (days <= 10) return 'critical';
    if (days <= 25) return 'high';
    if (days <= 50) return 'moderate';
    return 'normal';
  }

  const urgencyColors = {
    critical: 'from-red-600 to-red-800 animate-pulse',
    high: 'from-orange-500 to-orange-700',
    moderate: 'from-yellow-500 to-yellow-700',
    normal: 'from-green-500 to-green-700',
  };

  return (
    <div className={`
      relative overflow-hidden rounded-2xl p-6
      bg-gradient-to-r ${urgencyColors[urgencyLevel]}
      shadow-lg shadow-black/50
    `}>
      {/* Animated background particles */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[url('/patterns/grid.svg')] animate-pulse" />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-2xl">⏰</span>
            <span className="text-lg font-semibold text-white/90">
              DEADLINE: December 31, 2025
            </span>
          </div>
          <span className={`
            px-3 py-1 rounded-full text-sm font-bold uppercase
            ${urgencyLevel === 'critical' ? 'bg-red-900 text-red-100 animate-bounce' : ''}
            ${urgencyLevel === 'high' ? 'bg-orange-900 text-orange-100' : ''}
            ${urgencyLevel === 'moderate' ? 'bg-yellow-900 text-yellow-100' : ''}
            ${urgencyLevel === 'normal' ? 'bg-green-900 text-green-100' : ''}
          `}>
            {urgencyLevel}
          </span>
        </div>

        {/* Countdown Numbers */}
        <div className="grid grid-cols-4 gap-4" data-testid="countdown-grid">
          <CountdownUnit value={timeLeft.days} label="DAYS" urgent={urgencyLevel === 'critical'} />
          <CountdownUnit value={timeLeft.hours} label="HOURS" />
          <CountdownUnit value={timeLeft.minutes} label="MINUTES" />
          <CountdownUnit value={timeLeft.seconds} label="SECONDS" animate />
        </div>

        {/* Urgency Message */}
        <motion.p 
          className="mt-4 text-center text-white/80 text-sm font-medium"
          key={urgencyLevel}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {urgencyLevel === 'critical' && '🔥 CRITICAL! Every hour counts! Partnership letter deadline IMMINENT!'}
          {urgencyLevel === 'high' && '⚡ HIGH URGENCY! Focus on critical path tasks only!'}
          {urgencyLevel === 'moderate' && '📍 Stay focused! Partnership demo is the North Star!'}
          {urgencyLevel === 'normal' && '✅ Good pace! Keep momentum toward Dec 31!'}
        </motion.p>
      </div>
    </div>
  );
}

function CountdownUnit({ 
  value, 
  label, 
  urgent = false,
  animate = false 
}: { 
  value: number; 
  label: string;
  urgent?: boolean;
  animate?: boolean;
}) {
  return (
    <div className={`
      flex flex-col items-center justify-center
      bg-black/30 backdrop-blur-sm rounded-xl p-4
      ${urgent ? 'ring-2 ring-red-400 animate-pulse' : ''}
    `}>
      <AnimatePresence mode="popLayout">
        <motion.span
          key={value}
          initial={animate ? { opacity: 0, y: -20 } : {}}
          animate={{ opacity: 1, y: 0 }}
          exit={animate ? { opacity: 0, y: 20 } : {}}
          className="text-4xl md:text-5xl lg:text-6xl font-bold text-white font-display"
          data-testid={`countdown-${label.toLowerCase()}`}
        >
          {String(value).padStart(2, '0')}
        </motion.span>
      </AnimatePresence>
      <span className="text-xs md:text-sm text-white/70 font-medium mt-1">
        {label}
      </span>
    </div>
  );
}
```

### 2. AGENT CARD

```tsx
// components/agents/AgentCard.tsx

import { motion } from 'framer-motion';
import { Activity, Pause, AlertCircle, CheckCircle2 } from 'lucide-react';
import type { Agent } from '@/types';

interface AgentCardProps {
  agent: Agent;
  onClick?: () => void;
}

export function AgentCard({ agent, onClick }: AgentCardProps) {
  const statusIcons = {
    active: <Activity className="w-4 h-4 text-green-400 animate-pulse" />,
    idle: <Pause className="w-4 h-4 text-gray-400" />,
    blocked: <AlertCircle className="w-4 h-4 text-red-400 animate-bounce" />,
    completed: <CheckCircle2 className="w-4 h-4 text-blue-400" />,
  };

  const statusColors = {
    active: 'border-green-500/50 bg-green-500/5',
    idle: 'border-gray-500/50 bg-gray-500/5',
    blocked: 'border-red-500/50 bg-red-500/5',
    completed: 'border-blue-500/50 bg-blue-500/5',
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`
        relative overflow-hidden rounded-xl p-4 cursor-pointer
        bg-card border-2 transition-all duration-200
        ${statusColors[agent.status]}
        hover:shadow-lg hover:shadow-black/30
      `}
      data-testid={`agent-card-${agent.id}`}
    >
      {/* Color accent bar */}
      <div 
        className="absolute top-0 left-0 right-0 h-1"
        style={{ backgroundColor: agent.color }}
      />

      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          {/* Avatar */}
          <div 
            className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
            style={{ backgroundColor: `${agent.color}20` }}
          >
            {agent.model.icon}
          </div>
          
          {/* Name & Role */}
          <div>
            <h3 className="font-semibold text-white">{agent.name}</h3>
            <p className="text-sm text-gray-400 line-clamp-1">{agent.role}</p>
          </div>
        </div>

        {/* Status */}
        <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-black/30">
          {statusIcons[agent.status]}
          <span className="text-xs capitalize text-gray-300">{agent.status}</span>
        </div>
      </div>

      {/* Current Task */}
      {agent.currentTask && (
        <div className="mb-3 p-2 rounded-lg bg-black/20">
          <p className="text-xs text-gray-400 mb-1">Current Task:</p>
          <p className="text-sm text-gray-200 line-clamp-2">{agent.currentTask}</p>
        </div>
      )}

      {/* Progress Bar */}
      <div className="mb-3">
        <div className="flex justify-between text-xs text-gray-400 mb-1">
          <span>Progress</span>
          <span>{agent.progress}%</span>
        </div>
        <div className="h-2 bg-black/30 rounded-full overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{ backgroundColor: agent.color }}
            initial={{ width: 0 }}
            animate={{ width: `${agent.progress}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {/* Model & Tools */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
            {agent.model.name}
          </span>
          <span className="text-xs text-gray-500">{agent.model.cost}</span>
        </div>
        <div className="flex -space-x-1">
          {agent.tools.slice(0, 3).map((tool, i) => (
            <div
              key={tool}
              className="w-6 h-6 rounded-full bg-gray-700 border-2 border-card flex items-center justify-center"
              title={tool}
            >
              <span className="text-xs">🔧</span>
            </div>
          ))}
          {agent.tools.length > 3 && (
            <div className="w-6 h-6 rounded-full bg-gray-700 border-2 border-card flex items-center justify-center">
              <span className="text-xs text-gray-400">+{agent.tools.length - 3}</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
```

### 3. TEAM SECTION

```tsx
// components/agents/TeamSection.tsx

import { motion } from 'framer-motion';
import { ChevronDown, Play, Pause, Users } from 'lucide-react';
import { AgentCard } from './AgentCard';
import type { Agent, TeamType } from '@/types';

interface TeamSectionProps {
  team: TeamType;
  agents: Agent[];
  isExpanded: boolean;
  onToggle: () => void;
  onLaunchTeam: () => void;
  onLaunchAgent: (agentId: string) => void;
}

const TEAM_INFO = {
  leadership: { name: 'Leadership', icon: '👑', color: '#8B5CF6' },
  team0: { name: 'Team 0: Research Foundation', icon: '📚', color: '#3B82F6' },
  team1: { name: 'Team 1: Quantum Consciousness', icon: '⚛️', color: '#8B5CF6' },
  team2: { name: 'Team 2: Energy & Partnership', icon: '⚡', color: '#10B981' },
  team3: { name: 'Team 3: Innovation Lab', icon: '💡', color: '#F59E0B' },
  team4: { name: 'Team 4: Marketing & Sales', icon: '📊', color: '#EF4444' },
};

export function TeamSection({ 
  team, 
  agents, 
  isExpanded, 
  onToggle,
  onLaunchTeam,
  onLaunchAgent 
}: TeamSectionProps) {
  const info = TEAM_INFO[team];
  const activeCount = agents.filter(a => a.status === 'active').length;

  return (
    <div className="mb-6" data-testid={`team-section-${team}`}>
      {/* Team Header */}
      <motion.div
        className={`
          flex items-center justify-between p-4 rounded-xl cursor-pointer
          bg-card border border-border hover:border-gray-600 transition-colors
        `}
        onClick={onToggle}
        whileHover={{ backgroundColor: 'rgba(255,255,255,0.03)' }}
      >
        <div className="flex items-center gap-3">
          <div 
            className="w-10 h-10 rounded-lg flex items-center justify-center text-xl"
            style={{ backgroundColor: `${info.color}20` }}
          >
            {info.icon}
          </div>
          <div>
            <h2 className="font-semibold text-white">{info.name}</h2>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <Users className="w-4 h-4" />
              <span>{agents.length} agents</span>
              <span className="text-green-400">• {activeCount} active</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Launch Team Button */}
          <button
            onClick={(e) => { e.stopPropagation(); onLaunchTeam(); }}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-lg
              bg-gradient-to-r from-purple-600 to-purple-700
              hover:from-purple-500 hover:to-purple-600
              text-white text-sm font-medium
              transition-all duration-200
            `}
            data-testid={`launch-team-${team}`}
          >
            <Play className="w-4 h-4" />
            Launch Team
          </button>

          {/* Expand/Collapse */}
          <motion.div
            animate={{ rotate: isExpanded ? 180 : 0 }}
            transition={{ duration: 0.2 }}
          >
            <ChevronDown className="w-5 h-5 text-gray-400" />
          </motion.div>
        </div>
      </motion.div>

      {/* Agents Grid */}
      <motion.div
        initial={false}
        animate={{
          height: isExpanded ? 'auto' : 0,
          opacity: isExpanded ? 1 : 0,
        }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
          {agents.map((agent) => (
            <AgentCard 
              key={agent.id} 
              agent={agent}
              onClick={() => onLaunchAgent(agent.id)}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}
```

### 4. CHAT INTERFACE

```tsx
// components/chat/ChatInterface.tsx

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Paperclip, Mic, Bot, User, Lock } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'agent' | 'system';
  content: string;
  timestamp: Date;
  agentId?: string;
  isPrivate?: boolean;
}

interface ChatInterfaceProps {
  agentId?: string;
  agentName?: string;
  isPrivate?: boolean;
  messages: Message[];
  onSendMessage: (content: string) => void;
  isLoading?: boolean;
}

export function ChatInterface({
  agentId,
  agentName = 'Agent',
  isPrivate = false,
  messages,
  onSendMessage,
  isLoading = false,
}: ChatInterfaceProps) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    onSendMessage(input.trim());
    setInput('');
  };

  return (
    <div className="flex flex-col h-full bg-surface rounded-xl border border-border overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-card">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
            <Bot className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="font-semibold text-white">{agentName}</h3>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              {isPrivate && (
                <span className="flex items-center gap-1 text-yellow-400">
                  <Lock className="w-3 h-3" />
                  Private Chat
                </span>
              )}
              <span className="text-green-400">● Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4" data-testid="chat-messages">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`
                max-w-[80%] rounded-2xl px-4 py-3
                ${message.role === 'user' 
                  ? 'bg-purple-600 text-white rounded-br-md' 
                  : 'bg-card text-gray-200 rounded-bl-md border border-border'
                }
              `}>
                {message.role !== 'user' && (
                  <div className="flex items-center gap-2 mb-1">
                    <Bot className="w-4 h-4 text-purple-400" />
                    <span className="text-xs text-purple-400">{agentName}</span>
                  </div>
                )}
                <p className="whitespace-pre-wrap">{message.content}</p>
                <span className="text-xs opacity-50 mt-1 block">
                  {message.timestamp.toLocaleTimeString()}
                </span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-start"
          >
            <div className="bg-card rounded-2xl rounded-bl-md px-4 py-3 border border-border">
              <div className="flex items-center gap-2">
                <Bot className="w-4 h-4 text-purple-400" />
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" />
                  <span className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-100" />
                  <span className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-200" />
                </div>
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-border bg-card">
        <div className="flex items-end gap-2">
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
              placeholder={`Message ${agentName}...`}
              className="w-full px-4 py-3 bg-surface border border-border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-white placeholder-gray-500"
              rows={1}
              data-testid="chat-input"
            />
          </div>
          
          <div className="flex gap-2">
            <button
              type="button"
              className="p-3 rounded-xl bg-surface border border-border text-gray-400 hover:text-white hover:bg-hover transition-colors"
              data-testid="chat-attach"
            >
              <Paperclip className="w-5 h-5" />
            </button>
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="p-3 rounded-xl bg-purple-600 text-white hover:bg-purple-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              data-testid="chat-send"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
```

### 5. SIDEBAR NAVIGATION

```tsx
// components/layout/Sidebar.tsx

import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Users,
  Library,
  FileText,
  Box,
  MessageSquare,
  Settings,
  Zap,
  ChevronLeft,
  Rocket,
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

const NAV_ITEMS = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/agents', icon: Users, label: 'Agents' },
  { path: '/library', icon: Library, label: 'Library' },
  { path: '/reports', icon: FileText, label: 'Reports' },
  { path: '/prototypes', icon: Box, label: 'Prototypes' },
  { path: '/chat', icon: MessageSquare, label: 'Chat' },
  { path: '/hackathon', icon: Rocket, label: 'Hackathon', highlight: true },
  { path: '/settings', icon: Settings, label: 'Settings' },
];

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const location = useLocation();

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 72 : 280 }}
      className="fixed left-0 top-0 h-screen bg-card border-r border-border z-50 flex flex-col"
    >
      {/* Logo */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center">
            <Zap className="w-6 h-6 text-white" />
          </div>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="font-bold text-lg text-white font-display"
            >
              ELDORADO
            </motion.span>
          )}
        </Link>
        
        <button
          onClick={onToggle}
          className="p-2 rounded-lg hover:bg-hover transition-colors"
          data-testid="sidebar-toggle"
        >
          <motion.div animate={{ rotate: collapsed ? 180 : 0 }}>
            <ChevronLeft className="w-5 h-5 text-gray-400" />
          </motion.div>
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`
                flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200
                ${isActive 
                  ? 'bg-purple-600 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-hover'
                }
                ${item.highlight && !isActive ? 'bg-orange-500/10 text-orange-400 hover:bg-orange-500/20' : ''}
              `}
              data-testid={`nav-${item.path.replace('/', '') || 'dashboard'}`}
            >
              <Icon className={`w-5 h-5 ${item.highlight && !isActive ? 'text-orange-400' : ''}`} />
              {!collapsed && (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="font-medium"
                >
                  {item.label}
                </motion.span>
              )}
              {item.highlight && !collapsed && (
                <span className="ml-auto text-xs px-2 py-0.5 rounded-full bg-orange-500 text-white">
                  NEW
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* GPU Status */}
      <div className="p-4 border-t border-border">
        <div className={`
          flex items-center gap-3 p-3 rounded-xl bg-surface
          ${collapsed ? 'justify-center' : ''}
        `}>
          <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
          {!collapsed && (
            <div>
              <p className="text-sm font-medium text-white">GPU Active</p>
              <p className="text-xs text-gray-400">All tools available</p>
            </div>
          )}
        </div>
      </div>
    </motion.aside>
  );
}
```

═══════════════════════════════════════════════════════════════════════════════
## 📄 СТРАНИЦЫ ПРИЛОЖЕНИЯ
═══════════════════════════════════════════════════════════════════════════════

### PAGE 1: DASHBOARD

```tsx
// pages/Dashboard.tsx

import { DeadlineCountdown } from '@/components/countdown/DeadlineCountdown';
import { TeamOverview } from '@/components/dashboard/TeamOverview';
import { RecentReports } from '@/components/dashboard/RecentReports';
import { ActiveAgents } from '@/components/dashboard/ActiveAgents';
import { QuickActions } from '@/components/dashboard/QuickActions';

export function Dashboard() {
  return (
    <div className="p-6 space-y-6" data-testid="page-dashboard">
      {/* Deadline Countdown - ALWAYS VISIBLE! */}
      <DeadlineCountdown />

      {/* Quick Actions */}
      <QuickActions />

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Agents - 2 columns */}
        <div className="lg:col-span-2">
          <ActiveAgents />
        </div>

        {/* Recent Reports */}
        <div>
          <RecentReports />
        </div>
      </div>

      {/* Team Overview */}
      <TeamOverview />
    </div>
  );
}
```

### PAGE 2: AGENTS

```tsx
// pages/Agents.tsx

import { useState } from 'react';
import { TeamSection } from '@/components/agents/TeamSection';
import { AgentFilters } from '@/components/agents/AgentFilters';
import { LaunchAllButton } from '@/components/agents/LaunchAllButton';
import { useAgents } from '@/hooks/useAgents';

export function Agents() {
  const { agents, launchAgent, launchTeam, launchAll } = useAgents();
  const [expandedTeams, setExpandedTeams] = useState<string[]>(['leadership']);
  const [filter, setFilter] = useState<'all' | 'active' | 'idle' | 'blocked'>('all');

  const teams = ['leadership', 'team0', 'team1', 'team2', 'team3', 'team4'];

  return (
    <div className="p-6" data-testid="page-agents">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Agents</h1>
          <p className="text-gray-400">Manage and launch your 22-agent ecosystem</p>
        </div>
        
        <div className="flex items-center gap-4">
          <AgentFilters value={filter} onChange={setFilter} />
          <LaunchAllButton onClick={launchAll} />
        </div>
      </div>

      {/* Teams */}
      {teams.map((team) => (
        <TeamSection
          key={team}
          team={team as any}
          agents={agents.filter(a => a.team === team)}
          isExpanded={expandedTeams.includes(team)}
          onToggle={() => {
            setExpandedTeams(prev => 
              prev.includes(team) 
                ? prev.filter(t => t !== team)
                : [...prev, team]
            );
          }}
          onLaunchTeam={() => launchTeam(team)}
          onLaunchAgent={launchAgent}
        />
      ))}
    </div>
  );
}
```

### PAGE 3: LIBRARY

```tsx
// pages/Library.tsx

import { useState } from 'react';
import { LibraryCategories } from '@/components/library/LibraryCategories';
import { LibrarySearch } from '@/components/library/LibrarySearch';
import { DocumentCard } from '@/components/library/DocumentCard';
import { useLibrary } from '@/hooks/useLibrary';

const CATEGORIES = [
  { id: 'nvidia', name: 'NVIDIA Ecosystem', icon: '🟢', count: 15 },
  { id: 'quantum', name: 'Quantum Computing', icon: '⚛️', count: 23 },
  { id: 'energy', name: 'Energy & Thermodynamic', icon: '⚡', count: 12 },
  { id: 'tools', name: 'Critical Tools', icon: '🔧', count: 45 },
  { id: 'protocols', name: 'Protocols', icon: '📋', count: 18 },
  { id: 'research', name: 'Research Papers', icon: '📚', count: 89 },
  { id: 'ceo', name: 'CEO Inputs', icon: '👑', count: 7 },
  { id: 'reports', name: 'Agent Reports', icon: '📊', count: 34 },
];

export function Library() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const { documents, isLoading } = useLibrary(selectedCategory, searchQuery);

  return (
    <div className="p-6" data-testid="page-library">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Knowledge Library</h1>
          <p className="text-gray-400">
            All resources accessible to every agent
          </p>
        </div>
        
        <LibrarySearch value={searchQuery} onChange={setSearchQuery} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Categories Sidebar */}
        <div className="lg:col-span-1">
          <LibraryCategories
            categories={CATEGORIES}
            selected={selectedCategory}
            onSelect={setSelectedCategory}
          />
        </div>

        {/* Documents Grid */}
        <div className="lg:col-span-3">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-48 bg-card rounded-xl animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {documents.map((doc) => (
                <DocumentCard key={doc.id} document={doc} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
```

═══════════════════════════════════════════════════════════════════════════════
## 🔴 REAL-TIME ФУНКЦИОНАЛЬНОСТЬ
═══════════════════════════════════════════════════════════════════════════════

### SOCKET.IO SETUP

```typescript
// lib/socket.ts

import { io, Socket } from 'socket.io-client';

interface ServerToClientEvents {
  'agent:status': (data: { agentId: string; status: AgentStatus }) => void;
  'agent:progress': (data: { agentId: string; progress: number; task: string }) => void;
  'agent:message': (data: { agentId: string; message: string }) => void;
  'team:update': (data: { team: string; agents: Agent[] }) => void;
  'report:new': (data: Report) => void;
  'prototype:ready': (data: Prototype) => void;
  'countdown:sync': (data: { deadline: string }) => void;
}

interface ClientToServerEvents {
  'agent:launch': (agentId: string) => void;
  'agent:stop': (agentId: string) => void;
  'team:launch': (team: string) => void;
  'team:stop': (team: string) => void;
  'all:launch': () => void;
  'all:stop': () => void;
  'chat:message': (data: { agentId: string; message: string }) => void;
}

export const socket: Socket<ServerToClientEvents, ClientToServerEvents> = io({
  autoConnect: true,
  reconnection: true,
  reconnectionAttempts: 5,
  reconnectionDelay: 1000,
});

// Connection status store
export function useSocketStatus() {
  const [connected, setConnected] = useState(socket.connected);

  useEffect(() => {
    const onConnect = () => setConnected(true);
    const onDisconnect = () => setConnected(false);

    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);

    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
    };
  }, []);

  return connected;
}
```

### AGENT STORE WITH REALTIME

```typescript
// stores/agentStore.ts

import { create } from 'zustand';
import { socket } from '@/lib/socket';

interface AgentStore {
  agents: Agent[];
  activeAgents: string[];
  setAgents: (agents: Agent[]) => void;
  updateAgentStatus: (agentId: string, status: AgentStatus) => void;
  updateAgentProgress: (agentId: string, progress: number, task: string) => void;
  launchAgent: (agentId: string) => void;
  stopAgent: (agentId: string) => void;
  launchTeam: (team: string) => void;
  launchAll: () => void;
}

export const useAgentStore = create<AgentStore>((set, get) => ({
  agents: [],
  activeAgents: [],

  setAgents: (agents) => set({ agents }),

  updateAgentStatus: (agentId, status) => {
    set((state) => ({
      agents: state.agents.map((a) =>
        a.id === agentId ? { ...a, status } : a
      ),
    }));
  },

  updateAgentProgress: (agentId, progress, task) => {
    set((state) => ({
      agents: state.agents.map((a) =>
        a.id === agentId ? { ...a, progress, currentTask: task } : a
      ),
    }));
  },

  launchAgent: (agentId) => {
    socket.emit('agent:launch', agentId);
    set((state) => ({
      activeAgents: [...state.activeAgents, agentId],
    }));
  },

  stopAgent: (agentId) => {
    socket.emit('agent:stop', agentId);
    set((state) => ({
      activeAgents: state.activeAgents.filter((id) => id !== agentId),
    }));
  },

  launchTeam: (team) => {
    socket.emit('team:launch', team);
  },

  launchAll: () => {
    socket.emit('all:launch');
  },
}));

// Socket event listeners
socket.on('agent:status', ({ agentId, status }) => {
  useAgentStore.getState().updateAgentStatus(agentId, status);
});

socket.on('agent:progress', ({ agentId, progress, task }) => {
  useAgentStore.getState().updateAgentProgress(agentId, progress, task);
});
```

═══════════════════════════════════════════════════════════════════════════════
## 🔐 СИСТЕМА ДОСТУПА И ПРИВАТНОСТИ
═══════════════════════════════════════════════════════════════════════════════

### ACCESS LEVELS

```typescript
// types/access.ts

export type AccessLevel = 'ceo' | 'cto' | 'lead' | 'agent' | 'viewer';

export interface AccessControl {
  // CEO has full access
  ceo: {
    canViewAllChats: true;
    canViewPrivateChats: true;
    canLaunchAll: true;
    canModifyAgents: true;
    canAccessSettings: true;
    canViewReports: true;
    canExportData: true;
  };
  
  // CTOs have department access
  cto: {
    canViewTeamChats: true;
    canViewPrivateChats: false; // Only CEO
    canLaunchTeam: true;
    canModifyTeamAgents: true;
    canAccessTeamSettings: true;
    canViewTeamReports: true;
  };
  
  // Agents have limited access
  agent: {
    canViewOwnChats: true;
    canAccessLibrary: true;
    canSubmitReports: true;
    canViewPublicData: true;
  };
}

// Private Chat Access
export const PRIVATE_CHAT_ACCESS = {
  // CEO-only private chats
  ceoPrivate: {
    description: 'Direct CEO communication',
    accessLevel: 'ceo',
    encrypted: true,
  },
  
  // Department head chats
  departmentHeads: {
    description: 'Department coordination',
    accessLevel: 'cto',
    encrypted: true,
  },
  
  // Team chats
  teamChats: {
    description: 'Team communication',
    accessLevel: 'agent',
    encrypted: false,
  },
};
```

### AUTH MIDDLEWARE

```typescript
// middleware/auth.ts

import { NextFunction, Request, Response } from 'express';

export function requireAccess(level: AccessLevel) {
  return (req: Request, res: Response, next: NextFunction) => {
    const userLevel = req.user?.accessLevel || 'viewer';
    
    const hierarchy: AccessLevel[] = ['ceo', 'cto', 'lead', 'agent', 'viewer'];
    const userIndex = hierarchy.indexOf(userLevel);
    const requiredIndex = hierarchy.indexOf(level);
    
    if (userIndex <= requiredIndex) {
      next();
    } else {
      res.status(403).json({ error: 'Access denied' });
    }
  };
}

// Protected routes
app.get('/api/private-chats', requireAccess('ceo'), getPrivateChats);
app.get('/api/team-settings/:team', requireAccess('cto'), getTeamSettings);
app.get('/api/library', requireAccess('agent'), getLibrary);
```

═══════════════════════════════════════════════════════════════════════════════
## 📚 БИБЛИОТЕКА И КАТЕГОРИИ
═══════════════════════════════════════════════════════════════════════════════

### LIBRARY STRUCTURE

```typescript
// types/library.ts

export interface Document {
  id: string;
  title: string;
  category: LibraryCategory;
  content: string;
  path: string;
  lastModified: Date;
  accessLevel: AccessLevel;
  tags: string[];
  relatedAgents: string[];
}

export type LibraryCategory =
  | 'nvidia-ecosystem'
  | 'quantum-computing'
  | 'energy-thermodynamic'
  | 'critical-tools'
  | 'protocols'
  | 'research-papers'
  | 'ceo-inputs'
  | 'agent-reports'
  | 'prototypes';

export const LIBRARY_CATEGORIES: Record<LibraryCategory, CategoryInfo> = {
  'nvidia-ecosystem': {
    name: 'NVIDIA Ecosystem',
    icon: '🟢',
    color: '#76B900',
    description: 'CUDA, Triton, PhysicsNeMo, Nsight, NCCL, Dynamo',
    path: 'KNOWLEDGE_LIBRARY/NVIDIA_ECOSYSTEM/',
  },
  'quantum-computing': {
    name: 'Quantum Computing',
    icon: '⚛️',
    color: '#8B5CF6',
    description: 'Qiskit, Cirq, PennyLane, quantum physics',
    path: 'DOMAIN_BRANCHES/NANO_CHIPS/',
  },
  'energy-thermodynamic': {
    name: 'Energy & Thermodynamic',
    icon: '⚡',
    color: '#EF4444',
    description: 'Extropic AI, memristors, energy optimization',
    path: 'KNOWLEDGE_LIBRARY/EXTROPIC_AI_THERMODYNAMIC_COMPUTING.md',
  },
  'critical-tools': {
    name: 'Critical Tools',
    icon: '🔧',
    color: '#F59E0B',
    description: 'All tools agents must use',
    path: 'KNOWLEDGE_LIBRARY/CRITICAL_TOOLS_FOR_AGENTS.md',
  },
  'protocols': {
    name: 'Protocols',
    icon: '📋',
    color: '#3B82F6',
    description: 'Team coordination, workflows, hackathon',
    path: 'PROTOCOLS/',
  },
  'research-papers': {
    name: 'Research Papers',
    icon: '📚',
    color: '#10B981',
    description: 'arXiv papers, scientific references',
    path: 'KNOWLEDGE_LIBRARY/CEO_INPUTS/Papers/',
  },
  'ceo-inputs': {
    name: 'CEO Inputs',
    icon: '👑',
    color: '#EC4899',
    description: 'CEO directives, priorities, decisions',
    path: 'KNOWLEDGE_LIBRARY/CEO_INPUTS/',
  },
  'agent-reports': {
    name: 'Agent Reports',
    icon: '📊',
    color: '#06B6D4',
    description: 'Generated reports from agents',
    path: 'REPORTS/',
  },
  'prototypes': {
    name: 'Prototypes',
    icon: '🔨',
    color: '#A855F7',
    description: 'Working demos and PoCs',
    path: 'PROTOTYPES/',
  },
};
```

═══════════════════════════════════════════════════════════════════════════════
## 📊 РЕПОРТЫ И ПРОТОТИПЫ
═══════════════════════════════════════════════════════════════════════════════

### REPORT STRUCTURE

```typescript
// types/reports.ts

export interface Report {
  id: string;
  title: string;
  agentId: string;
  team: TeamType;
  type: ReportType;
  status: 'draft' | 'submitted' | 'reviewed' | 'approved';
  content: {
    summary: string;
    findings: Finding[];
    recommendations: string[];
    metrics: Metric[];
    attachments: Attachment[];
  };
  createdAt: Date;
  submittedAt: Date | null;
  reviewedBy: string | null;
  tier: ButcherTier;
}

export type ReportType =
  | 'research'      // Agent 0.x reports
  | 'technical'     // Agent 1.x, 2.x reports
  | 'innovation'    // Agent 3.x reports
  | 'business'      // Agent 4.x reports
  | 'hackathon';    // Hackathon submissions

export type ButcherTier = 'S' | 'A' | 'B' | 'C' | 'F';

export interface Prototype {
  id: string;
  name: string;
  agentId: string;
  status: 'development' | 'testing' | 'ready' | 'demo';
  demoUrl: string | null;
  codeRepo: string;
  metrics: {
    speedup: string;
    energyEfficiency: string;
    accuracy: string;
  };
  partnership: {
    readyForNvidia: boolean;
    readyForIntel: boolean;
    lastValidated: Date;
  };
  createdAt: Date;
}
```

### REPORTS DESTINATION

```typescript
// Куда идут репорты:

const REPORT_DESTINATIONS = {
  // Research reports → CEO + relevant CTOs
  research: {
    primary: 'ceo',
    cc: ['cto-1', 'cto-2'],
    storage: 'REPORTS/RESEARCH/',
  },
  
  // Technical reports → Team CTO + CEO
  technical: {
    primary: 'team-cto',
    cc: ['ceo'],
    storage: 'REPORTS/TECHNICAL/',
  },
  
  // Innovation reports → Innovation Lead + CEO
  innovation: {
    primary: 'innovation-lead',
    cc: ['ceo'],
    storage: 'REPORTS/INNOVATION/',
  },
  
  // Business reports → CEO (direct!)
  business: {
    primary: 'ceo',
    cc: [],
    storage: 'REPORTS/BUSINESS/',
  },
  
  // Hackathon submissions → CEO review
  hackathon: {
    primary: 'ceo',
    cc: ['all-ctos'],
    storage: 'REPORTS/HACKATHON/',
  },
};
```

═══════════════════════════════════════════════════════════════════════════════
## 📱 PWA И ДЕПЛОЙ
═══════════════════════════════════════════════════════════════════════════════

### PWA CONFIGURATION

```typescript
// vite.config.ts

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'mask-icon.svg'],
      manifest: {
        name: 'TECH ELDORADO Ecosystem',
        short_name: 'Eldorado',
        description: '22-Agent AI Ecosystem for Quantum Consciousness Development',
        theme_color: '#8B5CF6',
        background_color: '#0A0A0F',
        display: 'standalone',
        orientation: 'portrait',
        scope: '/',
        start_url: '/',
        icons: [
          {
            src: '/icons/icon-72x72.png',
            sizes: '72x72',
            type: 'image/png',
          },
          {
            src: '/icons/icon-96x96.png',
            sizes: '96x96',
            type: 'image/png',
          },
          {
            src: '/icons/icon-128x128.png',
            sizes: '128x128',
            type: 'image/png',
          },
          {
            src: '/icons/icon-144x144.png',
            sizes: '144x144',
            type: 'image/png',
          },
          {
            src: '/icons/icon-152x152.png',
            sizes: '152x152',
            type: 'image/png',
          },
          {
            src: '/icons/icon-192x192.png',
            sizes: '192x192',
            type: 'image/png',
          },
          {
            src: '/icons/icon-384x384.png',
            sizes: '384x384',
            type: 'image/png',
          },
          {
            src: '/icons/icon-512x512.png',
            sizes: '512x512',
            type: 'image/png',
          },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/api\.*/i,
            handler: 'NetworkFirst',
            options: {
              cacheName: 'api-cache',
              expiration: {
                maxEntries: 100,
                maxAgeSeconds: 60 * 60 * 24, // 1 day
              },
            },
          },
        ],
      },
    }),
  ],
});
```

### CLOUDFLARE TUNNEL SETUP

```bash
# Установка Cloudflare Tunnel (локальный запуск + публичный доступ)

# 1. Установить cloudflared
brew install cloudflared  # macOS
# или
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared

# 2. Авторизация
cloudflared tunnel login

# 3. Создать туннель
cloudflared tunnel create eldorado-ecosystem

# 4. Конфигурация (~/.cloudflared/config.yml)
tunnel: <TUNNEL_ID>
credentials-file: ~/.cloudflared/<TUNNEL_ID>.json

ingress:
  - hostname: ecosystem.eldorado.tech
    service: http://localhost:5000
  - service: http_status:404

# 5. DNS routing
cloudflared tunnel route dns eldorado-ecosystem ecosystem.eldorado.tech

# 6. Запуск
cloudflared tunnel run eldorado-ecosystem

# 7. Systemd service (для автозапуска)
sudo cloudflared service install
```

### DEPLOYMENT SCRIPT

```bash
#!/bin/bash
# deploy.sh

echo "🚀 Deploying ELDORADO Ecosystem..."

# Build frontend
echo "📦 Building frontend..."
cd client && npm run build && cd ..

# Build backend
echo "📦 Building backend..."
npm run build:server

# Start services
echo "🔧 Starting services..."
pm2 start ecosystem.config.js

# Start Cloudflare Tunnel
echo "🌐 Starting Cloudflare Tunnel..."
cloudflared tunnel run eldorado-ecosystem &

echo "✅ Deployment complete!"
echo "🌍 Access at: https://ecosystem.eldorado.tech"
```

═══════════════════════════════════════════════════════════════════════════════
## 🔌 API ЭНДПОИНТЫ
═══════════════════════════════════════════════════════════════════════════════

```typescript
// server/routes.ts

// ═══════════════════════════════════════════════════════════════
// AGENTS
// ═══════════════════════════════════════════════════════════════
GET    /api/agents                    // List all agents
GET    /api/agents/:id                // Get agent details
POST   /api/agents/:id/launch         // Launch single agent
POST   /api/agents/:id/stop           // Stop single agent
GET    /api/agents/:id/status         // Get agent status
GET    /api/agents/:id/history        // Get agent task history

// ═══════════════════════════════════════════════════════════════
// TEAMS
// ═══════════════════════════════════════════════════════════════
GET    /api/teams                     // List all teams
GET    /api/teams/:team               // Get team details
POST   /api/teams/:team/launch        // Launch entire team
POST   /api/teams/:team/stop          // Stop entire team
POST   /api/teams/all/launch          // Launch ALL agents
POST   /api/teams/all/stop            // Stop ALL agents

// ═══════════════════════════════════════════════════════════════
// CHAT
// ═══════════════════════════════════════════════════════════════
GET    /api/chat/:agentId             // Get chat history
POST   /api/chat/:agentId             // Send message
GET    /api/chat/private              // Get private chats (CEO only!)
POST   /api/chat/private/:agentId     // Private message (CEO only!)

// ═══════════════════════════════════════════════════════════════
// LIBRARY
// ═══════════════════════════════════════════════════════════════
GET    /api/library                   // List all documents
GET    /api/library/:category         // List by category
GET    /api/library/doc/:id           // Get document content
POST   /api/library/search            // Search library

// ═══════════════════════════════════════════════════════════════
// REPORTS
// ═══════════════════════════════════════════════════════════════
GET    /api/reports                   // List all reports
GET    /api/reports/:id               // Get report details
POST   /api/reports                   // Submit new report
PATCH  /api/reports/:id/review        // Review report (CEO/CTO)
GET    /api/reports/agent/:agentId    // Reports by agent

// ═══════════════════════════════════════════════════════════════
// PROTOTYPES
// ═══════════════════════════════════════════════════════════════
GET    /api/prototypes                // List all prototypes
GET    /api/prototypes/:id            // Get prototype details
POST   /api/prototypes                // Create prototype
PATCH  /api/prototypes/:id/status     // Update status
GET    /api/prototypes/:id/demo       // Get demo URL

// ═══════════════════════════════════════════════════════════════
// HACKATHON
// ═══════════════════════════════════════════════════════════════
GET    /api/hackathon                 // Get hackathon status
POST   /api/hackathon/start           // Start hackathon
GET    /api/hackathon/submissions     // Get all submissions
POST   /api/hackathon/submit          // Submit hackathon entry
PATCH  /api/hackathon/:id/evaluate    // CEO evaluate entry

// ═══════════════════════════════════════════════════════════════
// SYSTEM
// ═══════════════════════════════════════════════════════════════
GET    /api/status                    // System status
GET    /api/countdown                 // Deadline info
GET    /api/gpu                       // GPU status
POST   /api/gpu/enable                // Enable GPU tools
```

═══════════════════════════════════════════════════════════════════════════════
## 📱 MOBILE CONSIDERATIONS
═══════════════════════════════════════════════════════════════════════════════

### PWA = MOBILE APP (No separate app needed!)

```typescript
// PWA преимущества:

const PWA_BENEFITS = {
  // Установка
  install: 'Add to Home Screen на iOS/Android',
  icon: 'Появляется как обычное приложение',
  
  // Функциональность
  offline: 'Service Worker кэширует критичные данные',
  push: 'Web Push notifications для alerts',
  background: 'Background sync для обновлений',
  
  // UX
  fullscreen: 'Standalone mode без браузерной рамки',
  responsive: 'Адаптивный дизайн под все размеры',
  touch: 'Оптимизированные touch interactions',
  
  // Разработка
  singleCodebase: 'Один код для web + mobile',
  instantUpdates: 'Обновления без app store',
  noApproval: 'Не нужно ждать review',
};

// Responsive breakpoints
const BREAKPOINTS = {
  mobile: '< 640px',    // Phone portrait
  tablet: '640-1024px', // Tablet / Phone landscape
  desktop: '> 1024px',  // Desktop
};

// Mobile-specific components
const MOBILE_ADAPTATIONS = {
  sidebar: 'Bottom navigation на mobile',
  countdown: 'Компактная версия',
  agentCards: 'Swipeable carousel',
  chat: 'Full-screen modal',
  library: 'Collapsible categories',
};
```

═══════════════════════════════════════════════════════════════════════════════
## ✅ ЧЕКЛИСТ ДЛЯ РЕАЛИЗАЦИИ
═══════════════════════════════════════════════════════════════════════════════

```
PHASE 1: CORE SETUP
□ Initialize Vite + React + TypeScript project
□ Configure TailwindCSS + shadcn/ui
□ Set up routing (React Router)
□ Create base layout (Sidebar, Header)
□ Implement dark theme

PHASE 2: COMPONENTS
□ DeadlineCountdown (PRIORITY!)
□ AgentCard
□ TeamSection
□ ChatInterface
□ LibraryCategories
□ ReportCard
□ PrototypeCard

PHASE 3: PAGES
□ Dashboard
□ Agents
□ Library
□ Reports
□ Prototypes
□ Chat
□ Hackathon
□ Settings

PHASE 4: BACKEND
□ Express/Hono server
□ PostgreSQL + Drizzle setup
□ Socket.io for realtime
□ API routes implementation
□ Authentication (Clerk)

PHASE 5: REALTIME
□ Socket.io client setup
□ Agent status updates
□ Chat messaging
□ Report notifications
□ Prototype alerts

PHASE 6: PWA
□ Vite PWA plugin config
□ Service Worker
□ Manifest.json
□ Icons (all sizes)
□ Offline support

PHASE 7: DEPLOY
□ Cloudflare Tunnel setup
□ DNS configuration
□ SSL (automatic via CF)
□ PM2 process manager
□ Health checks
```

═══════════════════════════════════════════════════════════════════════════════

**ГОТОВО К ПЕРЕДАЧЕ В CURSOR/GEMINI/CLAUDE ДЛЯ РЕАЛИЗАЦИИ!**

