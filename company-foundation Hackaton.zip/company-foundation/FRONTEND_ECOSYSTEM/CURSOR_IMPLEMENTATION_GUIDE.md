# CURSOR/GEMINI IMPLEMENTATION GUIDE
**Пошаговая инструкция для создания ELDORADO Ecosystem Frontend**

═══════════════════════════════════════════════════════════════════════════════
## КРАТКАЯ ИНСТРУКЦИЯ ДЛЯ CURSOR/GEMINI
═══════════════════════════════════════════════════════════════════════════════

```
PROMPT ДЛЯ CURSOR:

"Создай React + TypeScript + Vite приложение с TailwindCSS и shadcn/ui.

Это dashboard для управления 22 AI-агентами с:
- Countdown таймером до 31 декабря 2025
- Карточками агентов с статусами (active/idle/blocked/completed)
- Группировкой по 6 командам (Leadership + Team 0-4)
- Чатом с агентами (включая приватные для CEO)
- Библиотекой знаний с категориями
- Системой репортов и прототипов
- Real-time обновлениями через Socket.io
- PWA поддержкой для мобильных

Темная тема с фиолетовым акцентом (#8B5CF6).
Локальный запуск + Cloudflare Tunnel для публичного доступа.

Смотри спецификации в:
- COMPLETE_FRONTEND_SPECIFICATION.md
- AGENTS_DATA.md"
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 1: PROJECT INITIALIZATION
═══════════════════════════════════════════════════════════════════════════════

```bash
# 1. Создать проект
npm create vite@latest eldorado-ecosystem -- --template react-ts
cd eldorado-ecosystem

# 2. Установить dependencies
npm install

# Core
npm install react-router-dom zustand @tanstack/react-query socket.io-client framer-motion

# UI
npm install tailwindcss postcss autoprefixer
npm install @radix-ui/react-icons lucide-react
npm install recharts

# Forms & Validation
npm install react-hook-form @hookform/resolvers zod

# PWA
npm install vite-plugin-pwa

# 3. Инициализировать TailwindCSS
npx tailwindcss init -p

# 4. Установить shadcn/ui
npx shadcn@latest init
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 2: TAILWIND CONFIGURATION
═══════════════════════════════════════════════════════════════════════════════

```javascript
// tailwind.config.js

/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // Brand
        primary: {
          50: '#F5F3FF',
          100: '#EDE9FE',
          200: '#DDD6FE',
          300: '#C4B5FD',
          400: '#A78BFA',
          500: '#8B5CF6',
          600: '#7C3AED',
          700: '#6D28D9',
          800: '#5B21B6',
          900: '#4C1D95',
        },
        nvidia: '#76B900',
        
        // Background (dark theme)
        background: '#0A0A0F',
        surface: '#12121A',
        card: '#1A1A25',
        hover: '#252530',
        
        // Border
        border: '#27272A',
        
        // Status
        status: {
          active: '#22C55E',
          idle: '#6B7280',
          blocked: '#EF4444',
          completed: '#3B82F6',
        },
        
        // Urgency
        urgency: {
          critical: '#DC2626',
          high: '#F97316',
          moderate: '#EAB308',
          normal: '#22C55E',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
        display: ['Space Grotesk', 'sans-serif'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
    },
  },
  plugins: [],
}
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 3: GLOBAL STYLES
═══════════════════════════════════════════════════════════════════════════════

```css
/* src/index.css */

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono&family=Space+Grotesk:wght@500;600;700&display=swap');

@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 4%;
    --foreground: 0 0% 98%;
    --card: 240 6% 10%;
    --card-foreground: 0 0% 98%;
    --primary: 262 83% 58%;
    --primary-foreground: 0 0% 100%;
    --secondary: 240 4% 16%;
    --secondary-foreground: 0 0% 98%;
    --muted: 240 4% 16%;
    --muted-foreground: 240 5% 65%;
    --accent: 262 83% 58%;
    --accent-foreground: 0 0% 100%;
    --destructive: 0 84% 60%;
    --destructive-foreground: 0 0% 100%;
    --border: 240 4% 16%;
    --input: 240 4% 16%;
    --ring: 262 83% 58%;
    --radius: 0.75rem;
  }

  * {
    @apply border-border;
  }

  body {
    @apply bg-background text-foreground;
    font-feature-settings: "rlig" 1, "calt" 1;
  }

  /* Scrollbar */
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  ::-webkit-scrollbar-track {
    @apply bg-surface;
  }

  ::-webkit-scrollbar-thumb {
    @apply bg-border rounded-full;
  }

  ::-webkit-scrollbar-thumb:hover {
    @apply bg-hover;
  }
}

@layer components {
  .glass {
    @apply bg-card/80 backdrop-blur-md border border-border;
  }
  
  .glow-purple {
    box-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
  }
  
  .glow-green {
    box-shadow: 0 0 20px rgba(34, 197, 94, 0.3);
  }
  
  .glow-red {
    box-shadow: 0 0 20px rgba(239, 68, 68, 0.3);
  }
}
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 4: FILE STRUCTURE
═══════════════════════════════════════════════════════════════════════════════

```
src/
├── components/
│   ├── ui/                    # shadcn components
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── input.tsx
│   │   └── ...
│   │
│   ├── layout/
│   │   ├── Sidebar.tsx        # Navigation sidebar
│   │   ├── Header.tsx         # Top header
│   │   └── Layout.tsx         # Main layout wrapper
│   │
│   ├── countdown/
│   │   └── DeadlineCountdown.tsx  # ⏰ CRITICAL COMPONENT!
│   │
│   ├── agents/
│   │   ├── AgentCard.tsx      # Individual agent card
│   │   ├── TeamSection.tsx    # Team accordion
│   │   ├── AgentFilters.tsx   # Status filters
│   │   ├── LaunchAllButton.tsx
│   │   └── AgentStatus.tsx    # Status indicator
│   │
│   ├── chat/
│   │   ├── ChatInterface.tsx  # Chat UI
│   │   ├── MessageBubble.tsx  # Individual message
│   │   └── ChatList.tsx       # List of chats
│   │
│   ├── library/
│   │   ├── LibraryCategories.tsx
│   │   ├── LibrarySearch.tsx
│   │   └── DocumentCard.tsx
│   │
│   ├── reports/
│   │   ├── ReportCard.tsx
│   │   └── ReportViewer.tsx
│   │
│   ├── prototypes/
│   │   ├── PrototypeCard.tsx
│   │   └── DemoLauncher.tsx
│   │
│   └── dashboard/
│       ├── TeamOverview.tsx
│       ├── ActiveAgents.tsx
│       ├── RecentReports.tsx
│       └── QuickActions.tsx
│
├── pages/
│   ├── Dashboard.tsx          # Main dashboard
│   ├── Agents.tsx             # All agents view
│   ├── AgentDetail.tsx        # Single agent
│   ├── Library.tsx            # Knowledge library
│   ├── Reports.tsx            # All reports
│   ├── Prototypes.tsx         # Prototypes
│   ├── Chat.tsx               # Chat interface
│   ├── Hackathon.tsx          # Hackathon page
│   └── Settings.tsx           # Settings
│
├── hooks/
│   ├── useAgents.ts           # Agent operations
│   ├── useChat.ts             # Chat operations
│   ├── useCountdown.ts        # Deadline countdown
│   ├── useLibrary.ts          # Library operations
│   ├── useSocket.ts           # Socket.io connection
│   └── useToast.ts            # Toast notifications
│
├── stores/
│   ├── agentStore.ts          # Zustand agent store
│   ├── chatStore.ts           # Chat state
│   └── uiStore.ts             # UI state (sidebar, modals)
│
├── lib/
│   ├── api.ts                 # API client
│   ├── socket.ts              # Socket.io setup
│   ├── utils.ts               # Utilities
│   └── constants.ts           # Constants
│
├── data/
│   ├── agents.ts              # Agent data (from AGENTS_DATA.md)
│   ├── teams.ts               # Team configuration
│   └── models.ts              # AI models info
│
├── types/
│   └── index.ts               # TypeScript types
│
├── App.tsx                    # Main app with routing
├── main.tsx                   # Entry point
└── vite-env.d.ts
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 5: KEY COMPONENTS TO CREATE FIRST
═══════════════════════════════════════════════════════════════════════════════

### PRIORITY 1: DeadlineCountdown

```
КРИТИЧЕСКИ ВАЖЕН! Должен быть виден на КАЖДОЙ странице!

Требования:
- Countdown до December 31, 2025 23:59:59 UTC
- Обновление каждую секунду
- 4 блока: Days, Hours, Minutes, Seconds
- Цвет зависит от urgency level:
  • Critical (0-10 days): Red, пульсирует
  • High (11-25 days): Orange
  • Moderate (26-50 days): Yellow
  • Normal (51+ days): Green
- Сообщение под таймером зависит от urgency
```

### PRIORITY 2: AgentCard

```
Карточка агента с:
- Avatar/Icon (зависит от роли)
- Имя и роль
- Статус (active/idle/blocked/completed) с иконкой
- Прогресс бар
- Текущая задача (если есть)
- AI модель и cost
- Tools (показать 3 + "+N")
- Цветовой акцент сверху (team color)
- Hover эффект
- Click для открытия деталей
```

### PRIORITY 3: Sidebar

```
Левый sidebar с:
- Logo + название
- Navigation items (Dashboard, Agents, Library, Reports, etc.)
- Hackathon с badge "NEW"
- GPU Status indicator внизу
- Collapsible (можно свернуть)
```

### PRIORITY 4: TeamSection

```
Секция команды:
- Header с названием, иконкой, цветом
- Кнопка "Launch Team"
- Expand/Collapse стрелка
- Grid агентов внутри
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 6: ROUTING SETUP
═══════════════════════════════════════════════════════════════════════════════

```tsx
// src/App.tsx

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Layout } from './components/layout/Layout';

// Pages
import Dashboard from './pages/Dashboard';
import Agents from './pages/Agents';
import AgentDetail from './pages/AgentDetail';
import Library from './pages/Library';
import Reports from './pages/Reports';
import Prototypes from './pages/Prototypes';
import Chat from './pages/Chat';
import Hackathon from './pages/Hackathon';
import Settings from './pages/Settings';

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="agents" element={<Agents />} />
            <Route path="agents/:id" element={<AgentDetail />} />
            <Route path="library" element={<Library />} />
            <Route path="reports" element={<Reports />} />
            <Route path="prototypes" element={<Prototypes />} />
            <Route path="chat" element={<Chat />} />
            <Route path="chat/:agentId" element={<Chat />} />
            <Route path="hackathon" element={<Hackathon />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 7: ZUSTAND STORES
═══════════════════════════════════════════════════════════════════════════════

```tsx
// src/stores/agentStore.ts

import { create } from 'zustand';
import { AGENTS } from '@/data/agents';
import type { Agent, AgentStatus } from '@/types';

interface AgentStore {
  agents: Agent[];
  selectedAgent: Agent | null;
  
  // Actions
  setAgents: (agents: Agent[]) => void;
  selectAgent: (id: string) => void;
  updateAgentStatus: (id: string, status: AgentStatus) => void;
  updateAgentProgress: (id: string, progress: number, task: string) => void;
  launchAgent: (id: string) => void;
  stopAgent: (id: string) => void;
  launchTeam: (team: string) => void;
  launchAll: () => void;
}

export const useAgentStore = create<AgentStore>((set, get) => ({
  agents: AGENTS,
  selectedAgent: null,
  
  setAgents: (agents) => set({ agents }),
  
  selectAgent: (id) => {
    const agent = get().agents.find(a => a.id === id);
    set({ selectedAgent: agent || null });
  },
  
  updateAgentStatus: (id, status) => {
    set((state) => ({
      agents: state.agents.map(a => 
        a.id === id ? { ...a, status, lastUpdate: new Date() } : a
      ),
    }));
  },
  
  updateAgentProgress: (id, progress, task) => {
    set((state) => ({
      agents: state.agents.map(a => 
        a.id === id ? { ...a, progress, currentTask: task, lastUpdate: new Date() } : a
      ),
    }));
  },
  
  launchAgent: (id) => {
    set((state) => ({
      agents: state.agents.map(a => 
        a.id === id ? { ...a, status: 'active', lastUpdate: new Date() } : a
      ),
    }));
    // TODO: Emit socket event
  },
  
  stopAgent: (id) => {
    set((state) => ({
      agents: state.agents.map(a => 
        a.id === id ? { ...a, status: 'idle', lastUpdate: new Date() } : a
      ),
    }));
    // TODO: Emit socket event
  },
  
  launchTeam: (team) => {
    set((state) => ({
      agents: state.agents.map(a => 
        a.team === team ? { ...a, status: 'active', lastUpdate: new Date() } : a
      ),
    }));
    // TODO: Emit socket event
  },
  
  launchAll: () => {
    set((state) => ({
      agents: state.agents.map(a => ({ ...a, status: 'active', lastUpdate: new Date() })),
    }));
    // TODO: Emit socket event
  },
}));
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 8: PWA CONFIGURATION
═══════════════════════════════════════════════════════════════════════════════

```typescript
// vite.config.ts

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import path from 'path';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.ico', 'apple-touch-icon.png'],
      manifest: {
        name: 'TECH ELDORADO Ecosystem',
        short_name: 'Eldorado',
        description: '22-Agent AI Ecosystem',
        theme_color: '#8B5CF6',
        background_color: '#0A0A0F',
        display: 'standalone',
        icons: [
          { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
      },
    }),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 9: CLOUDFLARE TUNNEL
═══════════════════════════════════════════════════════════════════════════════

```bash
# 1. Install cloudflared
brew install cloudflare/cloudflare/cloudflared

# 2. Login
cloudflared tunnel login

# 3. Create tunnel
cloudflared tunnel create eldorado

# 4. Configure (~/.cloudflared/config.yml)
echo "
tunnel: <TUNNEL_ID>
credentials-file: ~/.cloudflared/<TUNNEL_ID>.json

ingress:
  - hostname: ecosystem.eldorado.tech
    service: http://localhost:5173
  - service: http_status:404
" > ~/.cloudflared/config.yml

# 5. Route DNS
cloudflared tunnel route dns eldorado ecosystem.eldorado.tech

# 6. Run (in separate terminal)
cloudflared tunnel run eldorado
```

═══════════════════════════════════════════════════════════════════════════════
## STEP 10: RUN COMMANDS
═══════════════════════════════════════════════════════════════════════════════

```bash
# Development (local only)
npm run dev

# Development + Cloudflare Tunnel (public access)
npm run dev &
cloudflared tunnel run eldorado

# Build for production
npm run build

# Preview production build
npm run preview
```

═══════════════════════════════════════════════════════════════════════════════
## QUICK REFERENCE: COMPONENT IMPORTS
═══════════════════════════════════════════════════════════════════════════════

```tsx
// Часто используемые импорты

// Icons (Lucide)
import { 
  Activity, Pause, AlertCircle, CheckCircle2,  // Status
  Users, Bot, MessageSquare,                    // Agents
  Library, FileText, Box,                       // Content
  Settings, ChevronDown, ChevronLeft,           // UI
  Play, Pause, Zap, Rocket,                     // Actions
  Lock, Send, Paperclip,                        // Chat
} from 'lucide-react';

// Framer Motion
import { motion, AnimatePresence } from 'framer-motion';

// Router
import { Link, useLocation, useParams, useNavigate } from 'react-router-dom';

// Store
import { useAgentStore } from '@/stores/agentStore';

// Data
import { AGENTS } from '@/data/agents';
import { TEAMS } from '@/data/teams';

// Utils
import { cn } from '@/lib/utils';
```

═══════════════════════════════════════════════════════════════════════════════
## TROUBLESHOOTING
═══════════════════════════════════════════════════════════════════════════════

```
ПРОБЛЕМА: shadcn components не работают
РЕШЕНИЕ: npx shadcn@latest add button card input ...

ПРОБЛЕМА: TailwindCSS не применяется
РЕШЕНИЕ: Проверь content в tailwind.config.js

ПРОБЛЕМА: PWA не устанавливается
РЕШЕНИЕ: Нужен HTTPS (Cloudflare Tunnel даёт его автоматически)

ПРОБЛЕМА: Socket.io не подключается
РЕШЕНИЕ: Проверь что backend запущен на правильном порту

ПРОБЛЕМА: Countdown показывает неправильное время
РЕШЕНИЕ: Убедись что используешь UTC: new Date('2025-12-31T23:59:59Z')
```

═══════════════════════════════════════════════════════════════════════════════

**ВСЁ ГОТОВО ДЛЯ ПЕРЕДАЧИ В CURSOR!**

Просто скопируй этот файл и COMPLETE_FRONTEND_SPECIFICATION.md + AGENTS_DATA.md
и дай их Cursor/Gemini/Claude для создания приложения.

