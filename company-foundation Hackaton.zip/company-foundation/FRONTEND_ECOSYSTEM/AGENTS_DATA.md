# AGENTS DATA — ПОЛНЫЕ ДАННЫЕ 22 АГЕНТОВ

**Для копирования в код**

═══════════════════════════════════════════════════════════════════════════════
## TypeScript Types
═══════════════════════════════════════════════════════════════════════════════

```typescript
// types/agents.ts

export type AgentStatus = 'active' | 'idle' | 'blocked' | 'completed';
export type TeamType = 'leadership' | 'team0' | 'team1' | 'team2' | 'team3' | 'team4';

export interface AIModel {
  name: string;
  provider: string;
  cost: string;
  icon: string;
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  team: TeamType;
  model: AIModel;
  status: AgentStatus;
  currentTask: string | null;
  progress: number;
  color: string;
  tools: string[];
  lastUpdate: Date;
}
```

═══════════════════════════════════════════════════════════════════════════════
## Complete Agents Array
═══════════════════════════════════════════════════════════════════════════════

```typescript
// data/agents.ts

export const AGENTS: Agent[] = [
  // ═══════════════════════════════════════════════════════════════
  // LEADERSHIP — 3 Department Heads
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'cto-1',
    name: 'CTO 1 - Quantum',
    role: 'CTO/Engineering Lead - Vacancy Hunting',
    team: 'leadership',
    model: { 
      name: 'Claude 4 Opus', 
      provider: 'Anthropic', 
      cost: '$150-250/46d', 
      icon: '🧠' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#8B5CF6',
    tools: ['Strategic Planning', 'Team Coordination', 'Physics Validation', 'Elon Algorithm'],
    lastUpdate: new Date(),
  },
  {
    id: 'cto-2',
    name: 'CTO 2 - Energy',
    role: 'CTO/Engineering Lead - Partnership Technology',
    team: 'leadership',
    model: { 
      name: 'Claude 4 Opus', 
      provider: 'Anthropic', 
      cost: '$150-250/46d', 
      icon: '🧠' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#10B981',
    tools: ['NVIDIA Integration', 'Partnership Strategy', 'Technical Validation', 'CUDA Monopoly Test'],
    lastUpdate: new Date(),
  },
  {
    id: 'innovation-lead',
    name: 'Innovation Lead',
    role: 'Innovation Lead - Breakthrough Development',
    team: 'leadership',
    model: { 
      name: 'GPT-5', 
      provider: 'OpenAI', 
      cost: '$100-200/46d', 
      icon: '🚀' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#F59E0B',
    tools: ['Vacancy Detection', 'Synthesis', 'Prototyping', 'Butcher Tier System'],
    lastUpdate: new Date(),
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 0: RESEARCH FOUNDATION — 3 agents
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-0.1',
    name: 'Agent 0.1',
    role: 'Breakthrough Research Scientist',
    team: 'team0',
    model: { 
      name: 'Claude 3.7 Sonnet', 
      provider: 'Anthropic', 
      cost: '$105/46d', 
      icon: '📚' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#3B82F6',
    tools: ['arXiv Scanner', 'Paper Analysis', 'Insight Extraction', 'Scientific Validation'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-0.2',
    name: 'Agent 0.2',
    role: 'Applied Technology Researcher',
    team: 'team0',
    model: { 
      name: 'Kimi K2 Thinking', 
      provider: 'Moonshot AI', 
      cost: '$8/46d', 
      icon: '🔍' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#6366F1',
    tools: ['Multi-step Research', 'Pattern Detection', 'Gap Finding', 'BrowseComp'],
    lastUpdate: new Date(),
  },
  {
    id: 'designer-0.d',
    name: 'Designer 0.D',
    role: 'Visual Designer (B2B)',
    team: 'team0',
    model: { 
      name: 'Gemini 2.5 Pro', 
      provider: 'Google', 
      cost: '$0.14/46d', 
      icon: '🎨' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#EC4899',
    tools: ['Presentation Design', 'Visual Diagrams', 'Slide Layouts', 'Google Workspace'],
    lastUpdate: new Date(),
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 1: QUANTUM CONSCIOUSNESS — 4 agents
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-1.1',
    name: 'Agent 1.1',
    role: 'Quantum Physics Specialist',
    team: 'team1',
    model: { 
      name: 'Gemini 2.5 Pro', 
      provider: 'Google', 
      cost: '$20-40/46d', 
      icon: '⚛️' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#8B5CF6',
    tools: ['Genesis', 'PhysicsNeMo', 'Newton', 'Qiskit', 'Cirq'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-1.2',
    name: 'Agent 1.2',
    role: 'H100 Optimization Expert',
    team: 'team1',
    model: { 
      name: 'Qwen3-235B', 
      provider: 'Self-hosted (Ollama)', 
      cost: 'FREE', 
      icon: '⚡' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#76B900',
    tools: ['Sakana AI', 'CUDA-L1', 'Nsight Systems', 'Nsight Compute', 'Triton'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-1.3',
    name: 'Agent 1.3',
    role: 'Consciousness Emergence Architect',
    team: 'team1',
    model: { 
      name: 'Claude 4 Opus', 
      provider: 'Anthropic', 
      cost: '$150-250/46d', 
      icon: '🧬' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#7C3AED',
    tools: ['System Architecture', 'Emergence Patterns', 'Integration Strategy', 'Newton Genesis'],
    lastUpdate: new Date(),
  },
  {
    id: 'designer-1.d',
    name: 'Designer 1.D',
    role: 'Industrial Designer (Nano-chip)',
    team: 'team1',
    model: { 
      name: 'Gemini 2.5 Pro', 
      provider: 'Google', 
      cost: '$10-30/46d', 
      icon: '🔧' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#64748B',
    tools: ['Genesis 3D', 'Newton Physics', 'Blender', 'KLayout'],
    lastUpdate: new Date(),
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 2: ENERGY & PARTNERSHIP — 5 agents
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-2.1',
    name: 'Agent 2.1',
    role: 'Thermodynamic Computing Specialist',
    team: 'team2',
    model: { 
      name: 'DeepSeek R1', 
      provider: 'Self-hosted (MIT)', 
      cost: 'FREE', 
      icon: '🔥' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#EF4444',
    tools: ['ElmerFEM', 'Energy2D', 'Extropic Docs', 'OpenFOAM'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-2.2',
    name: 'Agent 2.2',
    role: 'USC Memristor Expert',
    team: 'team2',
    model: { 
      name: 'Gemini 2.5 Pro', 
      provider: 'Google', 
      cost: '$15-25/46d', 
      icon: '💾' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#06B6D4',
    tools: ['MemTorch', 'NeuroSim', 'PyMOL', 'RDKit'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-2.3',
    name: 'Agent 2.3',
    role: 'Power Architecture Engineer',
    team: 'team2',
    model: { 
      name: 'Qwen3-235B', 
      provider: 'Self-hosted (Ollama)', 
      cost: 'FREE', 
      icon: '⚡' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#FBBF24',
    tools: ['PowerSensor3', 'Energy Profiler', 'RAPL', 'Ngspice'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-2.4',
    name: 'Agent 2.4',
    role: 'Neuromorphic Architecture Expert',
    team: 'team2',
    model: { 
      name: 'Gemini 2.5 Pro', 
      provider: 'Google', 
      cost: '$15-25/46d', 
      icon: '🧠' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#A855F7',
    tools: ['Brian2', 'NEST', 'SNN Toolbox', 'Nengo'],
    lastUpdate: new Date(),
  },
  {
    id: 'designer-2.d',
    name: 'Designer 2.D',
    role: 'Visual + Technical Designer',
    team: 'team2',
    model: { 
      name: 'Gemini 2.5 Flash', 
      provider: 'Google', 
      cost: '$0.05/46d', 
      icon: '🎨' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#F472B6',
    tools: ['Technical Diagrams', 'Partnership Decks', 'Figma'],
    lastUpdate: new Date(),
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 3: INNOVATION LAB — 4 agents
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-3.1',
    name: 'Agent 3.1',
    role: 'Cross-Company Analyst',
    team: 'team3',
    model: { 
      name: 'Kimi K2 Thinking', 
      provider: 'Moonshot AI', 
      cost: '$15/46d', 
      icon: '🔎' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#14B8A6',
    tools: ['cuGraph', 'Company Intel', 'Gap Analysis', 'NetworkX'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-3.2',
    name: 'Agent 3.2',
    role: 'Innovation Synthesist',
    team: 'team3',
    model: { 
      name: 'Claude 3.7 Sonnet', 
      provider: 'Anthropic', 
      cost: '$30/46d', 
      icon: '💡' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#F97316',
    tools: ['Combination Engine', 'A+B+C Testing', 'Synthesis', 'Citation Networks'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-3.3',
    name: 'Agent 3.3',
    role: 'Technical Prototyper',
    team: 'team3',
    model: { 
      name: 'Claude 3.7 Sonnet', 
      provider: 'Anthropic', 
      cost: '$30/46d', 
      icon: '🔨' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#0EA5E9',
    tools: ['Triton Server', 'Nsight', 'PoC Builder', 'Docker'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-3.4',
    name: 'Agent 3.4',
    role: 'Business Validator',
    team: 'team3',
    model: { 
      name: 'GPT-5', 
      provider: 'OpenAI', 
      cost: '$10/46d', 
      icon: '💼' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#22C55E',
    tools: ['TAM/SAM/SOM', 'Partnership Pitch', 'Business Case', 'Butcher Tier'],
    lastUpdate: new Date(),
  },

  // ═══════════════════════════════════════════════════════════════
  // TEAM 4: MARKETING & SALES — 3 agents
  // ═══════════════════════════════════════════════════════════════
  {
    id: 'agent-4.1',
    name: 'Agent 4.1',
    role: 'PoC Demo Creator',
    team: 'team4',
    model: { 
      name: 'Claude 3.7 Sonnet + Veo 3.1', 
      provider: 'Anthropic + Google', 
      cost: '$13-23/46d', 
      icon: '🎬' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#EF4444',
    tools: ['Veo 3.1', 'NVIDIA Omniverse', 'Genesis', 'Video Editing'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-4.2',
    name: 'Agent 4.2',
    role: 'CEO Presentation Coach',
    team: 'team4',
    model: { 
      name: 'Gemini 2.5 Pro', 
      provider: 'Google', 
      cost: '$2-3/46d', 
      icon: '🎤' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#8B5CF6',
    tools: ['Demo Narration', 'Q&A Prep', 'Live Coaching', 'Presentation Skills'],
    lastUpdate: new Date(),
  },
  {
    id: 'agent-4.3',
    name: 'Agent 4.3',
    role: 'Strategic Marketing Coordinator',
    team: 'team4',
    model: { 
      name: 'Kimi K2 Thinking', 
      provider: 'Moonshot AI', 
      cost: '$114-223/46d', 
      icon: '📊' 
    },
    status: 'idle',
    currentTask: null,
    progress: 0,
    color: '#10B981',
    tools: ['cuGraph', 'LinkedIn Sales Navigator', 'HubSpot', 'Medium'],
    lastUpdate: new Date(),
  },
];
```

═══════════════════════════════════════════════════════════════════════════════
## Team Configuration
═══════════════════════════════════════════════════════════════════════════════

```typescript
// data/teams.ts

export const TEAMS = {
  leadership: {
    id: 'leadership',
    name: 'Leadership',
    fullName: '3 Department Heads',
    icon: '👑',
    color: '#8B5CF6',
    description: 'CTOs and Innovation Lead',
    agentCount: 3,
  },
  team0: {
    id: 'team0',
    name: 'Team 0',
    fullName: 'Research Foundation',
    icon: '📚',
    color: '#3B82F6',
    description: 'Breakthrough research & applied technology',
    agentCount: 3,
  },
  team1: {
    id: 'team1',
    name: 'Team 1',
    fullName: 'Quantum Consciousness',
    icon: '⚛️',
    color: '#8B5CF6',
    description: 'Quantum physics, H100 optimization, consciousness',
    agentCount: 4,
  },
  team2: {
    id: 'team2',
    name: 'Team 2',
    fullName: 'Energy & Partnership',
    icon: '⚡',
    color: '#10B981',
    description: 'Thermodynamic, memristors, neuromorphic',
    agentCount: 5,
  },
  team3: {
    id: 'team3',
    name: 'Team 3',
    fullName: 'Innovation Lab',
    icon: '💡',
    color: '#F59E0B',
    description: 'Analysis, synthesis, prototyping, validation',
    agentCount: 4,
  },
  team4: {
    id: 'team4',
    name: 'Team 4',
    fullName: 'Marketing & Sales',
    icon: '📊',
    color: '#EF4444',
    description: 'Demos, presentations, marketing',
    agentCount: 3,
  },
};

export const TOTAL_AGENTS = 22;
```

═══════════════════════════════════════════════════════════════════════════════
## AI Models Summary
═══════════════════════════════════════════════════════════════════════════════

```typescript
// data/models.ts

export const AI_MODELS = {
  'claude-4-opus': {
    name: 'Claude 4 Opus',
    provider: 'Anthropic',
    strengths: ['Best reasoning', 'GPQA 88.4%', 'Lowest hallucinations'],
    costPer46Days: '$150-250',
    usedBy: ['CTO 1', 'CTO 2', 'Agent 1.3'],
  },
  'claude-3.7-sonnet': {
    name: 'Claude 3.7 Sonnet',
    provider: 'Anthropic',
    strengths: ['Scientific reasoning', 'MMLU 93.7%', '200K context'],
    costPer46Days: '$30-105',
    usedBy: ['Agent 0.1', 'Agent 3.2', 'Agent 3.3', 'Agent 4.1'],
  },
  'gemini-2.5-pro': {
    name: 'Gemini 2.5 Pro',
    provider: 'Google',
    strengths: ['Multimodal', '2M context', 'Cheap'],
    costPer46Days: '$0.14-40',
    usedBy: ['Designer 0.D', 'Agent 1.1', 'Designer 1.D', 'Agent 2.2', 'Agent 2.4', 'Agent 4.2'],
  },
  'kimi-k2': {
    name: 'Kimi K2 Thinking',
    provider: 'Moonshot AI',
    strengths: ['Agentic workflows', 'BrowseComp 60.2%', '96% cheaper than o1'],
    costPer46Days: '$8-223',
    usedBy: ['Agent 0.2', 'Agent 3.1', 'Agent 4.3'],
  },
  'qwen3-235b': {
    name: 'Qwen3-235B',
    provider: 'Self-hosted (Ollama)',
    strengths: ['FREE', 'Math 85.7% AIME', 'Open weights'],
    costPer46Days: 'FREE',
    usedBy: ['Agent 1.2', 'Agent 2.3'],
  },
  'deepseek-r1': {
    name: 'DeepSeek R1',
    provider: 'Self-hosted (MIT)',
    strengths: ['FREE', 'Strong reasoning', 'MIT license'],
    costPer46Days: 'FREE',
    usedBy: ['Agent 2.1'],
  },
  'gpt-5': {
    name: 'GPT-5',
    provider: 'OpenAI',
    strengths: ['General excellence', 'Agentic', 'Tool use'],
    costPer46Days: '$10-200',
    usedBy: ['Innovation Lead', 'Agent 3.4'],
  },
};

// Total estimated cost
export const TOTAL_ESTIMATED_COST = {
  minimum: '$527',
  maximum: '$796',
  per46Days: true,
  budgetPercentage: '53-80%',
};
```

═══════════════════════════════════════════════════════════════════════════════
## Helper Functions
═══════════════════════════════════════════════════════════════════════════════

```typescript
// lib/agents.ts

import { AGENTS } from '@/data/agents';
import type { Agent, TeamType, AgentStatus } from '@/types';

// Get agents by team
export function getAgentsByTeam(team: TeamType): Agent[] {
  return AGENTS.filter(agent => agent.team === team);
}

// Get agent by ID
export function getAgentById(id: string): Agent | undefined {
  return AGENTS.find(agent => agent.id === id);
}

// Get active agents
export function getActiveAgents(): Agent[] {
  return AGENTS.filter(agent => agent.status === 'active');
}

// Get blocked agents
export function getBlockedAgents(): Agent[] {
  return AGENTS.filter(agent => agent.status === 'blocked');
}

// Count agents by status
export function countByStatus(): Record<AgentStatus, number> {
  return AGENTS.reduce((acc, agent) => {
    acc[agent.status] = (acc[agent.status] || 0) + 1;
    return acc;
  }, {} as Record<AgentStatus, number>);
}

// Get team statistics
export function getTeamStats(team: TeamType) {
  const teamAgents = getAgentsByTeam(team);
  return {
    total: teamAgents.length,
    active: teamAgents.filter(a => a.status === 'active').length,
    blocked: teamAgents.filter(a => a.status === 'blocked').length,
    averageProgress: teamAgents.reduce((sum, a) => sum + a.progress, 0) / teamAgents.length,
  };
}
```

