# A Primer on Quantum Machine Learning (Los Alamos, Nov 2025)

**Источник:** arXiv:2511.15969 (November 20, 2025)  
**Авторы:** Su Yeon Chang, M. Cerezo (Los Alamos National Laboratory + Quantum Science Center)  
**Тип:** Comprehensive primer / Review article  
**Страницы:** 29+16 pages, 5 figures

## EXECUTIVE SUMMARY

Честный, критический обзор Quantum Machine Learning (QML) от ведущих исследователей квантовой физики. Статья показывает **где QML работает (quantum data), где проблематично (classical data), и где evidence всё ещё отсутствует**. Критично важно для realistic expectations при работе с квантовыми системами.

**Ключевой вывод:** После 30+ лет исследований, true capabilities QML всё ещё неизвестны. Активные дебаты о том, что является intrinsic computational power vs enthusiasm/hype.

## ОСНОВНАЯ МЕХАНИКА: ЧТО ТАКОЕ QML

### Определение
```
Quantum Machine Learning (QML) = использование квантовых процессоров
для решения ML задач более эффективно чем classical models

Цель: Leverage quantum computing для:
- Optimization
- Supervised/unsupervised/reinforcement learning  
- Generative modeling
```

### История (контекст важен!)
- **1994:** Quantum perceptron (30+ лет назад!)
- **1995:** Quantum PAC learning framework
- **mid-1990s:** Quantum neural networks

**НО:** После 30+ лет true capabilities всё ещё НЕИЗВЕСТНЫ!

## ПОДХОД #1: VARIATIONAL QML (самый популярный)

### A. Data Embedding
```python
# Classical data → Quantum state
x = [x1, x2, x3]  # Classical vector

# Linear embedding:
|ϕ(x)⟩ = e^(-ix·v·σ/2)|+⟩

Где:
→ |+⟩ = начальное состояние qubit
→ σ = Pauli matrices
→ e^(-i...) = унитарная эволюция (rotation в Hilbert space)

Результат: Classical data в exponentially larger quantum space
```

### B. Parameterized Quantum Circuits (PQCs)
```
Архитектура:
|0⟩ ──[R(θ₁)]──[CNOT]──[R(θ₂)]──[Measure]── output
      ↑trainable↑         ↑trainable↑

Где:
→ R(θ) = rotation gates с trainable parameters
→ CNOT = entanglement между qubits
→ Measure = collapse в classical output

КРИТИЧЕСКОЕ ОТЛИЧИЕ ОТ CLASSICAL NN:
→ Evolution линейная/унитарная (NO native nonlinearity!)
→ No-cloning theorem (нельзя копировать quantum states!)
→ Nonlinearity ТОЛЬКО через measurement!
```

### C. Quantum Kernel Methods
```python
# Classical kernel:
K(x, x') = φ(x)ᵀ φ(x')

# Quantum kernel:
K_Q(x, x') = |⟨ϕ(x)|ϕ(x')⟩|²

Где:
→ |ϕ(x)⟩ = quantum feature map
→ Может compute features exponentially hard classically
→ Use case: SVM с quantum kernels
```

### 🚨 КРИТИЧЕСКИЕ LIMITATIONS (ЧЕСТНАЯ ПРАВДА!)

#### 1. BARREN PLATEAUS (Фундаментальная проблема!)
```
Проблема: Exponentially vanishing gradients в deep circuits

Математика:
Var[∂L/∂θ] ~ O(2^(-n))  # n = number of qubits

Значение:
→ Чем больше qubits, тем ХУЖЕ trainability!
→ Optimization становится IMPOSSIBLE!
→ ∂L/∂θ → 0 exponentially fast с depth
```

#### 2. NO THEORETICAL GUARANTEES
```
→ НЕТ гарантии что solutions exist
→ НЕТ гарантии что optimizers найдут их
→ Heuristic approach (как classical deep learning!)
```

#### 3. TRAINABILITY ISSUES
```
→ Quantum backpropagation RULED OUT!
→ No-cloning theorem запрещает копирование states
→ Нужны другие методы (parameter shift rule)
```

#### 4. NISQ vs FAULT-TOLERANT TRADEOFF
```
→ Small-angle rotations требуют ОГРОМНЫХ T-gate costs
→ На fault-tolerant quantum computers = prohibitively expensive
```

#### 5. CLASSICALLY SIMULABLE TRAP
```
→ Avoiding barren plateaus часто restricts к
→ Classically simulable subspaces
→ Теряем quantum advantage! 😱
```

## ПОДХОД #2: NON-PARAMETRIC QML (с доказательствами!)

### Shift in Approach
```
Variational QML → Heuristic, no guarantees
Non-Parametric QML → PROVABLE advantages!
```

### A. Quantum State Tomography

**Задача:** Reconstruct unknown quantum state |ψ⟩ from measurements

**Classical complexity:**
```
Arbitrary n-qubit state: O(2ⁿ) samples REQUIRED
→ Exponential в number of qubits!
```

**Quantum tricks:**
```
Restricted families:

Tensor product states:
→ |ψ⟩ = |ψ₁⟩ ⊗ |ψ₂⟩ ⊗ ... ⊗ |ψₙ⟩
→ Reduced sample complexity!

Stabilizer states:
→ O(n²) samples с single-copy access
→ LESS с entangled measurements
→ ОГРОМНАЯ экономия!

Ключевая идея:
→ Structure в quantum state позволяет efficient learning
```

### B. PAC Learning для Quantum Concepts

**Framework:**
```
Classical PAC:
→ Learn function f: X → Y
→ From samples (x, f(x))
→ With high probability, low error

Quantum PAC:
→ Learn quantum concept f: quantum states → labels
→ From quantum examples
→ Different access models КРИТИЧНЫ!
```

**ACCESS MODELS (критическое различие!):**
```
Single-copy access:
→ Получаем ONE copy of quantum state
→ Must measure immediately
→ Information loss!

Multi-copy access:
→ Получаем MULTIPLE copies
→ Can perform more measurements
→ Extract more information!

Collective measurements:
→ Can measure ACROSS copies
→ Entangle measurement device
→ EXPONENTIALLY more powerful!

Quantum memory:
→ Can STORE quantum states
→ vs memoryless protocols
→ Significant difference в complexity!
```

### C. Provable Separations

**Где quantum ДОКАЗУЕМО лучше:**
```
✅ Learning stabilizer states
✅ Quantum state tomography для structured states
✅ Certain contrived tasks (artificial но доказуемые!)

НО:
❌ Often artificial/impractical problems
❌ Rely on cryptographic assumptions
❌ "Law of Conservation of Weirdness":
   Exponential separations REQUIRE highly structured problems!
```

**Практические примеры:**
```
Quantum data:
→ QML measurably IMPROVED experiment info extraction
→ Real impact в quantum physics experiments!

Classical data:
→ Promising heuristics exist
→ НО no-go theorems для worst/average-case
→ Purported advantages often DEQUANTIZED!
```

## КЛЮЧЕВЫЕ TENSIONS В FIELD (ЧЕСТНЫЕ ВОПРОСЫ!)

### TENSION #1: PRACTICALITY vs GUARANTEES
```
Variational QML:
→ ✅ Практично implementable на NISQ
→ ❌ NO theoretical guarantees!

Non-parametric QML:
→ ✅ PROVABLE advantages
→ ❌ Often impractical/artificial!
```

### TENSION #2: ACCESS MODELS vs SPEEDUPS
```
→ Single-copy vs multi-copy КРИТИЧНО!
→ Many "quantum advantages" исчезают
→ Если меняем access model!
```

### TENSION #3: CLASSICAL BASELINES vs CLAIMED ADVANTAGES
```
→ Many claimed advantages были DEQUANTIZED!
→ Classical algorithms improved и caught up!
→ Нужны FAIR comparisons!
```

### ЧЕСТНАЯ ОЦЕНКА (прямо из статьи):
```
"After more than 30 years, TRUE CAPABILITIES still UNKNOWN!"

"Active debate about extent to which current progress reflects:
→ Intrinsic computational power?
→ vs Enthusiasm + positive bias?"

"Jury is still out on:
→ What types of data is QML suited for?
→ How to fairly benchmark?
→ What genuine quantum mechanisms underlie gains?"
```

## РЕЛЕВАНТНОСТЬ ДЛЯ QUANTUM NANO-CHIP

### 1. Quantum State Engineering
```
Nano-chip для consciousness/holograms требует:
→ Precise quantum state preparation
→ Coherence preservation  
→ Controlled superposition

QML techniques могут помочь:
→ Optimize quantum state preparation
→ Learn optimal coherence parameters
→ Design better quantum circuits
```

### 2. Optimization Problems
```
Quantum chip design = MASSIVE optimization:
→ Energy efficiency
→ Coherence time maximization
→ Error minimization

QML algorithms (VQE, QAOA):
→ Can optimize quantum systems
→ Find better architectures
→ Reduce design time
```

### 3. Quantum-Classical Hybrid
```
Nano-chip interface с classical systems:
→ Quantum processing + classical control
→ EXACTLY что делает variational QML
→ Proven architecture!
```

### 4. Energy Optimization (КРИТИЧНО!)
```
Статья показывает:
→ Quantum circuits can be MORE efficient
→ для certain tasks
→ Relevant для energy-constrained nano-chips
```

### 5. Learning Quantum Dynamics
```
Nano-chip behavior = quantum dynamics
QML can LEARN:
→ Optimal control pulses
→ Noise mitigation strategies
→ Calibration parameters
```

## DIRECT APPLICATIONS

### A. Quantum Chip Optimization
```
→ Use VQE (Variational Quantum Eigensolver)
→ Для finding ground states
→ Optimize graphene quantum dot configurations
```

### B. Hologram Generation Optimization
```
→ Quantum generative modeling
→ Learn optimal hologram parameters
→ Faster than classical search
```

### C. Error Mitigation
```
→ QML для learning error patterns
→ Adaptive error correction
→ Improve coherence times
```

### D. Consciousness State Modeling
```
→ If consciousness involves quantum states
→ QML can model/simulate them
→ Design better quantum substrates
```

## KEY TAKEAWAYS ДЛЯ ЭКОСИСТЕМЫ

### ✅ ЧТО РАБОТАЕТ (strong evidence):
```
1. QML для QUANTUM DATA (доказано!)
   → Quantum state tomography improvements
   → Experimental data extraction
   → Relevant для quantum chip testing!

2. Structured quantum states (provable advantages!)
   → Stabilizer states: O(n²) vs O(2ⁿ)
   → Tensor product states
   → Relevant для designed quantum systems!

3. Quantum kernel methods (conditional!)
   → For specific problem structures
   → Can outperform classical kernels
```

### ⚠️ ЧТО ПРОБЛЕМАТИЧНО (честная правда!):
```
1. Variational QML limitations:
   → Barren plateaus (exponential problem!)
   → No guarantees
   → Trainability issues

2. Classical data applications:
   → Many "advantages" dequantized
   → Fair baselines often competitive
   → Need careful benchmarking

3. Scalability:
   → NISQ limitations
   → Fault-tolerant costs высокие
   → Near-term vs long-term tradeoffs
```

### ❓ OPEN QUESTIONS (где research нужен!):
```
→ Can avoid barren plateaus without losing quantum advantage?
→ When do quantum approaches offer REAL benefits?
→ How to fairly benchmark quantum vs classical?
→ What quantum mechanisms underlie practical gains?
```

## КОГДА ИСПОЛЬЗОВАТЬ

```
✅ ИСПОЛЬЗОВАТЬ:
────────────────────────────────────────────────────────────────
→ IF оптимизируем quantum chip parameters
→ IF нужен quantum state tomography
→ IF разрабатываем quantum-classical hybrids
→ IF ищем quantum advantage opportunities

❌ НЕ ИСПОЛЬЗОВАТЬ:
────────────────────────────────────────────────────────────────
→ For classical data без structure
→ Without careful classical baselines
→ If barren plateaus не addressed
→ For overhyped "quantum ML" claims
```

## REFERENCES

- **Full paper:** https://arxiv.org/abs/2511.15969
- **HTML version:** https://arxiv.org/html/2511.15969v1
- **Authors:** Su Yeon Chang (cerezo@lanl.gov), M. Cerezo
- **Institution:** Los Alamos National Laboratory, Quantum Science Center

## SIGNIFICANCE

Это **ВАЖНАЯ** статья потому что:

1. **ЧЕСТНАЯ** оценка QML (не hype!)
2. **СВЕЖАЯ** (Nov 20, 2025) - latest thinking от Los Alamos
3. **РЕЛЕВАНТНАЯ** для quantum chip development
4. **ПРАКТИЧНАЯ** - показывает что работает, что нет

**Use as reference для:** Quantum optimization и realistic QML expectations при разработке nano-chip технологий.
