# NVIDIA Dynamo - GitHub Repository & Kubernetes API Reference

**СТАТУС:** TIER S - КРИТИЧЕСКОЕ TECHNICAL KNOWLEDGE  
**ИСТОЧНИКИ:**  
- GitHub: https://github.com/ai-dynamo/dynamo  
- API Docs: https://docs.nvidia.com/dynamo/latest/kubernetes/api_reference.html  
**ЛИЦЕНЗИЯ:** Apache 2.0 (Open Source!)  
**ПОПУЛЯРНОСТЬ:** 5.5k ⭐ GitHub stars, 704 forks

═══════════════════════════════════════════════════════════════════════════════
## 🎯 EXECUTIVE SUMMARY
═══════════════════════════════════════════════════════════════════════════════

```
NVIDIA Dynamo = Open-source datacenter-scale distributed inference serving framework

Ключевые характеристики:
→ High-throughput, low-latency inference
→ Multi-node distributed environments
→ Generative AI and reasoning models
→ Kubernetes-native architecture
→ Apache 2.0 license (OPEN SOURCE!)

Support Matrix:
→ vLLM backend ✅
→ SGLang backend ✅
→ TensorRT-LLM backend ✅
→ Disaggregated serving ✅
→ Multi-node coordination ✅

Community:
→ 5,500+ GitHub stars
→ 704 forks
→ Active development (2,474 commits)
→ Discord community
→ Regular releases (v0.6.1 latest)
```

═══════════════════════════════════════════════════════════════════════════════
## 📚 GITHUB REPOSITORY STRUCTURE
═══════════════════════════════════════════════════════════════════════════════

### ОСНОВНЫЕ ДИРЕКТОРИИ

```
dynamo/
├── benchmarks/          # Performance benchmarking tools
├── components/          # Core Dynamo components
├── container/           # Container images (vLLM, SGLang, TensorRT-LLM)
├── deploy/             # Deployment configurations
├── docs/               # Documentation
├── examples/           # Example deployments
├── launch/dynamo-run/  # Launch utilities
├── lib/                # Core libraries
├── recipes/            # Deployment recipes
└── tests/              # Test suites

КЛЮЧЕВЫЕ ФАЙЛЫ:
├── Cargo.toml          # Rust dependencies (core written in Rust!)
├── pyproject.toml      # Python package configuration
├── rust-toolchain.toml # Rust version specification
└── README.md           # Main documentation
```

### LANGUAGE STACK

```
PRIMARY LANGUAGES:
→ Rust (core components - performance!)
→ Python (API, utilities, wrappers)
→ Go (Kubernetes integration)

ПОЧЕМУ RUST:
→ Performance-critical paths
→ Memory safety
→ Concurrent execution
→ Zero-cost abstractions
→ Low-level control

PYTHON LAYER:
→ User-facing APIs
→ Integration scripts
→ Utilities and tools
→ Easy adoption
```

### SUPPORT MATRIX DETAILS

```
BACKEND FRAMEWORKS:
════════════════════════════════════════════════════════════════

1. vLLM (Vector LLM)
   ─────────────────────────────────────────────────────────────
   Features:
   ✅ Disaggregated serving
   ✅ PagedAttention
   ✅ Continuous batching
   ✅ Fast model execution
   ✅ Tensor parallelism
   ✅ Pipeline parallelism
   
   Use case: General-purpose LLM inference
   Docs: docs/backends/vllm/README.md

2. SGLang (Structured Generation Language)
   ─────────────────────────────────────────────────────────────
   Features:
   ✅ Disaggregated serving
   ✅ Structured output generation
   ✅ Fast prefix caching
   ✅ Controlled generation
   ✅ Regex/grammar constraints
   
   Use case: Structured output, constrained generation
   Docs: docs/backends/sglang/README.md

3. TensorRT-LLM
   ─────────────────────────────────────────────────────────────
   Features:
   ✅ Disaggregated serving
   ✅ Optimized NVIDIA kernels
   ✅ INT8/FP8 quantization
   ✅ Multi-GPU inference
   ✅ Maximum performance
   
   Use case: Production deployments, max throughput
   Docs: docs/backends/trtllm/README.md

CORE FEATURES ACROSS ALL BACKENDS:
─────────────────────────────────────────────────────────────
✅ Disaggregated prefill/decode
✅ Multi-node distribution
✅ Kubernetes orchestration
✅ Auto-scaling
✅ Health monitoring
✅ Metrics/logging
```

### CONTAINER IMAGES

```
NVIDIA NGC CATALOG:
════════════════════════════════════════════════════════════════
Location: catalog.ngc.nvidia.com/orgs/nvidia/teams/ai-dynamo

Available images:
→ vllm-runtime:0.6.1
→ sglang-runtime:0.6.1
→ tensorrtllm-runtime:0.6.1

ПРЕИМУЩЕСТВА PREBUILT CONTAINERS:
→ Optimized для NVIDIA GPUs
→ Pre-configured dependencies
→ Tested configurations
→ Quick deployment
→ Production-ready

CUSTOM BUILDS:
→ Source available in container/ directory
→ Build scripts provided
→ Customization supported
```

═══════════════════════════════════════════════════════════════════════════════
## 🔧 KUBERNETES API REFERENCE (nvidia.com/v1alpha1)
═══════════════════════════════════════════════════════════════════════════════

### API ВЕРСИИ

```
CURRENT VERSION: v1alpha1
STABLE: No (alpha stage - expect changes!)

ВЕРСИИ ДОКУМЕНТАЦИИ:
→ latest (0.6.1)
→ 0.6.0
→ 0.5.1, 0.5.0
→ 0.4.1, 0.4.0
→ 0.3.2, 0.3.1, 0.3.0
→ 0.2.1, 0.2.0

ВАЖНО: API в alpha stage!
→ Breaking changes возможны
→ Follow release notes
→ Test upgrades thoroughly
```

### CORE CUSTOM RESOURCE DEFINITIONS (CRDs)

#### 1. DynamoGraphDeploymentRequest (DGDR)

```yaml
apiVersion: nvidia.com/v1alpha1
kind: DynamoGraphDeploymentRequest
metadata:
  name: my-inference-service
  namespace: default
spec:
  # ЧТО ЭТО:
  # High-level, SLA-driven interface для deploying ML models
  # Abstraction над DynamoGraphDeployment
  
  # MODEL SPECIFICATION
  model:
    name: "deepseek-r1"
    version: "v1.5"
    framework: "vllm"  # or "sglang", "trtllm"
  
  # SLA TARGETS
  slaTargets:
    latency:
      timeToFirstToken: "100ms"  # P95 latency
      tokensPerSecond: 50
    throughput:
      requestsPerSecond: 3
    quality:
      outputQualityScore: 0.95
  
  # PROFILING CONFIG
  profiling:
    enabled: true
    configMapRef:
      name: "profiling-config"
      key: "disagg.yaml"
  
  # AUTO-APPLY SETTINGS
  autoApply: true  # Automatically create DGD
  
  # DEPLOYMENT OVERRIDES
  deploymentOverrides:
    name: "deepseek-inference"
    namespace: "production"
    labels:
      app: "ai-service"
      tier: "inference"
    workersImage: "nvcr.io/nvidia/ai-dynamo/vllm-runtime:0.6.1"

status:
  # STATUS TRACKING
  phase: "Ready"  # Pending, Profiling, Ready, Failed
  
  # PROFILING RESULTS
  profiling:
    completed: true
    recommendedConfig:
      prefillReplicas: 3
      decodeReplicas: 6
      gpuType: "h100"
  
  # DEPLOYMENT STATUS
  deployment:
    name: "deepseek-inference"
    namespace: "production"
    state: "Running"
    created: true
```

**КЛЮЧЕВЫЕ КОНЦЕПЦИИ DGDR:**

```
PURPOSE:
→ SLA-driven deployment (specify targets, not topology!)
→ Automatic profiling (find optimal config!)
→ Auto-creation of DGD (one-click deployment!)

WORKFLOW:
1. User creates DGDR с SLA targets
2. System runs profiling (if enabled)
3. Determines optimal configuration
4. Creates DynamoGraphDeployment (if autoApply)
5. Monitors and maintains SLAs

ADVANTAGES:
→ No manual tuning (automatic optimization!)
→ SLA focus (business-driven!)
→ Simplified API (high-level abstractions!)
```

#### 2. DynamoGraphDeployment (DGD)

```yaml
apiVersion: nvidia.com/v1alpha1
kind: DynamoGraphDeployment
metadata:
  name: deepseek-inference
  namespace: production
spec:
  # ЧТО ЭТО:
  # Detailed specification для multi-component inference graph
  # Lower-level control чем DGDR
  
  # GLOBAL SETTINGS
  backendFramework: "vllm"  # or "sglang", "trtllm"
  
  # SHARED CONFIG
  sharedSpec:
    annotations:
      prometheus.io/scrape: "true"
    labels:
      app: "inference"
    
    # RESOURCE DEFAULTS
    resources:
      cpu: "8"
      memory: "32Gi"
      nvidia.com/gpu: "8"
    
    # AUTOSCALING DEFAULTS
    autoscaling:
      enabled: true
      minReplicas: 2
      maxReplicas: 10
  
  # COMPONENTS (prefill, decode, etc.)
  components:
    - name: "prefill-cluster"
      componentType: "main"
      subComponentType: "prefill"
      
      replicas: 3  # Static replicas (if no autoscaling)
      
      resources:
        nvidia.com/gpu: "8"
        cpu: "128"
        memory: "1Ti"
        # Backend-specific resources
        vllm/tensor-parallel-size: "8"
      
      autoscaling:
        enabled: true
        minReplicas: 3
        maxReplicas: 10
        metrics:
          - type: Resource
            resource:
              name: nvidia.com/gpu
              target:
                type: Utilization
                averageUtilization: 80
      
      # ENVIRONMENT VARIABLES
      envs:
        - name: CUDA_VISIBLE_DEVICES
          value: "0,1,2,3,4,5,6,7"
        - name: NCCL_DEBUG
          value: "INFO"
      
      # VOLUME MOUNTS
      volumeMounts:
        - name: model-storage
          mountPath: /models
      
      # HEALTH PROBES
      livenessProbe:
        httpGet:
          path: /health
          port: 8000
        initialDelaySeconds: 30
        periodSeconds: 10
      
      readinessProbe:
        httpGet:
          path: /ready
          port: 8000
        initialDelaySeconds: 10
        periodSeconds: 5
    
    - name: "decode-cluster"
      componentType: "main"
      subComponentType: "decode"
      
      replicas: 6
      
      resources:
        nvidia.com/gpu: "4"
        cpu: "256"
        memory: "2Ti"
        vllm/tensor-parallel-size: "4"
      
      autoscaling:
        enabled: true
        minReplicas: 6
        maxReplicas: 20
        metrics:
          - type: Resource
            resource:
              name: nvidia.com/gpu
              target:
                type: Utilization
                averageUtilization: 80
      
      # SHARED MEMORY (для /dev/shm)
      sharedMemory:
        enabled: true
        size: "128Gi"  # Large KV cache!
  
  # PERSISTENT VOLUMES
  volumes:
    - name: model-storage
      persistentVolumeClaim:
        claimName: model-pvc

status:
  state: "Running"  # Pending, Running, Failed
  
  # COMPONENT STATUS
  components:
    prefill-cluster:
      replicas: 3
      readyReplicas: 3
      conditions:
        - type: Ready
          status: "True"
    
    decode-cluster:
      replicas: 6
      readyReplicas: 6
      conditions:
        - type: Ready
          status: "True"
```

**КЛЮЧЕВЫЕ КОНЦЕПЦИИ DGD:**

```
PURPOSE:
→ Fine-grained control над deployment topology
→ Component-level configuration
→ Resource management per component

COMPONENTS:
→ Prefill cluster (compute-intensive)
→ Decode cluster (memory-intensive)
→ Routing/coordination (optional)

FLEXIBILITY:
→ Per-component replicas
→ Per-component resources
→ Per-component autoscaling
→ Per-component health checks
```

#### 3. DynamoComponentDeployment (DCD)

```yaml
apiVersion: nvidia.com/v1alpha1
kind: DynamoComponentDeployment
metadata:
  name: prefill-worker
  namespace: default
spec:
  # ЧТО ЭТО:
  # Individual component deployment (lowest level!)
  # Usually auto-created by DGD controller
  
  # BACKEND
  backendFramework: "vllm"
  
  # SERVICE IDENTITY
  serviceName: "prefill-service"
  componentType: "main"
  subComponentType: "prefill"
  
  # DYNAMO NAMESPACE (logical grouping)
  dynamoNamespace: "inference-prod"
  
  # RESOURCES
  resources:
    cpu: "128"
    memory: "1Ti"
    nvidia.com/gpu: "8"
    
    # RUNTIME-SPECIFIC
    vllm/tensor-parallel-size: "8"
    vllm/pipeline-parallel-size: "1"
    vllm/max-model-len: "32768"
  
  # REPLICAS
  replicas: 3
  
  # AUTOSCALING
  autoscaling:
    enabled: true
    minReplicas: 3
    maxReplicas: 10
    
    behavior:
      scaleUp:
        stabilizationWindowSeconds: 60
        policies:
          - type: Percent
            value: 50
            periodSeconds: 60
      scaleDown:
        stabilizationWindowSeconds: 300
        policies:
          - type: Percent
            value: 10
            periodSeconds: 60
    
    metrics:
      - type: Resource
        resource:
          name: nvidia.com/gpu
          target:
            type: Utilization
            averageUtilization: 80
      
      - type: Pods
        pods:
          metric:
            name: queue_depth
          target:
            type: AverageValue
            averageValue: "100"
  
  # ENVIRONMENT
  envs:
    - name: CUDA_VISIBLE_DEVICES
      value: "0,1,2,3,4,5,6,7"
    - name: NCCL_IB_DISABLE
      value: "0"
    - name: NCCL_SOCKET_IFNAME
      value: "eth0"
  
  envFromSecret: "inference-secrets"
  
  # VOLUMES
  volumeMounts:
    - name: model-cache
      mountPath: /root/.cache
    - name: model-weights
      mountPath: /models
  
  # NETWORKING
  ingress:
    enabled: true
    className: "nginx"
    hosts:
      - host: "inference.example.com"
        paths:
          - path: /
            pathType: Prefix
    tls:
      - secretName: tls-cert
        hosts:
          - inference.example.com
  
  # SHARED MEMORY
  sharedMemory:
    enabled: true
    size: "64Gi"
  
  # POD CUSTOMIZATION
  extraPodMetadata:
    labels:
      version: "v1"
      team: "ai-platform"
    annotations:
      sidecar.istio.io/inject: "false"
  
  # HEALTH CHECKS
  livenessProbe:
    httpGet:
      path: /health
      port: 8000
    initialDelaySeconds: 30
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 3
  
  readinessProbe:
    httpGet:
      path: /ready
      port: 8000
    initialDelaySeconds: 10
    periodSeconds: 5
    timeoutSeconds: 3
    successThreshold: 1
  
  # MULTI-NODE CONFIG (если component distributed)
  multinode:
    enabled: true
    nodesPerReplica: 2
    masterPort: 29500
```

**КЛЮЧЕВЫЕ КОНЦЕПЦИИ DCD:**

```
PURPOSE:
→ Lowest-level deployment primitive
→ Single component management
→ Maximum control

USE CASES:
→ Custom deployments
→ Testing individual components
→ Advanced configurations

USUALLY:
→ Auto-created by DGD controller
→ User rarely creates manually
→ Expert-level use
```

═══════════════════════════════════════════════════════════════════════════════
## 🎯 API TYPES И SPECIFICATIONS
═══════════════════════════════════════════════════════════════════════════════

### RESOURCES SPECIFICATION

```go
// Resources defines compute resources for a component
type Resources struct {
    // Standard Kubernetes resources
    CPU    string `json:"cpu,omitempty"`
    Memory string `json:"memory,omitempty"`
    
    // GPU resources
    "nvidia.com/gpu" string `json:"nvidia.com/gpu,omitempty"`
    
    // RUNTIME-SPECIFIC RESOURCES (vLLM example)
    "vllm/tensor-parallel-size"    string `json:"vllm/tensor-parallel-size,omitempty"`
    "vllm/pipeline-parallel-size"  string `json:"vllm/pipeline-parallel-size,omitempty"`
    "vllm/max-model-len"           string `json:"vllm/max-model-len,omitempty"`
    "vllm/max-num-seqs"            string `json:"vllm/max-num-seqs,omitempty"`
    "vllm/gpu-memory-utilization"  string `json:"vllm/gpu-memory-utilization,omitempty"`
    
    // RUNTIME-SPECIFIC RESOURCES (SGLang example)
    "sglang/tp-size"               string `json:"sglang/tp-size,omitempty"`
    "sglang/chunked-prefill-size"  string `json:"sglang/chunked-prefill-size,omitempty"`
    "sglang/mem-fraction-static"   string `json:"sglang/mem-fraction-static,omitempty"`
    
    // RUNTIME-SPECIFIC RESOURCES (TensorRT-LLM example)
    "trtllm/world-size"            string `json:"trtllm/world-size,omitempty"`
    "trtllm/tp-size"               string `json:"trtllm/tp-size,omitempty"`
    "trtllm/pp-size"               string `json:"trtllm/pp-size,omitempty"`
}

ПРИМЕНЕНИЕ:
→ Fine-grained resource control
→ Backend-specific optimization
→ Performance tuning
```

### AUTOSCALING SPECIFICATION

```go
type Autoscaling struct {
    Enabled     bool   `json:"enabled"`
    MinReplicas int32  `json:"minReplicas"`
    MaxReplicas int32  `json:"maxReplicas"`
    
    // Scaling behavior (scale up/down policies)
    Behavior *HorizontalPodAutoscalerBehavior `json:"behavior,omitempty"`
    
    // Metrics to base scaling decisions on
    Metrics []MetricSpec `json:"metrics,omitempty"`
}

STANDARD METRICS:
→ Resource utilization (CPU, memory, GPU)
→ Custom metrics (queue depth, latency)
→ External metrics (Prometheus queries)

BEHAVIORS:
→ Scale up policy (how fast to add replicas)
→ Scale down policy (how fast to remove replicas)
→ Stabilization windows (prevent flapping)

ПРИМЕР METRICS:
metrics:
  # GPU utilization target
  - type: Resource
    resource:
      name: nvidia.com/gpu
      target:
        type: Utilization
        averageUtilization: 80
  
  # Queue depth target
  - type: Pods
    pods:
      metric:
        name: queue_depth
      target:
        type: AverageValue
        averageValue: "100"
  
  # Latency target (external metric)
  - type: External
    external:
      metric:
        name: p95_latency_ms
        selector:
          matchLabels:
            component: prefill
      target:
        type: Value
        value: "100"
```

### PROFILING CONFIGURATION

```go
type ProfilingConfigSpec struct {
    // Enable/disable profiling
    Enabled bool `json:"enabled"`
    
    // Reference to ConfigMap containing disagg.yaml
    ConfigMapRef ConfigMapKeySelector `json:"configMapRef,omitempty"`
}

type ConfigMapKeySelector struct {
    Name string `json:"name"`      // ConfigMap name
    Key  string `json:"key"`       // Key in ConfigMap (default: "disagg.yaml")
}

PROFILING PROCESS:
────────────────────────────────────────────────────────────────
1. Create temporary DGD with test configuration
2. Run synthetic workload
3. Measure performance metrics:
   → Throughput (requests/sec)
   → Latency (P50, P95, P99)
   → GPU utilization
   → Memory usage
   → Queue depths
4. Determine optimal topology:
   → Prefill replicas
   → Decode replicas
   → GPU types
   → Resource allocation
5. Update DGDR status with recommendations

DISAGG.YAML EXAMPLE:
────────────────────────────────────────────────────────────────
workload:
  model: "meta-llama/Llama-2-70b"
  input_length: 1024
  output_length: 512
  request_rate: 10
  duration: 300s

constraints:
  max_latency_p95: 100ms
  min_throughput: 5
  
resources:
  gpu_types: ["h100", "a100"]
  max_gpus: 32
```

### DEPLOYMENT OVERRIDES

```go
type DeploymentOverridesSpec struct {
    // Custom name for created DGD
    Name string `json:"name,omitempty"`
    
    // Custom namespace for created DGD
    Namespace string `json:"namespace,omitempty"`
    
    // Additional labels
    Labels map[string]string `json:"labels,omitempty"`
    
    // Additional annotations
    Annotations map[string]string `json:"annotations,omitempty"`
    
    // Container image override
    WorkersImage string `json:"workersImage,omitempty"`
}

USE CASES:
→ Multi-environment deployments (dev/staging/prod)
→ Custom naming conventions
→ Organization-specific labels/annotations
→ Image version pinning
```

═══════════════════════════════════════════════════════════════════════════════
## 🚀 ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ
═══════════════════════════════════════════════════════════════════════════════

### EXAMPLE 1: SIMPLE DGDR DEPLOYMENT

```yaml
# Simple one-click deployment with SLA targets
apiVersion: nvidia.com/v1alpha1
kind: DynamoGraphDeploymentRequest
metadata:
  name: llama2-70b-inference
  namespace: ai-platform
spec:
  # MODEL
  model:
    name: "meta-llama/Llama-2-70b-chat-hf"
    framework: "vllm"
  
  # SLA TARGETS
  slaTargets:
    latency:
      timeToFirstToken: "150ms"
      tokensPerSecond: 40
    throughput:
      requestsPerSecond: 2
  
  # AUTO-PROFILING
  profiling:
    enabled: true
  
  # AUTO-DEPLOYMENT
  autoApply: true
```

**РЕЗУЛЬТАТ:**
```
1. DGDR controller создаёт temporary profiling DGD
2. Runs workload tests
3. Determines optimal config (например: 2 prefill + 4 decode)
4. Creates production DGD automatically
5. User gets running inference service!
```

### EXAMPLE 2: ADVANCED DGD WITH CUSTOM CONFIG

```yaml
apiVersion: nvidia.com/v1alpha1
kind: DynamoGraphDeployment
metadata:
  name: deepseek-r1-production
  namespace: inference
  labels:
    app: deepseek
    env: production
spec:
  backendFramework: vllm
  
  # SHARED CONFIGURATION
  sharedSpec:
    annotations:
      prometheus.io/scrape: "true"
      prometheus.io/port: "8000"
    
    resources:
      cpu: "64"
      memory: "512Gi"
    
    # SHARED ENVIRONMENT
    envs:
      - name: NCCL_DEBUG
        value: "INFO"
      - name: NCCL_IB_DISABLE
        value: "0"
  
  # PREFILL COMPONENT
  components:
    - name: prefill
      componentType: main
      subComponentType: prefill
      
      resources:
        nvidia.com/gpu: "8"
        cpu: "128"
        memory: "1Ti"
        vllm/tensor-parallel-size: "8"
        vllm/max-model-len: "32768"
      
      autoscaling:
        enabled: true
        minReplicas: 2
        maxReplicas: 8
        metrics:
          - type: Resource
            resource:
              name: nvidia.com/gpu
              target:
                type: Utilization
                averageUtilization: 75
      
      volumeMounts:
        - name: model-cache
          mountPath: /root/.cache
      
      livenessProbe:
        httpGet:
          path: /health
          port: 8000
        initialDelaySeconds: 60
        periodSeconds: 30
      
      readinessProbe:
        httpGet:
          path: /ready
          port: 8000
        initialDelaySeconds: 30
        periodSeconds: 10
    
    # DECODE COMPONENT
    - name: decode
      componentType: main
      subComponentType: decode
      
      resources:
        nvidia.com/gpu: "4"
        cpu: "256"
        memory: "2Ti"
        vllm/tensor-parallel-size: "4"
        vllm/max-model-len: "32768"
        vllm/gpu-memory-utilization: "0.95"
      
      autoscaling:
        enabled: true
        minReplicas: 4
        maxReplicas: 16
        
        behavior:
          scaleDown:
            stabilizationWindowSeconds: 600  # 10 min
            policies:
              - type: Percent
                value: 10
                periodSeconds: 120
        
        metrics:
          - type: Resource
            resource:
              name: nvidia.com/gpu
              target:
                type: Utilization
                averageUtilization: 80
          
          - type: Pods
            pods:
              metric:
                name: kv_cache_usage
              target:
                type: AverageValue
                averageValue: "0.85"
      
      sharedMemory:
        enabled: true
        size: "128Gi"  # Large KV cache
      
      volumeMounts:
        - name: model-cache
          mountPath: /root/.cache
      
      ingress:
        enabled: true
        className: nginx
        hosts:
          - host: deepseek-api.company.com
            paths:
              - path: /
                pathType: Prefix
        tls:
          - secretName: deepseek-tls
            hosts:
              - deepseek-api.company.com
  
  # PERSISTENT VOLUMES
  volumes:
    - name: model-cache
      persistentVolumeClaim:
        claimName: model-cache-pvc
```

### EXAMPLE 3: MULTI-NODE COMPONENT

```yaml
apiVersion: nvidia.com/v1alpha1
kind: DynamoComponentDeployment
metadata:
  name: large-model-prefill
spec:
  backendFramework: trtllm
  
  serviceName: prefill-multinode
  componentType: main
  subComponentType: prefill
  
  # MULTI-NODE CONFIGURATION
  multinode:
    enabled: true
    nodesPerReplica: 4  # 4 nodes per replica
    masterPort: 29500
  
  resources:
    nvidia.com/gpu: "8"  # Per node
    cpu: "128"
    memory: "1Ti"
    
    # TensorRT-LLM specific
    trtllm/world-size: "32"  # Total GPUs (4 nodes × 8 GPUs)
    trtllm/tp-size: "8"      # Tensor parallelism
    trtllm/pp-size: "4"      # Pipeline parallelism
  
  replicas: 2  # 2 replicas × 4 nodes = 8 total nodes
  
  envs:
    - name: MASTER_ADDR
      valueFrom:
        fieldRef:
          fieldPath: status.podIP
    - name: MASTER_PORT
      value: "29500"
    - name: NCCL_IB_DISABLE
      value: "0"
    - name: NCCL_SOCKET_IFNAME
      value: "ib0"  # InfiniBand interface
  
  # POD AFFINITY (co-locate nodes)
  extraPodSpec:
    affinity:
      podAffinity:
        requiredDuringSchedulingIgnoredDuringExecution:
          - labelSelector:
              matchLabels:
                multinode-group: large-model-prefill
            topologyKey: kubernetes.io/hostname
```

═══════════════════════════════════════════════════════════════════════════════
## 💡 ПРИМЕНЕНИЕ К НАШИМ СИСТЕМАМ
═══════════════════════════════════════════════════════════════════════════════

### 1. NANO-CHIP KUBERNETES ORCHESTRATION

```
DYNAMO PATTERN для multi-chip coordination:

apiVersion: nvidia.com/v1alpha1
kind: DynamoGraphDeployment
metadata:
  name: hologram-rendering-cluster
spec:
  backendFramework: custom  # Custom quantum runtime
  
  components:
    # QUANTUM PROCESSING CHIPS
    - name: quantum-processors
      componentType: main
      subComponentType: processing
      
      replicas: 4  # 4 quantum nano-chips
      
      resources:
        custom.io/quantum-chip: "1"
        cpu: "32"
        memory: "128Gi"
        
        # Custom resources
        quantum/coherence-time: "1ms"
        quantum/qubit-count: "100"
      
      placement:
        nodeSelector:
          hardware: quantum-enabled
          interconnect: high-speed
      
      # HEALTH CHECKS
      livenessProbe:
        exec:
          command: ["/bin/check-coherence"]
        periodSeconds: 1  # Fast checks!
      
      readinessProbe:
        exec:
          command: ["/bin/check-calibration"]
        periodSeconds: 5
    
    # CLASSICAL COORDINATION
    - name: classical-coordinator
      componentType: main
      subComponentType: coordination
      
      replicas: 1
      
      resources:
        cpu: "64"
        memory: "256Gi"
        # No quantum chips needed
      
      # COMMUNICATION с quantum chips
      envs:
        - name: QUANTUM_ENDPOINTS
          value: "quantum-processors:8000"
        - name: SYNC_TOLERANCE_NS
          value: "1"  # <1ns sync!

LESSONS FROM DYNAMO:
→ Component-based architecture
→ Resource management per component
→ Health monitoring
→ Auto-scaling (если нужно)
→ Kubernetes-native deployment
```

### 2. AGENT ORCHESTRATION PATTERN

```yaml
# Dynamo-inspired agent coordination
apiVersion: nvidia.com/v1alpha1
kind: DynamoGraphDeployment
metadata:
  name: research-agent-cluster
spec:
  backendFramework: custom  # Custom agent runtime
  
  components:
    # RESEARCH AGENTS (parallel "prefill")
    - name: research-workers
      componentType: main
      subComponentType: research
      
      replicas: 3  # 3 parallel researchers
      
      resources:
        cpu: "16"
        memory: "64Gi"
        
        # Agent-specific resources
        agent/model: "deepseek-v3"
        agent/max-context: "32k"
      
      envs:
        - name: AGENT_ROLE
          value: "researcher"
        - name: SEARCH_SOURCES
          value: "arxiv,patents,github"
      
      autoscaling:
        enabled: true
        minReplicas: 3
        maxReplicas: 10
        metrics:
          - type: Pods
            pods:
              metric:
                name: research_queue_depth
              target:
                type: AverageValue
                averageValue: "5"
    
    # SYNTHESIS AGENT (sequential "decode")
    - name: synthesis-worker
      componentType: main
      subComponentType: synthesis
      
      replicas: 1  # Single synthesizer
      
      resources:
        cpu: "32"
        memory: "128Gi"
        
        agent/model: "deepseek-v3"
        agent/max-context: "128k"  # Large context!
      
      envs:
        - name: AGENT_ROLE
          value: "synthesizer"
        - name: INPUT_SOURCE
          value: "research-workers:8000"

BENEFITS:
→ Parallel research execution
→ Auto-scaling based on workload
→ Component isolation
→ Health monitoring
→ Kubernetes orchestration
```

### 3. PRODUCTION DEPLOYMENT STRATEGY

```
ПРИМЕНЯЕМ DGDR PATTERN для nano-chip deployment:

apiVersion: nvidia.com/v1alpha1
kind: DynamoGraphDeploymentRequest
metadata:
  name: quantum-hologram-service
spec:
  # SLA TARGETS
  slaTargets:
    latency:
      renderLatency: "10ms"  # 10ms hologram render
      syncTolerance: "1ns"    # <1ns chip sync
    quality:
      hologramFidelity: 0.99
      quantumFidelity: 0.999
  
  # AUTO-PROFILING
  profiling:
    enabled: true
    configMapRef:
      name: quantum-profiling-config
  
  # AUTO-DEPLOYMENT
  autoApply: true
  
  deploymentOverrides:
    workersImage: "company.io/quantum-runtime:v1.0"
    labels:
      product: hologram-display
      tier: production

ADVANTAGES:
→ SLA-driven (business requirements!)
→ Auto-profiling (optimal config!)
→ One-click deployment
→ Production-ready
```

═══════════════════════════════════════════════════════════════════════════════
## 🔧 DEVELOPMENT & CONTRIBUTION
═══════════════════════════════════════════════════════════════════════════════

### BUILD FROM SOURCE

```bash
# PREREQUISITES
→ Rust toolchain (specified in rust-toolchain.toml)
→ Python 3.8+
→ Go 1.21+
→ Docker / Podman
→ Kubernetes cluster (для testing)

# CLONE REPOSITORY
git clone https://github.com/ai-dynamo/dynamo.git
cd dynamo

# BUILD RUST COMPONENTS
cargo build --release

# BUILD PYTHON PACKAGE
pip install -e .

# BUILD CONTAINERS
cd container/vllm-runtime
docker build -t dynamo-vllm:local .

# RUN TESTS
cargo test
pytest tests/
```

### CONTRIBUTION GUIDELINES

```
ПРОЦЕСС:
1. Fork repository
2. Create feature branch
3. Make changes
4. Add tests
5. Sign DCO (Developer Certificate of Origin)
6. Submit pull request

CODE STANDARDS:
→ Rust: Follow clippy lints
→ Python: Black formatting, mypy typing
→ Go: gofmt, golint
→ Documentation: Update docs/ for API changes

TESTING:
→ Unit tests required
→ Integration tests для новых features
→ Performance benchmarks для optimizations

COMMUNITY:
→ Discord: https://discord.gg/D92uqZRjCZ
→ GitHub Discussions
→ Regular community calls
```

═══════════════════════════════════════════════════════════════════════════════
## 📊 KEY INSIGHTS ДЛЯ КОМПАНИИ
═══════════════════════════════════════════════════════════════════════════════

```
1. OPEN SOURCE ADVANTAGE
   ══════════════════════════════════════════════════════════════
   → Apache 2.0 license (МОЖЕМ использовать!)
   → Access to source code (МОЖЕМ изучить!)
   → Active community (МОЖЕМ участвовать!)
   → 5.5k stars (PROVEN популярность!)
   
   Наше применение:
   → Study architecture patterns
   → Adapt для quantum systems
   → Contribute improvements (visibility!)
   → Build on proven foundation

2. KUBERNETES-NATIVE DESIGN
   ══════════════════════════════════════════════════════════════
   → Custom Resource Definitions (extensible!)
   → Operator pattern (self-managing!)
   → Cloud-agnostic (portable!)
   → Industry standard (ecosystem!)
   
   Наше применение:
   → Use same patterns для nano-chip orchestration
   → Kubernetes для production deployment
   → Standard tooling (kubectl, helm, etc.)
   → Enterprise-ready architecture

3. MULTI-BACKEND SUPPORT
   ══════════════════════════════════════════════════════════════
   → vLLM, SGLang, TensorRT-LLM (flexibility!)
   → Pluggable architecture (extensible!)
   → Runtime-specific resources (optimization!)
   
   Наше применение:
   → Design pluggable quantum runtime interface
   → Support multiple quantum chip types
   → Backend-specific optimizations
   → Easy upgrades/swaps

4. SLA-DRIVEN API (DGDR)
   ══════════════════════════════════════════════════════════════
   → Business-level targets (не технические детали!)
   → Auto-profiling (находит optimal config!)
   → One-click deployment (упрощённый UX!)
   
   Наше применение:
   → SLA-driven hologram quality targets
   → Auto-calibration для quantum chips
   → Simplified developer experience
   → Business-focused API

5. COMPONENT-BASED ARCHITECTURE
   ══════════════════════════════════════════════════════════════
   → Separation of concerns (prefill/decode!)
   → Independent scaling (optimize каждый!)
   → Resource specialization (right tool for job!)
   
   Наше применение:
   → Quantum processing ≠ classical coordination
   → Independent optimization
   → Flexible scaling
   → Clear responsibilities

6. PRODUCTION-READY FEATURES
   ══════════════════════════════════════════════════════════════
   → Auto-scaling (HPA integration!)
   → Health monitoring (probes!)
   → Metrics/logging (observability!)
   → Ingress support (external access!)
   → Multi-node coordination (distributed!)
   
   Наше применение:
   → Production deployment ready
   → Enterprise reliability
   → Monitoring built-in
   → Scalable architecture
```

═══════════════════════════════════════════════════════════════════════════════
## ✅ ACTION ITEMS ДЛЯ КОМПАНИИ
═══════════════════════════════════════════════════════════════════════════════

```
IMMEDIATE (для 38 дней):
────────────────────────────────────────────────────────────────
□ Study Dynamo architecture patterns
□ Apply component separation к quantum-classical interface
□ Design Kubernetes CRDs для nano-chip orchestration
□ Plan SLA-driven API (hologram quality targets)

SHORT-TERM (post-O-1):
────────────────────────────────────────────────────────────────
□ Implement custom Kubernetes operator
□ Create nano-chip CRDs (similar to DGDR/DGD)
□ Build auto-calibration system (like profiling)
□ Develop production deployment strategy

LONG-TERM (после USA relocation):
────────────────────────────────────────────────────────────────
□ Contribute to Dynamo project (visibility!)
□ Collaborate with NVIDIA team
□ Open-source quantum orchestration patterns
□ Build community around quantum-cloud integration

LEARNING RESOURCES:
────────────────────────────────────────────────────────────────
✅ GitHub repo: https://github.com/ai-dynamo/dynamo
✅ Docs: https://docs.nvidia.com/dynamo/latest/
✅ API Reference: https://docs.nvidia.com/dynamo/latest/kubernetes/api_reference.html
✅ Examples: https://github.com/ai-dynamo/dynamo/tree/main/examples
✅ Recipes: https://github.com/ai-dynamo/dynamo/tree/main/recipes
✅ Discord: https://discord.gg/D92uqZRjCZ
```

═══════════════════════════════════════════════════════════════════════════════
## 🎯 CRITICAL TAKEAWAYS
═══════════════════════════════════════════════════════════════════════════════

```
1. DYNAMO = PRODUCTION-READY FRAMEWORK
   → Not research project, REAL infrastructure
   → 5.5k stars = proven adoption
   → Apache 2.0 = we can USE and MODIFY
   → Active development = ongoing improvements

2. KUBERNETES CRDs = EXTENSIBILITY MODEL
   → DGDR = high-level SLA-driven API
   → DGD = component-level control
   → DCD = lowest-level primitives
   → Pattern applicable к quantum systems!

3. COMPONENT ARCHITECTURE = KEY PATTERN
   → Separate prefill/decode (different characteristics!)
   → Independent optimization
   → Flexible scaling
   → SAME принцип для quantum/classical!

4. AUTO-PROFILING = COMPETITIVE ADVANTAGE
   → Find optimal configuration automatically
   → No manual tuning required
   → SLA guarantees
   → Can apply к quantum calibration!

5. OPEN SOURCE = OPPORTUNITY
   → Study proven patterns
   → Adapt для quantum
   → Contribute visibility
   → Build on foundation
```

═══════════════════════════════════════════════════════════════════════════════

**ИТОГ:** NVIDIA Dynamo - это open-source production-ready framework с proven architecture patterns (5.5k stars!), Kubernetes-native design, и multi-backend flexibility. **Ключевые концепции (component separation, SLA-driven API, auto-profiling) DIRECT применимы к quantum nano-chip orchestration и production deployment strategy!** 🔥
