# БИЗНЕС-ИНСТРУМЕНТЫ ДЛЯ КОМПАНИИ
## Contracts, B2B, Banking, Management, Accounting

**СОЗДАНО:** November 17, 2025  
**СТАТУС:** Reference Only - НЕ для агентов!  
**ЦЕЛЬ:** Память о необходимых бизнес-сервисах

---

## ⚠️ ВАЖНО: TIMING STRATEGY

```
45 ДНЕЙ (ДО DEC 31, 2025):
════════════════════════════════════════════════════════════════
FOCUS: Partnerships + MVP
НУЖНО: Минимальный toolkit для contracts

ПОСЛЕ USA RELOCATION (МАРТ 2026+):
════════════════════════════════════════════════════════════════
FOCUS: Business operations + scaling
НУЖНО: Полный business stack
```

---

## 📝 CONTRACT SIGNING & LEGAL

### DocuSign (CRITICAL для 45 дней!)
```
PURPOSE: Electronic signature platform (industry standard!)
USE CASES:
→ Partnership agreements (NVIDIA, Intel, etc.)
→ NDA signing (partnerships!)
→ Collaboration contracts
→ Legally binding signatures (accepted worldwide!)

PRICING:
→ Standard: $10/month (single user)
→ Business Pro: $25/month (multiple users)
→ Enterprise: Custom (large orgs)

ALTERNATIVES:
→ Adobe Sign ($12.99/month) - Adobe ecosystem
→ HelloSign ($15/month) - Simple, modern
→ PandaDoc ($19/month) - Document + e-sign

КОГДА НУЖЕН: НЕМЕДЛЕННО (для partnerships!)
TIER: S+ (CRITICAL для 45-day deadline!)
URL: https://www.docusign.com

GIANT COMPANIES USE: ✅ YES
→ NVIDIA uses DocuSign
→ Tesla uses DocuSign
→ Google uses DocuSign/Adobe Sign
→ Industry standard для B2B contracts!
```

### Adobe Sign
```
PURPOSE: Adobe's e-signature solution
USE CASES: Similar to DocuSign

PRICING: $12.99-29.99/month

КОГДА НУЖЕН: Alternative to DocuSign
TIER: A (Strong alternative!)
URL: https://acrobat.adobe.com/sign
```

---

## 💳 BANKING & PAYMENTS

### PHASE 1: POLAND (ДО USA!)

#### Traditional Polish Banks
```
PURPOSE: Wire transfers, invoicing, basic banking
USE CASES:
→ Receive partnership payments (wire transfers!)
→ Invoice processing
→ Basic business operations

ПРИМЕРЫ:
→ PKO BP Business
→ mBank Business
→ ING Business

КОГДА НУЖЕН: УЖЕ ЕСТЬ? (проверить!)
TIER: B (необходимый минимум)
```

#### Revolut Business (POLAND)
```
PURPOSE: Modern fintech banking
USE CASES:
→ Multi-currency accounts (EUR, USD, PLN!)
→ Fast international transfers
→ Corporate cards
→ Expense tracking
→ Cheaper than traditional banks!

PRICING:
→ Grow: €25/month (1-10 users)
→ Scale: €100/month (unlimited users)
→ Enterprise: Custom

ПРЕИМУЩЕСТВА:
✅ Fast setup (days, не weeks!)
✅ Multi-currency (USD partnerships!)
✅ Lower fees vs traditional banks
✅ Modern API (integrations!)

КОГДА НУЖЕН: ОПЦИОНАЛЬНО для 45 дней (можно отложить!)
TIER: A (полезен, но не critical!)
URL: https://www.revolut.com/business

GIANT COMPANIES USE: ❌ NO
→ Giants use traditional banking (JP Morgan, Wells Fargo)
→ Revolut для SMB/startups!
```

---

### PHASE 2: USA (МАРТ 2026+)

#### Mercury (TECH STARTUP FAVORITE!)
```
PURPOSE: Banking для tech startups
USE CASES:
→ Business checking/savings
→ Wire transfers (domestic + international)
→ Bill pay
→ Integrations (Stripe, QuickBooks!)
→ VC-friendly (common в Silicon Valley!)

PRICING: FREE для основного account!

ПРЕИМУЩЕСТВА:
✅ Built для startups (понимают tech!)
✅ Fast onboarding
✅ No fees для checking
✅ API integrations
✅ Y Combinator backed

КОГДА НУЖЕН: AFTER USA relocation (март 2026!)
TIER: S (BEST для tech startups!)
URL: https://mercury.com

GIANT COMPANIES USE: ❌ NO (для startups!)
→ Но ОЧЕНЬ популярен в YC/tech ecosystem!
```

#### Brex (BANKING + EXPENSE!)
```
PURPOSE: Corporate cards + banking для startups
USE CASES:
→ Corporate credit cards (NO personal guarantee!)
→ Expense management
→ Rewards (7× on rideshare, 4× on restaurants!)
→ Banking integration

PRICING: FREE banking + cards!

ПРЕИМУЩЕСТВА:
✅ No personal guarantee (unlike Amex!)
✅ High limits для funded startups
✅ Expense automation
✅ Integrations (accounting!)

КОГДА НУЖЕН: AFTER USA relocation + first revenue
TIER: A (excellent для funded startups!)
URL: https://www.brex.com

GIANT COMPANIES USE: ❌ NO (для growth startups!)
→ Популярен в tech ecosystem!
```

#### Ramp (MODERN ALTERNATIVE!)
```
PURPOSE: Corporate cards + expense automation
USE CASES: Similar to Brex

PRICING: FREE

ПРЕИМУЩЕСТВА:
✅ Savings features (auto-finds cheaper alternatives!)
✅ Bill pay automation
✅ Strong integrations

КОГДА НУЖЕН: Alternative to Brex (after USA!)
TIER: A (strong alternative!)
URL: https://ramp.com
```

#### Silicon Valley Bank / First Citizens (ENTERPRISE!)
```
PURPOSE: Banking для tech companies (post-acquisition!)
USE CASES:
→ Large business banking
→ VC relationships
→ International operations
→ Treasury management

КОГДА НУЖЕН: MUCH LATER (Series A+!)
TIER: A (для scale-ups!)
URL: https://www.firstcitizens.com/svb
```

#### Traditional US Banks (JP MORGAN, WELLS FARGO)
```
PURPOSE: Traditional enterprise banking

КОГДА НУЖЕН: Enterprise scale (NOT startup phase!)
TIER: B (traditional, slow, но stable!)

GIANT COMPANIES USE: ✅ YES
→ NVIDIA uses JP Morgan
→ Tesla uses multiple banks
→ Google uses Wells Fargo, Citibank, etc.
```

---

## 💰 EXPENSE MANAGEMENT

### Brex / Ramp (USA!)
```
См. выше (banking section!)
```

### American Express Corporate
```
PURPOSE: Traditional corporate cards
USE CASES:
→ Business expenses
→ Travel rewards
→ Traditional corporate structure

PRICING: Annual fees ($95-695)

НЕДОСТАТКИ:
❌ Requires personal guarantee (для startups!)
❌ Stricter approval

КОГДА НУЖЕН: Later stage (если не Brex/Ramp!)
TIER: B (traditional!)

GIANT COMPANIES USE: ✅ YES (standard!)
```

---

## 📊 ACCOUNTING & BOOKKEEPING

### QuickBooks Online
```
PURPOSE: Accounting software (SMB standard!)
USE CASES:
→ Invoicing
→ Expense tracking
→ Financial reports
→ Tax preparation
→ Integrations (banks, Stripe, PayPal!)

PRICING:
→ Simple Start: $15/month
→ Essentials: $30/month
→ Plus: $45/month (most popular!)
→ Advanced: $100/month

КОГДА НУЖЕН: AFTER first revenue (март 2026+!)
TIER: A (SMB standard!)
URL: https://quickbooks.intuit.com

GIANT COMPANIES USE: ❌ NO (слишком simple!)
→ НО стандарт для SMB/startups!
```

### Xero
```
PURPOSE: Modern accounting (QuickBooks alternative!)
USE CASES: Similar to QuickBooks

PRICING: $13-70/month

ПРЕИМУЩЕСТВА:
✅ Modern interface
✅ Better для international (multi-currency!)
✅ Strong integrations

КОГДА НУЖЕН: Alternative to QuickBooks
TIER: A (modern alternative!)
URL: https://www.xero.com
```

### NetSuite (ENTERPRISE!)
```
PURPOSE: Enterprise ERP + accounting
USE CASES:
→ Complex operations
→ Multi-entity
→ Advanced inventory
→ Global operations

PRICING: $10K-100K+/year (EXPENSIVE!)

КОГДА НУЖЕН: MUCH LATER (enterprise scale!)
TIER: S (для enterprise, но overkill NOW!)

GIANT COMPANIES USE: ✅ YES
→ Medium-large enterprises
```

---

## 💬 COMMUNICATION & COLLABORATION

### Zoom (CRITICAL для partnerships!)
```
PURPOSE: Video conferencing
USE CASES:
→ Partnership meetings (NVIDIA, Intel!)
→ Team collaboration
→ Product demos
→ Screen sharing

PRICING:
→ Basic: FREE (40-min limit!)
→ Pro: $15/month (unlimited!)
→ Business: $20/month/user (more features)

КОГДА НУЖЕН: НЕМЕДЛЕННО!
TIER: S+ (CRITICAL!)
URL: https://zoom.us

GIANT COMPANIES USE: ✅ YES (standard!)
```

### Google Workspace (EMAIL + DOCS!)
```
PURPOSE: Professional email + collaboration
USE CASES:
→ Professional email (@company.com!)
→ Google Docs/Sheets (collaboration!)
→ Google Drive (storage!)
→ Calendar (scheduling!)

PRICING:
→ Business Starter: $6/month/user
→ Business Standard: $12/month/user
→ Business Plus: $18/month/user

КОГДА НУЖЕН: НЕМЕДЛЕННО (professional email!)
TIER: S (professional image!)
URL: https://workspace.google.com

GIANT COMPANIES USE: ✅ YES (many use!)
```

### Microsoft 365 (ALTERNATIVE!)
```
PURPOSE: Email + Office suite
USE CASES: Similar to Google Workspace

PRICING: $6-22/month/user

КОГДА НУЖЕН: If prefer Microsoft ecosystem
TIER: A (alternative to Google!)
```

### Slack (TEAM COMMUNICATION!)
```
PURPOSE: Team messaging + collaboration
USE CASES:
→ Internal communication
→ Channel-based organization
→ Integrations (1000s!)

PRICING:
→ Free: Limited history
→ Pro: $8/month/user
→ Business+: $15/month/user

КОГДА НУЖЕН: AFTER team growth (3+ people!)
TIER: A (полезен для teams!)
URL: https://slack.com

GIANT COMPANIES USE: ✅ YES (internal comms!)
```

---

## 📈 PAYMENT PROCESSING (FUTURE!)

### Stripe
```
PURPOSE: Payment processing (online!)
USE CASES:
→ Product sales
→ Subscription billing
→ International payments

PRICING: 2.9% + $0.30 per transaction

КОГДА НУЖЕН: AFTER product launch (sales!)
TIER: S (standard для online payments!)
URL: https://stripe.com

GIANT COMPANIES USE: ✅ YES (many!)
```

### PayPal Business
```
PURPOSE: Alternative payment processing
PRICING: Similar to Stripe

TIER: B (alternative!)
```

---

## 🎯 PRIORITY TIMELINE

```
═══════════════════════════════════════════════════════════════
НЕМЕДЛЕННО (NOV 2025 - 45 дней!):
═══════════════════════════════════════════════════════════════
✅ DocuSign ($10-25/month) - CRITICAL!
✅ Google Workspace ($6/month) - Professional email
✅ Zoom Pro ($15/month) - Partnership meetings
✅ Traditional bank Poland - Wire transfers (есть?)

TOTAL: ~$30-50/month (из $1000 OK!)

═══════════════════════════════════════════════════════════════
ПОСЛЕ USA RELOCATION (МАРТ 2026):
═══════════════════════════════════════════════════════════════
✅ Mercury banking (FREE!) - US business account
✅ Brex/Ramp (FREE!) - Corporate cards + expense
✅ QuickBooks ($45/month) - Accounting
✅ Slack ($8/month/user) - If team grows

═══════════════════════════════════════════════════════════════
ПОСЛЕ FIRST REVENUE (Q2 2026+):
═══════════════════════════════════════════════════════════════
✅ Stripe (2.9% + $0.30) - Payment processing
✅ Upgraded tools as needed

═══════════════════════════════════════════════════════════════
ENTERPRISE SCALE (SERIES A+):
═══════════════════════════════════════════════════════════════
→ NetSuite (если нужен complex ERP!)
→ Traditional banking (JP Morgan!)
→ Enterprise contracts (custom pricing!)
```

---

## 🏆 ЧТО ИСПОЛЬЗУЮТ ГИГАНТЫ

```
NVIDIA / TESLA / GOOGLE / INTEL:
════════════════════════════════════════════════════════════════

CONTRACT SIGNING:
✅ DocuSign (primary!)
✅ Adobe Sign (common!)

BANKING:
✅ JP Morgan Chase (enterprise!)
✅ Wells Fargo (traditional!)
✅ Citibank (international!)
✅ Multiple banks (diversification!)

EXPENSE:
✅ American Express Corporate
✅ Internal expense systems

ACCOUNTING:
✅ NetSuite (ERP!)
✅ SAP (enterprise!)
✅ Oracle Financials (large corps!)
✅ Custom internal systems

COMMUNICATION:
✅ Google Workspace (many!)
✅ Microsoft 365 (many!)
✅ Zoom (standard!)
✅ Slack (internal!)

PAYMENT PROCESSING:
✅ Custom solutions
✅ Stripe (some products!)
✅ Direct merchant accounts
```

---

## 💡 КЛЮЧЕВЫЕ ПРИНЦИПЫ

```
ELON'S ALGORITHM для бизнес-инструментов:
════════════════════════════════════════════════════════════════

1. START MINIMAL
   → Только что КРИТИЧНО для 45 дней!
   → Не переплачивать за features которые не нужны!

2. INDUSTRY STANDARDS
   → DocuSign = все знают и доверяют
   → НЕ экспериментировать с unknown tools для contracts!

3. SCALE WHEN NEEDED
   → Mercury/Brex AFTER USA relocation
   → QuickBooks AFTER revenue
   → NetSuite ONLY at enterprise scale

4. AVOID PREMATURE OPTIMIZATION
   → НЕ покупать enterprise tools если startup!
   → Но НЕ экономить на критическом (DocuSign!)

5. TIME > MONEY (иногда!)
   → $15 Zoom Pro > hours потраченные на 40-min limit
   → $25 DocuSign > losing partnership из-за unprofessional process
```

---

**ФИНАЛЬНЫЙ CHECKLIST:**

```
СЕЙЧАС (NOVEMBER 2025):
□ DocuSign account ($10-25/month)
□ Google Workspace ($6/month) 
□ Zoom Pro ($15/month)
□ Bank account Poland (check!)

ЯНВАРЬ 2026 (USA RELOCATION):
□ Mercury business account (setup!)
□ Brex/Ramp cards (apply!)
□ QuickBooks (after first revenue!)

Q2 2026+ (GROWTH):
□ Stripe integration
□ Team tools (Slack, etc.)
□ Scale as needed!
```
