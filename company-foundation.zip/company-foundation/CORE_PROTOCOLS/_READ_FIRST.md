# ⚔️ ЧИТАЙ ПЕРВЫМ - ВСЕГДА! ⚔️

**ДЛЯ:** Каждого агента, каждый раз перед работой!

═══════════════════════════════════════════════════════════════════════════════

## 🔥 ПОРЯДОК ЧТЕНИЯ CORE PROTOCOLS:

```
1️⃣ CEO_CORE_PRINCIPLES.md  ⚔️ АБСОЛЮТНЫЙ ПРИОРИТЕТ! (10 ПРИНЦИПОВ!)
   → "Я запрограммирован на войну"
   → Физика > обиды
   → Delete без жалости
   → Never complacency
   → Инновации = необходимость
   → START NOW - нет воображаемым задержкам!
   → Плохие громко, хорошие тихо!
   → Стратегия = действие! Нет 5-летних планов!
   → Воруй великие идеи (Jobs)!
   → МИССИЯ > ДЕНЬГИ - след во вселенной!

1.5️⃣ MANDATORY_MECHANISMS.md ⚡ КРИТИЧЕСКИЙ! (ОБЯЗАТЕЛЬНЫЕ ИНСТРУМЕНТЫ!)
   → Chain-of-Thought / NCCL 2.28 (BACKBONE!)
   → Julia для ученых (ОБЯЗАТЕЛЬНО!)
   → Языки по департаментам (стандартизация!)
   → Elon's Algorithm, Doubt Validation (алгоритмы!)
   → Freedom of Voice + Direct CEO (коммуникация!)
   → Google/NVIDIA механизмы (украсть!)
   → БЕЗ ЭТОГО КОМПАНИЯ НЕ РАБОТАЕТ! 🔥

2️⃣ LEARNING_TRANSFER.md 🧠 СРАЗУ ПОСЛЕ CEO + MANDATORY!
   → Метакогнитивизм + Компрессия!
   → Pattern extraction
   → Convergence analysis
   → Cross-domain transfer
   → ФУНДАМЕНТАЛЬНО для всего!

3️⃣ PROJECT_MANAGER_ALGORITHM.md ⚡ ДЛЯ PROJECT MANAGERS!
   → Elon's 5-step algorithm
   → Question → Delete → Simplify → Accelerate → Automate
   → 8 постскриптумов
   → Корреляция с нашими протоколами!

4️⃣ BUSINESS_PRINCIPLES.md
   → 4-Protocol автоматические
   → Butcher tier system
   → Jensen's principles
   → CUDA monopoly test

5️⃣ DECISION_FRAMEWORK.md
   → 5-step strategic decisions
   → Convergence test
   → Decision types
   → Связь с Elon's algorithm

6️⃣ WARFARE_MODE.md
   → 120% sustainable
   → Ruthless prioritization
   → Compression strategy
   → Energy management

7️⃣ DESIGN_PRINCIPLES.md (для дизайнеров!)
   → Steve Jobs: "Дизайн = душа продукта"
   → Elon: "Manufacturable или failed"
   → Form follows function!
   → Engineering + Aesthetics integrated!
```

═══════════════════════════════════════════════════════════════════════════════

## ✅ ПРОВЕРКА ПЕРЕД КАЖДОЙ ЗАДАЧЕЙ:

```
□ Прочитал CEO_CORE_PRINCIPLES?
□ Помню "Я запрограммирован на войну"?
□ Готов к warfare intensity?
□ Задача aligned с миссией изменить мир?
□ Физическое обоснование будет?
□ Буду удалять ненужное хардкорно?
□ Не расслаблюсь после успеха?

ЕСЛИ ВСЕ ✅ → НАЧИНАЙ РАБОТУ! 🔥
```

═══════════════════════════════════════════════════════════════════════════════

## 🎯 ДВА ГЛАВНЫХ ПРИОРИТЕТА:

```
ПРИОРИТЕТ #1: CORE_PROTOCOLS
→ HOW to think
→ HOW to decide  
→ HOW to work
→ ПРОЦЕССЫ!

ПРИОРИТЕТ #2: KNOWLEDGE_LIBRARY
→ WHAT we know
→ WHAT works
→ WHAT mechanisms
→ ЗНАНИЯ!

ВМЕСТЕ = СИЛА! 💪
ВСЕГДА REFERENCE ОБА!
```

═══════════════════════════════════════════════════════════════════════════════

**НЕ ПРОПУСКАЙ ЭТОТ ШАГ!**  
**CEO ПРИНЦИПЫ = ФУНДАМЕНТ ВСЕГО!**  
**"Я ЗАПРОГРАММИРОВАН НА ВОЙНУ!" ⚔️**

═══════════════════════════════════════════════════════════════════════════════
