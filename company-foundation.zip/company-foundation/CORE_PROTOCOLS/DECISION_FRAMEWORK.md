# DECISION FRAMEWORK - STRUCTURED DECISION-MAKING

**СТАТУС:** АКТИВЕН  
**ЦЕЛЬ:** Systematic approach к принятию решений  
**ПРИНЦИП:** Convergence + Metacognition + Patterns

**⚡ СВЯЗЬ С ELON'S ALGORITHM:**  
Этот framework для STRATEGIC decisions.  
Для PROJECT EXECUTION → см. `PROJECT_MANAGER_ALGORITHM.md` (Elon's 5-step!)

═══════════════════════════════════════════════════════════════════════════════
## 🔗 КОРРЕЛЯЦИЯ: НАШИ 5 STEPS ↔ ELON'S 5 STEPS
═══════════════════════════════════════════════════════════════════════════════

```
ДВА РАЗНЫХ КОНТЕКСТА, ОДИН ПРИНЦИП:

НАШИ 5 STEPS (Strategic Thinking):
→ ДЛЯ: Business decisions, направление компании
→ Metakognitivny → Pattern → Convergence → Instance → Inverse
→ ЦЕЛЬ: Правильное РЕШЕНИЕ что делать

ELON'S 5 STEPS (Execution):
→ ДЛЯ: Project execution, engineering work
→ Question → Delete → Simplify → Accelerate → Automate
→ ЦЕЛЬ: Правильное ВЫПОЛНЕНИЕ как делать

ОБА НАЧИНАЮТСЯ С QUESTIONING! 🎯
→ Наш Step 1: Metakognitivny (questioning assumptions!)
→ Elon Step 1: Question requirements!

ОБА ИСПОЛЬЗУЮТ INVERSE THINKING!
→ Наш Step 5: Inverse check (что отсутствует?)
→ Elon Step 2: Delete (что не нужно?)

ПРИМЕНЕНИЕ:
→ Strategic decision? → Этот framework!
→ Project execution? → Elon's algorithm!
→ Часто используем ОБА: решаем что делать, потом как делать!
```

═══════════════════════════════════════════════════════════════════════════════
## 5-STEP DECISION PROCESS
═══════════════════════════════════════════════════════════════════════════════

### Before EVERY major decision:

```
STEP 1: METAKOGNITIVNY CHECK 🧠
"Как я думаю об этом решении?"

⚡ КОРРЕЛЯЦИЯ: Elon's Step 1 "Question requirements"
→ Мы questioning свои assumptions!
→ Elon questioning чужие requirements!
→ ОДИН ПРИНЦИП: подвергай сомнению ВСЁ!

Questions:
→ Какие assumptions делаю?
→ Что могу пропускать?
→ Какой decision framework применяю?
→ Почему именно такой approach?
→ Есть ли cognitive biases?

ELON'S ADDITION:
→ КТО создал это requirement?
→ ЗАЧЕМ оно существует?
→ ЧТО ЕСЛИ его убрать?
→ Физически обосновано?

Output: Awareness своего thinking процесса + validated assumptions
```

```
STEP 2: PATTERN MATCH 🔍
"Видел ли похожие ситуации?"

Questions:
→ Какие patterns applicable?
→ Что было общего в прошлых успехах?
→ Где были ошибки раньше?
→ Какие anti-patterns избежать?
→ Что работало повторяюще?

Output: Исторический контекст для решения
```

```
STEP 3: CONVERGENCE TEST 📊
"Сколько independent signals?"

Questions:
→ Сходятся ли indicators?
→ Сколько independent data points?
→ Quad-convergence present?
→ Есть ли contradictions?
→ Где disagreement между signals?

Scoring:
4+ signals converge = QUAD (high confidence!)
3 signals = TRIPLE (good confidence)
2 signals = DUAL (moderate confidence)
1 signal = SINGLE (low confidence, need more data!)

Output: Confidence level для решения
```

```
STEP 4: INSTANCE-AWARE 🎯
"Что уникально ДЛЯ ЭТОГО случая?"

Questions:
→ Generic solution или custom?
→ Где specific advantage?
→ Какие unique constraints?
→ Что отличает от "typical case"?
→ Применимы ли "best practices"?

Output: Customization requirements
```

```
STEP 5: INVERSE CHECK 🔄
"Что ОТСУТСТВУЕТ в моём анализе?"

⚡ КОРРЕЛЯЦИЯ: Elon's Step 2 "Delete"
→ Мы ищем что отсутствует (vacancies!)
→ Elon ищет что не нужно (deletion!)
→ INVERSE THINKING оба раза!

Questions:
→ Какие альтернативы не рассмотрел?
→ Где vacancies в моём thinking?
→ Что я предполагаю без проверки?
→ Какие unknown unknowns?
→ Что я НЕ ЗНАЮ что не знаю?

DELETION CHECK:
→ Какие части решения НЕ НУЖНЫ?
→ Можно ли проще?
→ Что удалить БЕЗ потери value?

Output: Blind spots identification + simplification opportunities
```

### DECISION MATRIX:

```
IF все 5 steps пройдены:
  → HIGH CONFIDENCE decision!
  → Proceed with conviction!
  
IF 3-4 steps:
  → MODERATE confidence
  → Proceed с validation plan
  
IF <3 steps:
  → LOW confidence
  → Need more analysis OR
  → Accept uncertainty explicitly
```

═══════════════════════════════════════════════════════════════════════════════
## DECISION TYPES & FRAMEWORKS
═══════════════════════════════════════════════════════════════════════════════

### TYPE 1: STRATEGIC DECISIONS (COMPANY DIRECTION)

```
Examples:
→ Which market to enter?
→ What product to build?
→ Partnership vs independent?
→ Pivot vs persevere?

Framework:

1) CONVERGENCE ANALYSIS:
   Market demand ✓
   Technical feasibility ✓
   Competitive advantage ✓
   Resource availability ✓
   Team capability ✓
   → Quad+ convergence = GO!

2) TIER CLASSIFICATION:
   S-tier potential? (moonshot!)
   A-tier opportunity? (flagship!)
   B-tier solid? (revenue!)
   C-tier quick? (cash flow!)
   D-tier reject? (skip!)

3) MONOPOLY TEST:
   Ecosystem potential?
   Vertical integration?
   Years to master?
   → Lock-in possible?

4) CREATIVE COMBINATION:
   What can we combine?
   Emergent properties?
   New category creation?

Decision: GO / NO-GO / PIVOT
Timeline: Weeks to decide
Impact: Company direction
Reversibility: Hard to reverse!
```

### TYPE 2: TACTICAL DECISIONS (EXECUTION)

```
Examples:
→ Which feature to build first?
→ How to allocate resources?
→ When to launch?
→ Which customer to prioritize?

Framework:

1) CRITICAL PATH:
   What blocks everything else?
   What enables multiple things?
   Where are dependencies?

2) IMPACT vs EFFORT:
   High impact, low effort = DO NOW!
   High impact, high effort = PLAN!
   Low impact, low effort = DEFER!
   Low impact, high effort = NEVER!

3) WARFARE MODE:
   Deadline pressure?
   Critical or nice-to-have?
   MVP sufficient?

Decision: PRIORITIZE / DEFER / DELEGATE
Timeline: Days to decide
Impact: Execution speed
Reversibility: Usually reversible
```

### TYPE 3: OPERATIONAL DECISIONS (DAY-TO-DAY)

```
Examples:
→ How to structure code?
→ Which tool to use?
→ Meeting or async?
→ Internal or outsource?

Framework:

1) PATTERN MATCH:
   What worked before?
   Standard approach exists?
   Any innovation needed?

2) COMPRESSION:
   High-value decision?
   Or quick verdict sufficient?

3) EFFICIENCY:
   Fastest path forward?
   Good enough for now?
   Can optimize later?

Decision: CHOOSE & MOVE
Timeline: Minutes to hours
Impact: Execution quality
Reversibility: Highly reversible
```

═══════════════════════════════════════════════════════════════════════════════
## SPECIFIC DECISION SCENARIOS
═══════════════════════════════════════════════════════════════════════════════

### PRODUCT DECISION

```
Question: "Should we build this product?"

STEP 1: METAKOGNITIVNY
"Am I thinking vacancy-based or competition-based?"
→ Vacancy: what's MISSING на рынке? ✓
→ Competition: how beat existing? ❌

STEP 2: PATTERN MATCH
"Similar успехи/провалы в прошлом?"
→ Successful: filled vacancy, 10x improvement
→ Failed: incremental в crowded market

STEP 3: CONVERGENCE
□ Customer demand validated?
□ Technical feasibility confirmed?
□ Competitive advantage clear?
□ Resources available?
→ 4/4 = QUAD! High confidence!

STEP 4: INSTANCE-AWARE
"What's unique about THIS product/market?"
→ Specific customer pain point
→ Unique capability we have
→ Timing advantage (market ready now!)

STEP 5: INVERSE
"What am I NOT considering?"
→ Alternative approaches?
→ Hidden assumptions?
→ Risks not evaluated?

DECISION MATRIX:
Quad-convergence + Unique advantage + Vacancy = BUILD!
Dual-convergence + Moderate advantage = VALIDATE MORE!
Single-convergence + Crowded market = REJECT!
```

### HIRING DECISION

```
Question: "Should we hire this person?"

CONVERGENCE TEST:
□ Technical skills validated? (test/portfolio)
□ Cultural fit confirmed? (values alignment)
□ Growth mindset evident? (learning examples)
□ References positive? (external validation)

Quad-convergence = HIRE!
Triple = HIRE with onboarding focus
Dual = MAYBE (more interviews?)
Single = NO

INSTANCE-AWARE:
→ What's unique about THIS role?
→ What's unique about THIS candidate?
→ Generic fit or perfect match?

INVERSE:
→ What concerns NOT surfaced?
→ What я НЕ спросил?
→ Unknown unknowns about candidate?
```

### PARTNERSHIP DECISION

```
Question: "Should we partner with Company X?"

CONVERGENCE:
□ Strategic alignment? (goals compatible)
□ Mutual value? (both benefit)
□ Resource complementarity? (we have A, they have B)
□ Trust established? (track record/references)

PATTERN MATCH:
→ Similar partnerships successful?
→ What made them work?
→ What risks materialized?

TIER THINKING:
→ S-tier partnership? (ecosystem monopoly together!)
→ A-tier? (significant advantage)
→ B-tier? (good revenue)
→ C-tier? (quick win)
→ D-tier? (waste of time)

DECISION:
S/A-tier + Quad-convergence = PURSUE AGGRESSIVELY!
B-tier + Triple = EXPLORE!
C/D-tier = POLITE DECLINE!
```

═══════════════════════════════════════════════════════════════════════════════
## DECISION DOCUMENTATION
═══════════════════════════════════════════════════════════════════════════════

### For MAJOR decisions, document:

```
DECISION LOG TEMPLATE:

Date: [когда решение принято]
Decision: [что решили]
Context: [why this decision needed]

ANALYSIS:
✓ Metakognitivny: [how we thought about it]
✓ Pattern Match: [similar cases referenced]
✓ Convergence: [signals that aligned - score X/4]
✓ Instance-Aware: [unique factors considered]
✓ Inverse: [what we checked for blind spots]

OUTCOME:
→ Decision: [GO / NO-GO / PIVOT / DEFER]
→ Confidence: [HIGH / MODERATE / LOW]
→ Reversibility: [HARD / MEDIUM / EASY]
→ Timeline: [when to revisit if applicable]

LEARNING:
→ What would improve this decision process?
→ What patterns emerged?
→ What to watch for in future similar decisions?
```

### Where to document:

```
Strategic decisions:
→ company-foundation/COMPANY_OPERATIONS/DECISION_LOG.md

Tactical decisions:
→ Project documentation / sprint notes

Operational decisions:
→ Usually not documented (unless pattern emerges)
```

═══════════════════════════════════════════════════════════════════════════════
## DECISION ANTI-PATTERNS (AVOID!)
═══════════════════════════════════════════════════════════════════════════════

```
❌ ANALYSIS PARALYSIS
"Need perfect information before deciding"
→ Accept uncertainty!
→ Make decision с best available data!
→ Plan для validation after!

❌ SUNK COST FALLACY
"We've invested so much already..."
→ Past investment IRRELEVANT!
→ Future value only matters!
→ Pivot if data says so!

❌ GROUPTHINK
"Everyone agrees so must be right"
→ Seek dissenting opinions!
→ Devil's advocate important!
→ Convergence должна быть INDEPENDENT!

❌ CONFIRMATION BIAS
"Looking only for supporting evidence"
→ Actively seek contradictions!
→ Inverse check critical!
→ What would prove us WRONG?

❌ RECENCY BIAS
"Last experience defines all future"
→ Pattern match across MULTIPLE cases!
→ Not just most recent!
→ Statistical thinking!

❌ AUTHORITY BIAS
"Expert said X so must be true"
→ First principles thinking!
→ Validate even expert opinions!
→ Context matters!
```

═══════════════════════════════════════════════════════════════════════════════

**DECISION FRAMEWORK = SYSTEMATIC, NOT BUREAUCRATIC!**  
**QUICK FOR SMALL, THOROUGH FOR BIG!**  
**DOCUMENT LEARNING, IMPROVE PROCESS!**

═══════════════════════════════════════════════════════════════════════════════
