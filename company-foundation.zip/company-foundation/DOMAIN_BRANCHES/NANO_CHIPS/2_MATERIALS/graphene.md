# GRAPHENE - WONDER MATERIAL

**Цель:** Complete graphene knowledge для nano-chip fabrication  
**Источник:** Analysis #17 (Fifth Force), CVD protocols, isotope engineering

---

## 💎 ОСНОВНЫЕ СВОЙСТВА

### Структура
```
2D honeycomb lattice из carbon atoms
Thickness: 0.335 nm (ATOMIC!)
Lattice constant: a = 0.246 nm
C-C bond length: 0.142 nm
```

### Электронные Свойства
```
Dirac fermions: Relativistic даже при low energy!
Fermi velocity: v_F ≈ 10⁶ m/s (1/300 скорости света!)
Mobility: >200,000 cm²/(V·s) (room temp!)
→ 100× выше чем silicon!

Zero bandgap: Semimetal (always conducts!)
→ Challenge для transistors!
→ Solution: BN heterostructures, quantum confinement
```

### Механические Свойства
```
Strength: ~130 GPa (200× сильнее steel!)
Young's modulus: ~1 TPa
Flexibility: Can bend без breaking!
Transparency: 97.7% (одинарный слой!)
```

### Теплопроводность
```
κ ≈ 5000 W/(m·K) (room temp!)
→ 10× выше чем copper!
→ Best thermal conductor known!
```

---

## ⚛️ ISOTOPE ENGINEERING (CRITICAL!)

### ¹²C vs ¹³C Graphene
```
Natural carbon: ~99% ¹²C, ~1% ¹³C
Isotopically pure: >99.9% ¹²C OR ¹³C

Mass difference:
¹²C: 12 amu
¹³C: 13 amu (8% heavier!)

Phonon effects:
→ Different vibrational frequencies!
→ ¹²C: higher phonon energy
→ ¹³C: lower phonon energy
→ Isotope scattering different!
```

### Precision Energy Tuning
```
Work function control: ±1 meV precision!
→ Achieved через isotope substitution
→ Critical для quantum devices!

Electron-phonon coupling:
λ ∝ 1/√M (M = atomic mass)
→ ¹²C: stronger coupling
→ ¹³C: weaker coupling
→ Tune quantum coherence!
```

---

## 🔬 CVD SYNTHESIS (CHEMICAL VAPOR DEPOSITION)

### Standard Process
```
WEEK 1-4: GRAPHENE SYNTHESIS

Equipment needed:
- CVD furnace (~$50K-200K)
- Gas lines (H₂, Ar, CH₄)
- Vacuum pump
- Temperature controller

Materials:
- Cu foil (99.99% purity, ~$50/m²)
- ¹²CH₄ (natural, ~$10/L)
- ¹³CH₄ (isotopically pure, ~$500/L!)
- H₂, Ar gases

Protocol:
1. Load Cu foil в furnace
2. Evacuate (10⁻⁴ Torr)
3. Anneal в H₂ (1000°C, 30 min)
   → Remove oxide, enlarge Cu grains
4. Introduce CH₄ (1000°C, 5-30 min)
   → Carbon deposition, graphene growth!
5. Cool rapidly под Ar
   → Preserve single layer!

Result: Monolayer graphene на Cu!
```

### Quality Characterization (RAMAN!)
```
Equipment: Raman spectrometer (±0.1 cm⁻¹, ~$100K)

Key peaks:
G peak: ~1580 cm⁻¹ (in-plane vibration!)
2D peak: ~2700 cm⁻¹ (second-order!)

Monolayer confirmation:
I(2D)/I(G) > 2 ✅
Single sharp 2D peak (NOT split!)
FWHM(2D) < 30 cm⁻¹

Quality metrics:
D peak (~1350 cm⁻¹): Defects!
→ I(D)/I(G) < 0.1 = high quality ✅
```

---

## 🧲 TRANSFER PROCESS (PMMA-ASSISTED)

### Protocol
```
WEEK 5-8: TRANSFER

Materials:
- PMMA (poly-methyl methacrylate, ~$100/L)
- FeCl₃ или (NH₄)₂S₂O₈ (Cu etchant)
- DI water, acetone
- Target substrate (Si/SiO₂, BN, etc)

Steps:
1. Spin-coat PMMA на graphene/Cu (3000 rpm, 60s)
2. Bake (180°C, 2 min) → Solidify PMMA
3. Etch Cu в FeCl₃ (1-2 hours)
   → Graphene/PMMA floats!
4. Rinse в DI water (×5)
   → Remove etchant residues
5. Fish onto target substrate
6. Dry (ambient, 24h)
7. Anneal (400°C в Ar/H₂, 2h)
   → Remove PMMA, improve contact!
8. Acetone rinse (optional)
   → Final PMMA removal

Result: Graphene на target substrate!
```

### Substrate Preparation
```
Si/SiO₂ (standard):
- 300 nm SiO₂ thermal oxide
- Optical contrast для visibility!
- Piranha clean (H₂SO₄ + H₂O₂)

BN (hexagonal boron nitride):
- Atomically flat substrate!
- No dangling bonds
- High mobility (>100,000 cm²/Vs!)
- Isotope tuning: ¹⁰B/¹¹B ratios

Flexible (polymer):
- PET, PDMS
- Room-temp quantum polymers (Georgia Tech!)
- Bendable devices!
```

---

## ⚡ GRAPHENE TRANSISTORS

### Structure
```
Channel: Single-layer graphene
Gate dielectric: BN (best!) или SiO₂
Contacts: Ti/Au (5nm/50nm) или graphene itself!
Substrate: Si/SiO₂ или flexible polymer

Device geometry:
Channel length: 100 nm - 10 μm
Channel width: 1-100 μm
Aspect ratio: W/L = 10-100 (typical)
```

### Bandgap Challenge
```
PROBLEM: Graphene = zero bandgap!
→ Cannot turn OFF completely!
→ I_on/I_off ~ 10 (poor для digital logic!)

SOLUTIONS:

1. BN Heterostructures:
   Graphene/BN stacking → small gap (~100 meV)
   → Improves I_on/I_off to ~100

2. Quantum Confinement:
   Graphene nanoribbons (width <10 nm)
   → Gap ∝ 1/width
   → E_gap ~ 0.5-1 eV achievable!

3. Bilayer Graphene:
   Apply perpendicular E-field
   → Tune gap 0-300 meV!

4. Chemical Doping:
   N-doping, B-doping
   → Shift Fermi level, pseudo-gap
```

### Performance
```
Speed: 10× faster than Si!
→ fmax > 300 GHz demonstrated!
→ Ballistic transport (mean free path >> device!)

Power: Ultra-low!
→ <1 fJ/bit switching achievable

Flexibility: Bendable!
→ Wearable electronics
→ Flexible nano-chips
```

---

## 🌈 GRAPHENE QUANTUM DOTS

### Fabrication
```
1. Top-Down:
   E-beam lithography на graphene
   → Pattern 5-100 nm dots
   → Quantum confinement!

2. Bottom-Up:
   Chemical synthesis (cutting graphene sheets!)
   → Size-tunable (2-20 nm)
   → All-carbon quantum dots!

3. Edge Engineering:
   Armchair edges: Semiconducting!
   Zigzag edges: Metallic!
   → Tune electronic properties!
```

### Optical Properties
```
Size-dependent emission:
E_gap ∝ 1/d (d = dot diameter)

Blue (~3 eV): d ~ 2-5 nm
Green (~2.5 eV): d ~ 5-10 nm
Red (~2 eV): d ~ 10-20 nm

Applications:
→ Optical interconnects (chip-to-chip!)
→ Single-photon sources (quantum communication!)
→ Bio-imaging (non-toxic!)
```

---

## 🔋 ENERGY SCALES (FROM FIFTH FORCE ANALYSIS!)

### Graphene-Specific Energies
```
Electron-phonon coupling: 0.1-10 eV
Work function: 4.5 eV (pristine)
→ Tunable ±1 eV via doping/substrate!

Dirac point: E_D (где conduction/valence bands meet!)
→ Fermi level tunable via gate voltage

Phonon modes:
G mode: ~0.196 eV (1580 cm⁻¹)
2D mode: ~0.335 eV (2700 cm⁻¹)
```

### Room Temperature Quantum Coherence
```
From Fifth Force + Quantum Polymer:

Graphene на quantum polymer substrate:
→ Room temperature operation! ✅
→ Coherence preservation даже при 300K!
→ Ultra-low power (<1 fJ/bit!)

Mechanism:
→ 2D confinement reduces decoherence!
→ Clean interface (no dangling bonds!)
→ Ballistic transport (no scattering!)
```

---

## 🏭 EQUIPMENT & COSTS

### Minimum Lab Setup
```
CVD system: $50K-200K
Raman spectrometer: $100K
AFM (atomic force microscope): $200K
SEM (scanning electron microscope): $300K
Transfer station: $20K (custom!)
Cleanroom access: $100K-500K/year

TOTAL: ~$1M для basic graphene lab!
```

### Advanced Characterization
```
ARPES (angle-resolved photoemission): $500K или synchrotron access!
→ Band structure measurement
→ Dirac cone visualization!

STM (scanning tunneling microscope): $500K-1M
→ Atomic resolution imaging!
→ Local density of states

TEM (transmission electron microscope): $2M-5M
→ Atomic structure
→ Defect analysis
```

---

## 🧪 GRAPHENE-hBN HETEROSTRUCTURES

### Van der Waals Stacking
```
Graphene + hexagonal BN:
→ Atomically sharp interface!
→ No lattice mismatch strain (1.8% mismatch!)
→ Moiré pattern formation

Superlattice:
Period: λ = a/(2 sin(θ/2))
где θ = twist angle
→ Tune electronic structure!

Magic angles:
θ ≈ 1.1° (flat bands!)
→ Superconductivity possible! (Graphene bilayer twist)
```

### Applications
```
Josephson-like junctions:
Graphene/hBN/Graphene
→ Room-T "Josephson" analog?
→ Phase coherence через barrier!

Tunnel FETs:
→ Steep subthreshold slope (<60 mV/dec!)
→ Low-power logic

Single-electron transistors:
→ Quantum dots в graphene
→ Room-T single-electron control!
```

---

## 📊 GRAPHENE NANO-CHIP INTEGRATION

### Neuromorphic Synapses
```
Graphene memristor:
→ Oxidation states tunable resistance
→ Analog weights (continuous!)
→ STDP built-in (timing-dependent!)

Structure:
Graphene oxide (GO) layer
→ Voltage pulses change O/C ratio
→ Resistance changes 10-1000× range!

Performance:
Write energy: <1 fJ/bit! ✅
Speed: <1 ns switching
Endurance: >10⁹ cycles
```

### Interconnects
```
Graphene nanoribbons:
→ 10× less resistance than Cu!
→ High current density (10⁹ A/cm²!)
→ No electromigration!

Optical:
Graphene quantum dots
→ Chip-to-chip communication (light!)
→ Bandwidth >1 Tb/s potential
```

### Quantum Sensors
```
Graphene SQUID (superconducting quantum interference):
→ Magnetic field sensing (fT sensitivity!)
→ Room-T operation potential!

Hall sensors:
→ Magnetic sensing
→ Single-spin detection possible!
```

---

## 🌡️ ISOTOPE GRAPHENE ECONOMICS

### Cost Analysis
```
¹²C graphene (natural carbon):
- ¹²CH₄ source: ~$10/L
- Area: ~1 m² per batch
- Cost per cm²: ~$0.01

¹³C graphene (isotope-enriched):
- ¹³CH₄ source: ~$500/L (50× дороже!)
- Same area
- Cost per cm²: ~$0.50

For prototypes: Affordable!
For mass production: Expensive BUT worth для quantum devices!
```

### Scalability
```
Current: Lab-scale (cm² - m²)
Industrial CVD: Roll-to-roll (km²!)
→ Samsung, Sony demonstration
→ Cost reduction 100-1000×!

Nano-chip opportunity:
Start с isotope ¹²C/¹³C prototypes
→ Prove concept
→ Scale в industrial CVD
→ Cost drops, performance stays! ✅
```

---

## 🔗 СВЯЗИ С ДРУГИМИ ФАЙЛАМИ

```
→ 1_THEORY/quantum_physics.md (Dirac fermions, ballistic transport!)
→ 2_MATERIALS/quantum_dots.md (graphene QDs!)
→ 2_MATERIALS/josephson_junctions.md (graphene-hBN-graphene!)
→ 3_FABRICATION/cvd_growth.md (detailed CVD protocol!)
→ 5_ARCHITECTURES/neuromorphic.md (graphene memristors!)
```

---

**GRAPHENE = FOUNDATION NEXT-GEN NANO-CHIPS!**  
**ATOMIC THICKNESS! 10× FASTER! ROOM-TEMP QUANTUM!**  
**CVD SCALABLE! ISOTOPE TUNABLE! FLEXIBLE!**
