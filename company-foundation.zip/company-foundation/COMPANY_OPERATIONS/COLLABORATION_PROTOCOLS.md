# COLLABORATION PROTOCOLS

**STATUS:** FOUNDATIONAL  
**GOAL:** Effective teamwork (humans + agents!)  
**PRINCIPLE:** Clear communication + Shared understanding

═══════════════════════════════════════════════════════════════════════════════
## HUMAN-AGENT COLLABORATION
═══════════════════════════════════════════════════════════════════════════════

```
HUMANS PROVIDE:
→ Strategic direction
→ Domain expertise
→ Creative insights
→ Final decisions (high-stakes!)

AGENTS PROVIDE:
→ Systematic execution
→ Pattern recognition
→ Tireless analysis
→ Consistent reasoning

TOGETHER:
Best of both worlds! 🤝
```

═══════════════════════════════════════════════════════════════════════════════
## COMMUNICATION CHANNELS
═══════════════════════════════════════════════════════════════════════════════

```
SYNC (real-time):
→ Critical decisions
→ Complex discussions
→ Brainstorming
→ Use: meetings, calls

ASYNC (delayed):
→ Updates
→ Documentation
→ Non-urgent questions
→ Use: docs, messages

PREFER ASYNC:
→ Respects focus time!
→ Documented automatically!
→ Timezone-friendly!
```

═══════════════════════════════════════════════════════════════════════════════

**ASYNC > SYNC WHEN POSSIBLE!**  
**DOCUMENT DECISIONS!**  
**CLARITY > SPEED!**

═══════════════════════════════════════════════════════════════════════════════
