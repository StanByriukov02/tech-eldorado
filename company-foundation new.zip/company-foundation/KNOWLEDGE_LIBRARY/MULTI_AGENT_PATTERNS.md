# MULTI-AGENT PATTERNS (Adapted from n8n/Google)

**ИСТОЧНИКИ:** n8n workflow automation + Google LangGraph/CrewAI  
**АДАПТАЦИЯ:** NON-LLM agents (knowledge graphs + Chain-of-Thought)  
**СТАТУС:** Production-ready patterns for nano-chips agents  
**ДАТА:** November 14, 2025

═══════════════════════════════════════════════════════════════════════════════
## 🎯 CRITICAL NOTE: LLM vs NON-LLM ADAPTATION
═══════════════════════════════════════════════════════════════════════════════

```
ИСТОЧНИКИ (n8n/Google):
→ Designed для LLM agents (GPT, Gemini, Claude!)
→ Visual workflow builders (no-code!)
→ LangChain orchestration
→ Conversation state management

НАША АДАПТАЦИЯ:
→ NON-LLM agents (knowledge graphs!)
→ Code-first (Python/Julia!)
→ Direct reasoning (Chain-of-Thought!)
→ Shared knowledge state

STEAL: Architectural patterns (proven!)
SKIP: Tooling/platforms (overhead!)
```

═══════════════════════════════════════════════════════════════════════════════
## 🏗️ PATTERN 1: SUPERVISOR/GATEKEEPER (Chief Scientist Model)
═══════════════════════════════════════════════════════════════════════════════

### CONCEPT:
Central "brain" agent routes tasks to specialized sub-agents, synthesizes results.

### ARCHITECTURE:
```
┌─────────────────────────────────────────┐
│   SUPERVISOR (Chief Scientist Agent)    │
│   - Receives task                       │
│   - Classifies/routes                   │
│   - Delegates to specialists            │
│   - Synthesizes results                 │
└─────────────────┬───────────────────────┘
                  │
    ┌─────────────┼─────────────┬─────────────┐
    ▼             ▼             ▼             ▼
┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐
│Quantum │  │ Thermo │  │Engineer│  │Integra-│
│Physics │  │dynamics│  │  ing   │  │  tion  │
│ Agent  │  │ Agent  │  │ Agent  │  │ Agent  │
└────────┘  └────────┘  └────────┘  └────────┘
```

### IMPLEMENTATION (Python):

```python
class ChiefScientistAgent:
    """
    Supervisor pattern for multi-agent coordination.
    Adapted from n8n Gatekeeper pattern.
    """
    def __init__(self, knowledge_graph):
        self.kg = knowledge_graph
        self.specialists = {
            'quantum': QuantumPhysicsAgent(knowledge_graph),
            'thermo': ThermodynamicsAgent(knowledge_graph),
            'engineering': EngineeringAgent(knowledge_graph),
            'integration': IntegrationAgent(knowledge_graph)
        }
        
    def route_task(self, task):
        """
        Routing logic (n8n Switch node adapted).
        Uses keywords + knowledge graph reasoning.
        """
        keywords = task.extract_keywords()
        
        # Knowledge graph classification
        domain = self.kg.classify_domain(keywords)
        
        # Route to specialist
        if domain == 'energy_optimization':
            return self.specialists['thermo']
        elif domain == 'quantum_coherence':
            return self.specialists['quantum']
        elif domain == 'chip_design':
            return self.specialists['engineering']
        elif domain == 'system_integration':
            return self.specialists['integration']
        else:
            # Fallback: multi-specialist (parallel!)
            return [self.specialists['quantum'], 
                    self.specialists['thermo']]
    
    def execute(self, task):
        """Main execution flow."""
        # Step 1: Route
        agents = self.route_task(task)
        
        # Step 2: Execute (single or parallel)
        if isinstance(agents, list):
            results = [agent.process(task) for agent in agents]
        else:
            results = [agents.process(task)]
        
        # Step 3: Synthesize (Supervisor responsibility!)
        synthesis = self.synthesize_results(results, task)
        
        return synthesis
    
    def synthesize_results(self, results, task):
        """
        Combine specialist findings.
        Uses knowledge graph for reasoning.
        """
        # Add all findings to knowledge graph
        for result in results:
            self.kg.add_facts(result.findings)
        
        # Reason over combined knowledge
        synthesis = self.kg.query({
            'question': task.question,
            'context': [r.findings for r in results]
        })
        
        return synthesis
```

### WHEN TO USE:
- Task requires multiple expertise areas
- Clear domain boundaries (quantum, thermo, engineering)
- Need centralized coordination
- Results must be synthesized

### EXAMPLE NANO-CHIPS:
```
Task: "Validate room-temperature quantum coherence feasibility"

Flow:
1. Chief Scientist receives task
2. Routes to: Quantum + Thermo agents (both needed!)
3. Quantum: Analyzes coherence physics
4. Thermo: Analyzes energy constraints
5. Chief Scientist synthesizes: "Feasible with graphene + p-bits"
```

═══════════════════════════════════════════════════════════════════════════════
## 🔗 PATTERN 2: CHAINED REASONING (Research Pipeline)
═══════════════════════════════════════════════════════════════════════════════

### CONCEPT:
Sequential agents where each step feeds context to next (pipeline processing).

### ARCHITECTURE:
```
Input → Agent1 → Agent2 → Agent3 → Agent4 → Output
        ↓        ↓        ↓        ↓
      Context  Context  Context  Context
       grows    grows    grows    grows
```

### IMPLEMENTATION:

```python
class ResearchPipeline:
    """
    Chained reasoning pattern.
    Adapted from n8n Chained Requests.
    """
    def __init__(self, knowledge_graph):
        self.kg = knowledge_graph
        self.pipeline = [
            LiteratureReviewAgent(knowledge_graph),
            TheoreticalAnalysisAgent(knowledge_graph),
            ExperimentDesignAgent(knowledge_graph),
            ValidationAgent(knowledge_graph)
        ]
    
    def execute(self, research_question):
        """
        Sequential execution with growing context.
        """
        context = {
            'question': research_question,
            'findings': [],
            'confidence': 1.0
        }
        
        for i, agent in enumerate(self.pipeline):
            print(f"Step {i+1}/{len(self.pipeline)}: {agent.name}")
            
            # Agent processes with full context
            result = agent.process(context)
            
            # Update context (accumulate knowledge!)
            context['findings'].append(result)
            context['confidence'] *= result.confidence
            
            # Add to knowledge graph
            self.kg.add_facts(result.facts)
            
            # Early termination if confidence too low
            if context['confidence'] < 0.3:
                return self.generate_insufficient_confidence_report(context)
        
        # Generate final comprehensive report
        return self.generate_final_report(context)
    
    def generate_final_report(self, context):
        """Synthesize all pipeline steps."""
        return {
            'question': context['question'],
            'literature': context['findings'][0],
            'theory': context['findings'][1],
            'experiment': context['findings'][2],
            'validation': context['findings'][3],
            'confidence': context['confidence'],
            'recommendation': self.kg.query_recommendation(context)
        }
```

### WHEN TO USE:
- Multi-step analysis required
- Each step builds on previous
- Clear sequential dependencies
- Research workflows

### EXAMPLE NANO-CHIPS PIPELINE:
```
Question: "Can graphene quantum dots achieve 99.9% energy reduction?"

Step 1 (Literature): Find papers on graphene energy efficiency
  → Context: 50 papers, best shows 90% reduction

Step 2 (Theory): Analyze theoretical limits
  → Context: Physics allows 99.9%, requires room-T coherence

Step 3 (Experiment): Design validation tests
  → Context: 3 experiments, need p-bits + graphene integration

Step 4 (Validation): Check feasibility
  → Context: Feasible, timeline 3 months, confidence 85%

Output: Comprehensive research plan + confidence score
```

═══════════════════════════════════════════════════════════════════════════════
## ⚡ PATTERN 3: PARALLEL EXECUTION + MERGE (Fast Research)
═══════════════════════════════════════════════════════════════════════════════

### CONCEPT:
Multiple agents work simultaneously on independent subtasks, results merged.

### ARCHITECTURE:
```
                    ┌─ Agent A ─┐
Input → SPLIT ──────┼─ Agent B ─┼──── MERGE → Output
                    └─ Agent C ─┘
     (parallel!)                   (synthesis!)
```

### IMPLEMENTATION:

```python
import asyncio

class ParallelResearchTeam:
    """
    Parallel execution pattern.
    Adapted from n8n Split→Parallel→Merge.
    """
    def __init__(self, knowledge_graph):
        self.kg = knowledge_graph
        self.sources = {
            'arxiv': ArxivSearchAgent(knowledge_graph),
            'patents': PatentSearchAgent(knowledge_graph),
            'github': GithubSearchAgent(knowledge_graph),
            'ieee': IEEESearchAgent(knowledge_graph)
        }
    
    async def research_parallel(self, topic):
        """
        Parallel search across all sources.
        3-4× faster than sequential!
        """
        # Create tasks (one per source)
        tasks = [
            self.sources['arxiv'].search_async(topic),
            self.sources['patents'].search_async(topic),
            self.sources['github'].search_async(topic),
            self.sources['ieee'].search_async(topic)
        ]
        
        # Execute in parallel
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle errors gracefully
        valid_results = [r for r in results if not isinstance(r, Exception)]
        
        # Merge results
        merged = self.merge_results(valid_results, topic)
        
        return merged
    
    def merge_results(self, results, topic):
        """
        Synthesis agent combines findings.
        Uses knowledge graph for deduplication + reasoning.
        """
        all_papers = []
        all_patents = []
        all_repos = []
        
        for result in results:
            if result.source == 'arxiv':
                all_papers.extend(result.papers)
            elif result.source == 'patents':
                all_patents.extend(result.patents)
            elif result.source == 'github':
                all_repos.extend(result.repos)
        
        # Deduplicate using knowledge graph
        unique_papers = self.kg.deduplicate(all_papers, by='doi')
        unique_patents = self.kg.deduplicate(all_patents, by='patent_id')
        unique_repos = self.kg.deduplicate(all_repos, by='repo_url')
        
        # Rank by relevance
        ranked = self.kg.rank_by_relevance(
            topic=topic,
            papers=unique_papers,
            patents=unique_patents,
            repos=unique_repos
        )
        
        return {
            'topic': topic,
            'papers': ranked['papers'][:20],  # Top 20
            'patents': ranked['patents'][:10],
            'repos': ranked['repos'][:5],
            'total_sources': len(results),
            'execution_time': 'parallel (3-4× faster!)'
        }
    
    # Synchronous wrapper
    def research(self, topic):
        """Sync interface for parallel research."""
        return asyncio.run(self.research_parallel(topic))
```

### WHEN TO USE:
- Independent subtasks (no dependencies)
- Speed critical (deadline pressure!)
- Multiple data sources
- Embarrassingly parallel problems

### EXAMPLE:
```
Topic: "Thermodynamic computing energy efficiency"

Parallel execution (simultaneous!):
- ArxivAgent: Searches 50K papers → 15 results (2 seconds)
- PatentAgent: Searches USPTO → 8 patents (2 seconds)  
- GithubAgent: Searches repos → 3 implementations (2 seconds)
- IEEEAgent: Searches journals → 12 papers (2 seconds)

Sequential would take: 8 seconds
Parallel takes: 2 seconds (4× faster!)

Merge: Deduplicate, rank by relevance, return top 35 results
```

═══════════════════════════════════════════════════════════════════════════════
## 🤝 PATTERN 4: HUMAN-IN-THE-LOOP (Critical Decisions)
═══════════════════════════════════════════════════════════════════════════════

### CONCEPT:
Agent proposes action, waits for human approval before executing critical operations.

### ARCHITECTURE:
```
Agent → Generate Proposal → Request Approval → Human Reviews
                                    ↓
                            Approved? ──Yes──→ Execute
                                    ↓
                                   No ──→ Reject + Log
```

### IMPLEMENTATION:

```python
class AgentWithGovernance:
    """
    Human-in-the-loop pattern.
    Adapted from n8n Wait for Approval node.
    """
    def __init__(self, knowledge_graph, approval_threshold='high'):
        self.kg = knowledge_graph
        self.approval_threshold = approval_threshold
        
    def requires_approval(self, action):
        """
        Determine if action needs human review.
        Based on risk, cost, impact.
        """
        risk_score = self.calculate_risk(action)
        
        thresholds = {
            'low': 0.3,      # Auto-approve most
            'medium': 0.5,   # Balanced
            'high': 0.2      # Approve only low-risk
        }
        
        return risk_score > thresholds[self.approval_threshold]
    
    def calculate_risk(self, action):
        """Risk assessment using knowledge graph."""
        factors = {
            'budget_impact': action.estimated_cost / 10000,  # $10K baseline
            'timeline_impact': action.estimated_days / 49,    # 49-day deadline
            'reversibility': 0 if action.reversible else 0.5,
            'precedent': 0 if self.kg.has_precedent(action) else 0.3
        }
        
        return sum(factors.values()) / len(factors)
    
    def execute_with_approval(self, action):
        """
        Main execution flow with human governance.
        """
        # Generate detailed proposal
        proposal = self.generate_proposal(action)
        
        # Check if approval needed
        if self.requires_approval(action):
            print(f"\n{'='*60}")
            print(f"APPROVAL REQUIRED: {action.name}")
            print(f"{'='*60}")
            print(f"Risk Score: {self.calculate_risk(action):.2f}")
            print(f"\nProposal:")
            print(proposal)
            print(f"\nApprove? (yes/no): ", end='')
            
            # Wait for human input
            approval = input().strip().lower()
            
            if approval != 'yes':
                self.log_rejection(action, proposal)
                return {
                    'status': 'rejected',
                    'action': action.name,
                    'reason': 'Human declined approval'
                }
        
        # Execute (approved or low-risk)
        result = self.execute_action(action)
        self.log_execution(action, result)
        
        return result
    
    def generate_proposal(self, action):
        """Detailed proposal for human review."""
        return f"""
ACTION: {action.name}
DESCRIPTION: {action.description}

ESTIMATED IMPACT:
- Budget: ${action.estimated_cost:,.2f}
- Timeline: {action.estimated_days} days
- Risk: {self.calculate_risk(action):.2%}
- Reversible: {'Yes' if action.reversible else 'No'}

REASONING:
{action.reasoning}

ALTERNATIVES CONSIDERED:
{chr(10).join(f"- {alt}" for alt in action.alternatives)}

RECOMMENDATION: {'APPROVE' if self.calculate_risk(action) < 0.3 else 'REVIEW CAREFULLY'}
"""
```

### WHEN TO USE:
- Budget allocation decisions
- Major architectural changes
- Research direction pivots
- Resource commitments
- Publishing/public statements

### EXAMPLE SCENARIOS:

```python
# Scenario 1: Low-risk (auto-approved)
action = Action(
    name="Run literature search on graphene",
    estimated_cost=0,        # Free API
    estimated_days=0.1,      # 2 hours
    reversible=True,         # Can re-run
    reasoning="Standard research task"
)
# → Executes automatically (risk: 0.05)

# Scenario 2: High-risk (requires approval)
action = Action(
    name="Commit to 6-month graphene fabrication partnership",
    estimated_cost=50000,    # $50K
    estimated_days=180,      # 6 months
    reversible=False,        # Contract commitment
    reasoning="Critical for MVP but major resource commitment"
)
# → Stops for human approval (risk: 0.82)

# Scenario 3: Medium-risk (threshold dependent)
action = Action(
    name="Redesign nano-chip architecture (switch from memristors to p-bits)",
    estimated_cost=0,        # Internal work
    estimated_days=14,       # 2 weeks
    reversible=True,         # Can revert design
    reasoning="Extropic thermodynamic computing validates p-bit approach"
)
# → Requires approval if threshold='high' (risk: 0.29)
```

═══════════════════════════════════════════════════════════════════════════════
## 🎯 PATTERN SELECTION GUIDE
═══════════════════════════════════════════════════════════════════════════════

```
USE CASE                              → RECOMMENDED PATTERN
─────────────────────────────────────────────────────────────────────────────
Multi-domain task (quantum+thermo)    → Supervisor (Chief Scientist)
Sequential research steps              → Chained Pipeline
Fast literature review                 → Parallel Execution
Budget/timeline decisions              → Human-in-the-Loop
Complex synthesis                      → Supervisor + Chained
Speed critical + independent tasks     → Parallel Execution
Unknown domain classification          → Supervisor (routes dynamically)
High-stakes irreversible action        → Human-in-the-Loop
Multi-step with growing context        → Chained Pipeline

COMBINATIONS (powerful!):
- Supervisor + Parallel: Chief delegates to parallel teams
- Chained + Human-in-Loop: Pipeline stops for approvals
- Supervisor + Chained: Specialist runs multi-step analysis
```

═══════════════════════════════════════════════════════════════════════════════
## 🔧 SHARED INFRASTRUCTURE (All Patterns)
═══════════════════════════════════════════════════════════════════════════════

### Knowledge Graph State (Replaces n8n Memory):

```python
class SharedKnowledgeGraph:
    """
    Shared state for all agents.
    Adapted from n8n Simple Memory node.
    """
    def __init__(self):
        self.facts = []
        self.agent_states = {}
        self.execution_history = []
    
    def add_facts(self, facts, agent_id=None):
        """Agent contributes knowledge."""
        self.facts.extend(facts)
        if agent_id:
            self.agent_states[agent_id] = {
                'last_update': datetime.now(),
                'facts_contributed': len(facts)
            }
    
    def query(self, question):
        """
        Knowledge graph reasoning.
        Uses Chain-of-Thought over accumulated facts.
        """
        relevant_facts = self.find_relevant(question)
        reasoning_chain = self.chain_of_thought(question, relevant_facts)
        return reasoning_chain
    
    def deduplicate(self, items, by='id'):
        """Remove duplicate findings."""
        seen = set()
        unique = []
        for item in items:
            key = getattr(item, by)
            if key not in seen:
                seen.add(key)
                unique.append(item)
        return unique
```

### Error Handling (Robust Agents):

```python
class RobustAgentMixin:
    """
    Error handling adapted from n8n fallback paths.
    """
    def process_with_fallback(self, task):
        """Primary → Fallback → Escalate pattern."""
        try:
            return self.primary_method(task)
        except RecoverableError as e:
            logger.warning(f"Primary failed: {e}, trying fallback")
            return self.fallback_method(task)
        except CriticalError as e:
            logger.error(f"Critical failure: {e}")
            return self.escalate_to_human(task, error=e)
    
    def fallback_method(self, task):
        """Alternative approach when primary fails."""
        raise NotImplementedError("Subclass must implement fallback")
    
    def escalate_to_human(self, task, error):
        """Critical errors require human intervention."""
        return {
            'status': 'escalated',
            'task': task,
            'error': str(error),
            'requires_human': True
        }
```

═══════════════════════════════════════════════════════════════════════════════
## ✅ IMPLEMENTATION TIMELINE (49-Day Context)
═══════════════════════════════════════════════════════════════════════════════

```
WEEK 1:
☐ Implement Supervisor (Chief Scientist)
☐ Test routing logic
☐ 2-3 specialist agents
→ FUNCTIONAL multi-agent coordination! ✅

WEEK 2:
☐ Implement Chained Pipeline (research!)
☐ 4 agents: Literature → Theory → Experiment → Validation
☐ Test on nano-chips question
→ AUTOMATED research pipeline! ✅

WEEK 3:
☐ Add Parallel Execution (async!)
☐ Multi-source literature search
☐ Benchmark speedup (should see 3-4×)
→ FAST research capability! ✅

WEEK 4-7:
☐ Human-in-the-Loop for critical decisions
☐ Refine patterns based on usage
☐ FOCUS: Nano-chips MVP development! 🔥

TOTAL IMPLEMENTATION: 3 weeks
BENEFIT: Proven patterns, NO platform overhead
COST: ~600 lines Python total
```

═══════════════════════════════════════════════════════════════════════════════
## 🎓 KEY LESSONS FROM n8n/Google
═══════════════════════════════════════════════════════════════════════════════

```
WHAT THEY GOT RIGHT (patterns!):
✅ Clear separation of concerns (specialists!)
✅ Supervisor coordinates, doesn't execute
✅ Chained reasoning accumulates context
✅ Parallel execution for independent tasks
✅ Human governance for high-stakes
✅ Shared state/memory critical
✅ Error handling with fallbacks

WHAT WE SKIP (platform overhead!):
❌ Visual workflow builders (code-first!)
❌ LLM orchestration frameworks (NON-LLM!)
❌ No-code tooling (technical team!)
❌ External dependencies (asset-light!)
❌ Platform setup time (49-day deadline!)

ADAPTATION PHILOSOPHY:
"Steal the patterns, skip the platform.
 Proven architecture, direct implementation.
 Code beats clicks for technical teams."
```

═══════════════════════════════════════════════════════════════════════════════

**METAКОГНИТИВНЫЙ ВЫВОД:**  
**4 PATTERNS = PROVEN ORCHESTRATION** (n8n/Google validated!)  
**NON-LLM ADAPTATION = DIRECT, FAST** (no LangChain overhead!)  
**3-WEEK IMPLEMENTATION** vs **5+ weeks platform setup!**  
**CODE-FIRST = RIGHT CHOICE** для technical research team!

═══════════════════════════════════════════════════════════════════════════════
