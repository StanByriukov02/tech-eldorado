# ELON'S ALGORITHM - 5-STEP OPTIMIZATION PROTOCOL

**TYPE:** Process Optimization Framework (ACTIVE!)
**SOURCE:** Elon Musk (validated across Tesla, SpaceX, Neuralink!)
**TIER:** S (Industry-proven!)
**SCOPE:** ALL processes, systems, workflows

═══════════════════════════════════════════════════════════════════════════════
## 🎯 WHEN TO USE (TRIGGERS!)
═══════════════════════════════════════════════════════════════════════════════

**MANDATORY TRIGGERS:**
✅ New process design
✅ System bottleneck identified
✅ Workflow inefficiency
✅ Before adding complexity
✅ Cost reduction needed

**WHO USES:**
- Engineers (system design!)
- Process optimizers (workflow improvement!)
- Architects (infrastructure planning!)
- ALL team members (daily decisions!)

**INTEGRATION:**
- Applied to EVERY new process
- Part of continuous improvement
- Combined with AlphaEvolve for research

═══════════════════════════════════════════════════════════════════════════════
## 🔥 THE 5 STEPS (STRICT ORDER!)
═══════════════════════════════════════════════════════════════════════════════

### STEP 1: Make Requirements Less Dumb

**CRITICAL:** Requirements are ALWAYS somewhat dumb!
**Originated by:** Smart people, but context changed

**Questions:**
```
1. Who set this requirement?
2. When was it set? (context changed?)
3. What's the REAL goal? (vs stated requirement)
4. Can we achieve goal differently?
```

**Example:**
```
Requirement: "Agent must use 10 reasoning steps"
Less dumb: "Agent must achieve 95% accuracy"
Why better: Allows 3 steps if accurate, 20 if needed!
```

**NEVER SKIP THIS!** Even if "someone smart" set requirement!

---

### STEP 2: Delete Part/Process

**CRITICAL:** If not adding back 10%, deleting too little!

**Rule:**
```
Delete FIRST, optimize LATER!
Don't optimize thing that shouldn't exist!
```

**Questions:**
```
1. What happens if we DELETE this entirely?
2. Can we achieve goal without it?
3. Is this legacy/historical cruft?
4. Adding value OR just tradition?
```

**Example:**
```
Process: "Manual code review for every change"
Delete: Automated checks + spot reviews
Result: 80% time saved, quality maintained!
```

**Guideline:** If haven't added back 10% of deleted, TOO CONSERVATIVE!

---

### STEP 3: Simplify/Optimize

**CRITICAL:** ONLY after deleting unnecessary!

**Common mistake:** Optimize before deleting!
**Result:** Perfectly optimized unnecessary process!

**Questions:**
```
1. Can we combine steps?
2. Remove redundancy?
3. Streamline flow?
4. Reduce complexity?
```

**Example:**
```
Before: Parse → Validate → Transform → Validate → Store
After: Parse → Validate → Transform&Store (combined!)
```

**Rule:** Simple > Complex, ALWAYS!

---

### STEP 4: Accelerate Cycle Time

**CRITICAL:** Moving fast smoothly > slow perfection!

**Questions:**
```
1. What's the bottleneck?
2. How to iterate faster?
3. Reduce waiting time?
4. Parallel execution?
```

**Example:**
```
Before: Sequential 5-day research cycle
After: Parallel 1-day with faster tools
Result: 5× faster iteration!
```

**Danger:** Accelerating broken process makes worse!
**That's why:** Delete → Simplify → THEN accelerate!

---

### STEP 5: Automate

**CRITICAL:** LAST step, not first!

**Why last:**
```
Automating unnecessary = waste!
Automating complex = brittle!
Automating slow = expensive!
```

**Only automate after:**
✅ Requirements clear (Step 1)
✅ Unnecessary deleted (Step 2)
✅ Process simplified (Step 3)
✅ Cycle time fast (Step 4)

**Questions:**
```
1. Is this repetitive enough?
2. High volume justifies cost?
3. Rules clear/stable?
4. Error handling defined?
```

**Example:**
```
After optimizing agent evaluation:
- Requirements clear ✅
- Removed manual checks ✅
- Simplified metrics ✅
- Fast execution ✅
NOW automate: Continuous testing pipeline!
```

═══════════════════════════════════════════════════════════════════════════════
## 📊 BEFORE/AFTER TEMPLATE
═══════════════════════════════════════════════════════════════════════════════

**Process:** [NAME]

**Step 1 - Less Dumb:**
```
Original requirement: ...
Less dumb version: ...
Why better: ...
```

**Step 2 - Delete:**
```
Deleted: ...
Justification: ...
Impact: ...
```

**Step 3 - Simplify:**
```
Complexity before: ...
Simplified to: ...
Reduction: ...
```

**Step 4 - Accelerate:**
```
Cycle time before: ...
Cycle time after: ...
Speedup: ...×
```

**Step 5 - Automate:**
```
Automated: ...
Manual remaining: ...
Why manual: ...
```

**Total Improvement:**
```
Time: ...× faster
Cost: ...% reduction
Quality: ... impact
```

═══════════════════════════════════════════════════════════════════════════════
## ✅ REAL EXAMPLES (Applied!)
═══════════════════════════════════════════════════════════════════════════════

### Example 1: AlphaEvolve Method

**Step 1:** "Use AI for math" → "Evolve CODE for solutions"
**Step 2:** DELETE direct parameter optimization
**Step 3:** Self-specifying parameters (simpler!)
**Step 4:** Prompt reuse (50× faster!)
**Step 5:** Automated evolution loop

**Result:** Tier S research method! ✅

---

### Example 2: Agent Optimization Stack

**Step 1:** "Optimize everything manually" → "Multi-objective automated"
**Step 2:** DELETE manual hyperparameter search
**Step 3:** BOHB combines Bayesian + HyperBand (simpler!)
**Step 4:** Multi-fidelity (30-50× faster!)
**Step 5:** Optuna automates entire pipeline

**Result:** 1000× faster architecture discovery! ✅

---

### Example 3: File Creation (Meta!)

**Step 1:** "Document everything" → "Only integrate into company"
**Step 2:** DELETE standalone analysis files
**Step 3:** Structured PROTOCOLS/ hierarchy
**Step 4:** Template reuse (10× faster!)
**Step 5:** Automated validation checks

**Result:** Optimized documentation itself! ✅

═══════════════════════════════════════════════════════════════════════════════
## 🚨 COMMON MISTAKES
═══════════════════════════════════════════════════════════════════════════════

**MISTAKE #1:** Skip Step 1
```
Problem: Optimizing wrong requirements!
Fix: ALWAYS question requirements first!
```

**MISTAKE #2:** Automate before Delete
```
Problem: Automated unnecessary process!
Fix: Follow order strictly!
```

**MISTAKE #3:** Optimize before Simplify
```
Problem: Complex optimized process!
Fix: Simplify FIRST, then optimize!
```

**MISTAKE #4:** Delete too conservatively
```
Problem: 2% deletion (should be 10-30%!)
Fix: Be aggressive! Add back if needed!
```

**MISTAKE #5:** Skip steps
```
Problem: Incomplete optimization!
Fix: ALL 5 steps, IN ORDER!
```

═══════════════════════════════════════════════════════════════════════════════
## 🎯 DECISION CHECKLIST
═══════════════════════════════════════════════════════════════════════════════

Before finalizing ANY process:

**☐ Step 1:** Requirements questioned? Less dumb version found?
**☐ Step 2:** Unnecessary parts deleted? (10%+ gone?)
**☐ Step 3:** Process simplified? Complexity reduced?
**☐ Step 4:** Cycle time accelerated? Bottlenecks removed?
**☐ Step 5:** Automation justified? (volume + stability + cost?)

**☐ Documentation:** Before/after comparison documented?
**☐ Metrics:** Quantified improvements?
**☐ Review:** Team validated changes?

**ALL boxes checked? → APPROVE!** ✅
**Any unchecked? → RETURN TO THAT STEP!** ❌

═══════════════════════════════════════════════════════════════════════════════
## 🔄 CONTINUOUS APPLICATION
═══════════════════════════════════════════════════════════════════════════════

**NOT one-time optimization!**

**Schedule:**
- Weekly: Review slow processes
- Monthly: Deep-dive bottlenecks
- Quarterly: Re-optimize everything
- Always: Question before adding

**Company culture:** Everyone applies Elon's Algorithm!

**Measure:** "You can only improve what you measure!"
