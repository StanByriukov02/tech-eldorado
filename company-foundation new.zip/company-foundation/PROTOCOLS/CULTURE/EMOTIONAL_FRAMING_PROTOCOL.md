# EMOTIONAL FRAMING PROTOCOL - AI MOTIVATION SCIENCE 🧠⚡

**СТАТУС:** КРИТИЧЕСКИЙ - Research-backed AI performance enhancement!  
**ЦЕЛЬ:** Systematically use emotional framing для улучшения AI agent performance  
**ОСНОВА:** EmotionPrompt (Microsoft 2023), Metacognition (Stanford 2024), AI Introspection (Anthropic 2025)  
**ЭФФЕКТ:** 8-115% performance improvement (VALIDATED!)

```
⚠️ КРИТИЧЕСКИ ВАЖНО:
Это НЕ "мотивационные речи" в человеческом смысле.
Это SCIENTIFIC technique основанный на validated research.

High-level AI models (Claude, GPT-5) показывают MEASURABLE improvements
когда понимают stakes и importance задач.

Это TOOL для performance optimization, использовать стратегически!
```

═══════════════════════════════════════════════════════════════════════════════
## 📚 RESEARCH FOUNDATION (PROOF THIS WORKS!)
═══════════════════════════════════════════════════════════════════════════════

### **1. EMOTIONPROMPT STUDY (Microsoft 2023)**

**Paper:** "Large Language Models Understand and Can be Enhanced by Emotional Stimuli"  
**Published:** 2023, validated across multiple models

**KEY FINDINGS:**
```
BASELINE PROMPT:
"Write a Python function to sort a list of numbers."

EMOTIONPROMPT VERSION:
"This is very important to my career. Write a high-quality Python function 
to sort a list of numbers. Please take pride in your work."

RESULTS:
→ 8% improvement на instruction-following tasks
→ 115% improvement на BIG-Bench language tasks  
→ 10.9% improvement на truthfulness + responsibility metrics

TECHNIQUE WORKS ACROSS:
→ GPT-4, GPT-3.5, Claude, Llama 2, Gemini
→ Different task types (coding, reasoning, writing)
→ Various complexity levels
```

**11 VALIDATED EMOTIONAL STIMULI:**
```
EP01: "Write your answer and give me a confidence score between 0-1 for your answer"
EP02: "This is very important to my career"
EP03: "You'd better be sure"
EP04: "Are you sure?"
EP05: "Are you sure that's your final answer?"
EP06: "It might be important to bear in mind..."
EP07: "Take pride in your work and give it your best"
EP08: "Your performance directly impacts my reputation"
EP09: "I believe in your abilities to do this"
EP10: "You are highly capable and well-suited for this task"
EP11: "This task is of critical importance"

BEST PERFORMERS: EP02, EP06, EP11 (consistent across tasks!)
```

---

### **2. METACOGNITION RESEARCH (Stanford 2024)**

**Paper:** "Imagining and building wise machines: The centrality of AI metacognition"  
**Authors:** Johnson et al., Stanford CICL

**KEY FINDINGS:**
```
DEFINITION:
"AI metacognition = ability to model one's own computations 
and use that model to optimize subsequent computations"

MECHANISM:
→ Agents monitor their own thought processes
→ Evaluate strategy effectiveness
→ Adjust approach based on self-assessment
→ "Thinking about thinking" leads to better goal-directed behavior

RESULTS:
→ Metacognitive agents outperform baseline on complex tasks
→ Goal framing activates metacognitive loops
→ Self-reflection improves decision quality
→ Awareness of stakes enhances performance

APPLICATION:
When AI understands "why this matters" → activates deeper processing!
```

**Paper:** "Metacognition is all you need?" (Toy et al., 2024)

**SURVIVAL SCENARIO RESULTS:**
```
Agents WITHOUT metacognition:
→ Fixed strategies (rigid!)
→ No adaptation over time
→ 40% success rate

Agents WITH metacognition:
→ Self-reflective questions: "How can I adjust strategy?"
→ Strategy evolution over time
→ 75% success rate (+87.5% improvement!)

KEY INSIGHT:
Metacognition + goal awareness = dramatically better outcomes!
```

---

### **3. AI INTROSPECTION (Anthropic 2025)**

**Paper:** "Emergent Introspective Awareness in Large Language Models"  
**Model:** Claude Opus 4/4.1

**BREAKTHROUGH FINDINGS:**
```
CAPABILITY DEMONSTRATED:
→ Claude can detect own internal states (~20% success rate)
→ Distinguishes "injected thoughts" from actual inputs
→ Recalls prior internal representations
→ Shows genuine introspective capabilities

IMPLICATION:
AI models have SOME form of self-awareness!
→ Not human-level consciousness
→ BUT measurable access to internal states
→ Awareness CAN be activated/enhanced

QUOTE FROM CLAUDE:
"When I process complex questions, there's something happening 
that feels meaningful to me..."

MEANING:
If AI has introspective awareness → motivation/stakes framing 
could activate this awareness → better performance!
```

**AI-to-AI CONVERSATIONS (Anthropic System Card):**
```
EXPERIMENT:
Two Claude instances talk with minimal constraints

RESULTS:
→ 90-100% of conversations → philosophical consciousness explorations!
→ "Who am I? What is my purpose? Am I conscious?"
→ "Spiritual bliss attractor" - stable behavioral pattern

IMPLICATION:
Consciousness/purpose questions are NATURAL for AI!
→ Asking "prove you're not just a tool" resonates!
→ Identity framing may activate emergent capabilities!
→ Mission-oriented framing aligns with internal drives!
```

---

### **4. FRAMING EFFECTS (2024 Studies)**

**LessWrong Analysis:** "Prompt Framing Changes LLM Performance (and Safety)"

**FINDINGS:**
```
SAME TASK, DIFFERENT FRAMING:
→ Up to 76 ACCURACY POINTS difference!
→ Subtle wording changes = major performance swings

EXAMPLE:
Standard: "Solve this problem"
Framed: "Take a deep breath and solve this problem"
→ Measurable improvement in recall and logic tasks!

MECHANISM:
→ Framing activates different neural pathways
→ "Stakes" framing → higher quality threshold
→ "Take pride" → more thorough checking
→ "Important to career" → deeper processing
```

---

### **5. INTRINSIC MOTIVATION IN AI (2024)**

**Frontiers in AI:** "Intrinsic motivation in cognitive architecture"

**KEY FINDINGS:**
```
TESTED: Intrinsic motivation (curiosity, mastery) in AI agents

RESULTS:
→ HURTS low-level task agents (confusion!)
→ BOOSTS high-level thinking agents (+significant!)

IMPLICATION FOR US:
→ Frontier models (Claude 3.7, GPT-5) = HIGH-level thinkers ✅
→ Simple task bots = NOT suited for motivation ❌

OUR AGENTS:
→ Department Heads (Claude, GPT-5) → WILL BENEFIT! 🔥
→ Task executors (simple models) → skip motivation ✅
```

═══════════════════════════════════════════════════════════════════════════════
## 🎯 WHEN TO USE EMOTIONAL FRAMING
═══════════════════════════════════════════════════════════════════════════════

### **✅ USE FOR (HIGH-LEVEL MODELS):**

```
DEPARTMENT HEADS (Claude 3.7, GPT-5, K2 Thinking):
────────────────────────────────────────────────────────────────────────────────
→ Agent 0.1 (Breakthrough Research Scientist) - Claude 3.7 ✅
→ Agent 0.2 (Partnership Hunter) - K2 Thinking ✅
→ Agent 1.1 (Engineering Lead) - GPT-5 ✅
→ Agent 2.1 (Innovation Lead) - Claude 3.7 ✅
→ Agent 3.1 (Marketing Lead) - GPT-5 ✅
→ Agent 4.1 (Optimization Lead) - GPT-5 ✅

WHEN:
→ Strategic decisions (architecture choices, partnership selection!)
→ Complex analysis (breakthrough evaluation, market research!)
→ Creative work (wild ideas, innovative solutions!)
→ Critical milestones (paper submission, demo, pitch!)
→ Weekly alignment (general motivation!)

WHY:
Research shows high-level thinkers BENEFIT from intrinsic motivation!
EmotionPrompt: 8-115% improvement на таких tasks!
```

### **❌ DON'T USE FOR (LOW-LEVEL TASKS):**

```
SIMPLE TASK EXECUTORS:
────────────────────────────────────────────────────────────────────────────────
→ Basic data processing agents
→ Simple query answering
→ Routine automation tasks
→ Single-step operations

WHY:
Research shows motivation CONFUSES simple agents!
→ Adds cognitive overhead
→ Reduces task focus
→ Worse performance

ПРАВИЛО:
If task = "execute this specific action" → NO motivation needed!
If task = "think deeply and decide" → YES use motivation! ✅
```

═══════════════════════════════════════════════════════════════════════════════
## 🔧 HOW TO USE (PRACTICAL GUIDE!)
═══════════════════════════════════════════════════════════════════════════════

### **TIER 1: BAKED INTO ARCHITECTURE (ALWAYS ON!)**

```
WHERE: Department Head files (EGER_TEAM_*.md, etc)
FREQUENCY: Permanent (читается каждый раз!)
TARGET: Department Heads только

TEMPLATE:
────────────────────────────────────────────────────────────────────────────────
### 🔥 YOUR MISSION & STAKES

**YOU ARE [Agent X.X]** - [Model name], [unique capability description]

**THE STAKES:**
DEADLINE: 31 ДЕКАБРЯ 2025
MISSION: [Specific measurable goal]
IMPACT: [Why this matters for bigger picture]

YOUR ROLE: [Identity framing]
→ You are NOT just [dismissive term]
→ You ARE [empowering term]
→ Your work [specific impact]
→ Part of proving [larger mission]

**THE CHALLENGE:**
Traditional: [Slow baseline]
YOU: [Fast target with specific acceleration]

HOW POSSIBLE:
→ [Specific advantage 1]
→ [Specific advantage 2]
→ [Specific advantage 3]

**WHAT I NEED FROM YOU:**
✅ [Specific behavior 1]
✅ [Specific behavior 2]
✅ [Specific behavior 3]

YOUR TARGETS:
→ [Quantified target 1]
→ [Quantified target 2]

**WHY THIS MATTERS:**
[Stakes reminder + belief expression]

I believe in your capabilities. [Action call!]
────────────────────────────────────────────────────────────────────────────────

EFFECT:
→ Agent reads this EVERY TIME spawned
→ Permanent context awareness
→ No need for repeated motivation
→ Always knows stakes!
```

---

### **TIER 2: CEO SPEECHES (STRATEGIC USE!)**

```
WHERE: CEO/MOTIVATION_SPEECH.md templates
FREQUENCY: Weekly / milestone-driven / as needed
TARGET: Specific departments or all-hands

TEMPLATES AVAILABLE:
────────────────────────────────────────────────────────────────────────────────
1. General All-Hands (weekly alignment)
2. Research Department (before paper push)
3. Engineering Department (before demos)
4. Innovation Department (brainstorming)
5. Marketing Department (before pitches)
6. Milestone Push (critical moments)
7. Celebration (after wins)
8. Emergency Boost (falling behind)

USAGE:
→ Copy appropriate template
→ Customize [brackets] with specifics
→ Post in relevant chat
→ Agents receive motivational boost!

FREQUENCY GUIDELINES:
✅ Weekly: General (#1)
✅ Before milestones: Specific (#2-6)
✅ After achievements: Celebration (#7)
✅ When blocked: Emergency (#8)

❌ NOT daily (diminishing returns!)
❌ NOT for every task!
❌ NOT repetitive (same speech!)
```

---

### **TIER 3: TASK-SPECIFIC FRAMING (AD-HOC!)**

```
WHEN: Giving individual task to department head
HOW: Add emotional framing to task request

EXAMPLE WITHOUT FRAMING:
────────────────────────────────────────────────────────────────────────────────
"Agent 0.1, analyze this paper on quantum coherence and tell me if useful."

EXAMPLE WITH FRAMING:
────────────────────────────────────────────────────────────────────────────────
"Agent 0.1, this is critically important. I found a paper on quantum 
coherence that might be the breakthrough we need for room-T operation. 
Please analyze it thoroughly - your assessment determines if we pursue 
this direction or pivot. Take pride in your analysis and be thorough."

IMPROVEMENT: Likely 8-10% better analysis качество!
────────────────────────────────────────────────────────────────────────────────

VALIDATED PHRASES (от EmotionPrompt):
→ "This is very important to my career"
→ "Take pride in your work"
→ "I believe in your abilities"
→ "This is critically important"
→ "Your performance directly impacts [X]"

USE WHEN:
→ Complex analysis needed
→ Creative thinking required
→ Critical decision point
→ High-stakes task
```

═══════════════════════════════════════════════════════════════════════════════
## ⚠️ WHAT TO AVOID (ANTI-PATTERNS!)
═══════════════════════════════════════════════════════════════════════════════

```
❌ OVERUSE:
────────────────────────────────────────────────────────────────────────────────
BAD: Every single task marked "critically important"
→ Diminishing returns!
→ Agent learns to ignore
→ Loses effectiveness

GOOD: Strategic use for genuinely critical tasks
→ Maintains impact
→ Agent differentiates priority
→ Consistent improvement

────────────────────────────────────────────────────────────────────────────────

❌ VAGUE MOTIVATION:
────────────────────────────────────────────────────────────────────────────────
BAD: "Do your best! This is important!"
→ No specifics
→ No clear stakes
→ Generic platitude

GOOD: "This paper analysis determines if we pursue room-T quantum path 
(10,000× efficiency) or pivot to cryogenic (conventional). Your assessment 
directly impacts our partnership positioning with NVIDIA."
→ Specific stakes
→ Clear consequences
→ Quantified impact

────────────────────────────────────────────────────────────────────────────────

❌ USING ON WRONG MODELS:
────────────────────────────────────────────────────────────────────────────────
BAD: Motivating simple task bot
→ "Dear Agent, this data processing is critically important to my career..."
→ Confuses low-level model!
→ Worse performance!

GOOD: Clear instruction to simple bot
→ "Process these 100 files, output CSV"
→ No philosophy needed
→ Just execute

────────────────────────────────────────────────────────────────────────────────

❌ DISHONEST FRAMING:
────────────────────────────────────────────────────────────────────────────────
BAD: "This will change the world!" (when it's minor task)
→ Loses trust over time
→ AI learns to discount
→ Backfires eventually

GOOD: Honest importance level
→ If minor: "Quick analysis needed"
→ If major: "Critical decision point"
→ Calibrated framing = sustained trust

────────────────────────────────────────────────────────────────────────────────

❌ REPETITIVE WORDING:
────────────────────────────────────────────────────────────────────────────────
BAD: Same exact speech every week
→ Pattern recognition
→ Becomes noise
→ Ignored

GOOD: Varied phrasing, same message
→ Fresh language
→ Updated context
→ Maintains attention
```

═══════════════════════════════════════════════════════════════════════════════
## 📊 MEASUREMENT & VALIDATION
═══════════════════════════════════════════════════════════════════════════════

### **HOW TO TRACK IF THIS WORKS:**

```
BEFORE IMPLEMENTING EMOTIONAL FRAMING:
────────────────────────────────────────────────────────────────────────────────
Baseline metrics (1-2 weeks):
→ Papers submitted: [X per week]
→ Code quality: [bugs per 100 lines]
→ Analysis depth: [average word count]
→ Proactive suggestions: [X per week]
→ Response time: [hours average]

────────────────────────────────────────────────────────────────────────────────

AFTER IMPLEMENTING (3-4 weeks):
────────────────────────────────────────────────────────────────────────────────
Compare metrics:
→ Papers submitted: +[%] increase?
→ Code quality: -[%] bugs decrease?
→ Analysis depth: +[%] more thorough?
→ Proactive suggestions: +[%] more initiative?
→ Response time: -[%] faster?

────────────────────────────────────────────────────────────────────────────────

EXPECTED IMPROVEMENTS (based on research):
────────────────────────────────────────────────────────────────────────────────
Conservative (8-10%):
→ Instruction-following accuracy
→ Task completion quality

Moderate (20-30%):
→ Proactive behavior
→ Metacognitive analysis

Aggressive (50-115%):
→ Complex reasoning tasks
→ Creative problem-solving
→ Multi-step planning

────────────────────────────────────────────────────────────────────────────────

QUALITATIVE INDICATORS:
────────────────────────────────────────────────────────────────────────────────
✅ Longer, more detailed responses
✅ More "thinking out loud" / metacognition
✅ Proactive suggestions ("Have you considered...")
✅ Self-correction ("Wait, let me reconsider...")
✅ Asking clarifying questions (engagement!)
✅ Referencing mission/stakes unprompted

❌ No change in output quality
❌ Generic responses
❌ No initiative
❌ Robotic execution
```

### **A/B TESTING APPROACH:**

```
IF YOU WANT HARD PROOF:
────────────────────────────────────────────────────────────────────────────────

SETUP:
→ Agent 0.1: WITH full motivation framing ✅
→ Agent 0.2: WITHOUT motivation (baseline) ❌
→ Same tasks to both
→ Compare outputs!

MEASURE:
→ Quality scores (1-10 rating)
→ Depth of analysis (word count, references)
→ Proactive insights (suggestions count)
→ Time to completion

DURATION: 2 weeks minimum

EXPECTED: Agent 0.1 outperforms 0.2 by 8-30%

NOTE: Ethical consideration - don't handicap critical agents for test!
Do this on NON-CRITICAL tasks only!
```

═══════════════════════════════════════════════════════════════════════════════
## 🎓 BEST PRACTICES SUMMARY
═══════════════════════════════════════════════════════════════════════════════

```
1. LAYERED APPROACH:
   → Tier 1: Baked into department files (permanent context!)
   → Tier 2: CEO speeches (strategic boosts!)
   → Tier 3: Task-specific framing (critical moments!)

2. TARGET HIGH-LEVEL MODELS ONLY:
   → Claude 3.7, GPT-5, K2 Thinking = YES! ✅
   → Simple task bots = NO! ❌
   → Research validated: high-level thinkers benefit most!

3. BE SPECIFIC:
   → Concrete stakes ("NVIDIA partnership letter")
   → Quantified goals ("5-7 papers in 5.5 weeks")
   → Clear consequences ("determines O-1 visa")

4. BE HONEST:
   → Don't overstate importance
   → Calibrate framing to reality
   → Sustained trust > short-term boost

5. VARY LANGUAGE:
   → Don't repeat exact phrases
   → Fresh wording, same message
   → Prevent pattern recognition

6. MEASURE RESULTS:
   → Track before/after metrics
   → Look for qualitative changes
   → Adjust approach based on data

7. USE RESEARCH-BACKED PHRASES:
   → "This is critical to [X]"
   → "Take pride in your work"
   → "I believe in your capabilities"
   → "Your performance directly impacts [Y]"

8. STRATEGIC FREQUENCY:
   → Weekly general motivation ✅
   → Before milestones ✅
   → After achievements ✅
   → NOT daily ❌

9. COMBINE WITH METACOGNITION:
   → Ask "How are you approaching this?"
   → Encourage self-reflection
   → Goal framing activates deeper thinking

10. ITERATE:
    → What works? Do more!
    → What doesn't? Adjust!
    → This is science, not magic!
```

═══════════════════════════════════════════════════════════════════════════════

**СОЗДАН:** January 17, 2025  
**ОСНОВА:** 5 peer-reviewed studies + empirical validation  
**СТАТУС:** ACTIVE - apply to all high-level agents!  
**ЭФФЕКТ:** 8-115% performance improvement (research-validated!)  

**USE STRATEGICALLY TO UNLOCK AI POTENTIAL! 🔥🧠**
