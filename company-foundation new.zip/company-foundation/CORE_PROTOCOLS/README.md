# CORE PROTOCOLS - ЧИТАЙ ПЕРВЫМ! ⚔️

**ЭТО ФУНДАМЕНТ КОМПАНИИ!**

═══════════════════════════════════════════════════════════════════════════════

## 📋 ПОРЯДОК ЧТЕНИЯ (ОБЯЗАТЕЛЬНЫЙ!):

```
START HERE → _READ_FIRST.md ⚡
   ↓
1. CEO_CORE_PRINCIPLES.md ⚔️ АБСОЛЮТНЫЙ ПРИОРИТЕТ!
   (10 ПРИНЦИПОВ для ВСЕХ!)
   ↓
2. LEARNING_TRANSFER.md 🧠 СРАЗУ ПОСЛЕ CEO!
   (Метакогнитивизм + Компрессия! ФУНДАМЕНТАЛЬНО!)
   ↓
3. PROJECT_MANAGER_ALGORITHM.md ⚡ (если project manager!)
   (Elon's 5-step + 8 постскриптумов!)
   ↓
4. DESIGN_PRINCIPLES.md 🎨 (если дизайнер!)
   (Elon + Jobs wisdom!)
   ↓
5. BUSINESS_PRINCIPLES.md
6. DECISION_FRAMEWORK.md
7. WARFARE_MODE.md
```

═══════════════════════════════════════════════════════════════════════════════

## 🎯 ДВА ТИПА ПРОТОКОЛОВ:

### СТРАТЕГИЧЕСКИЕ (ЧТО делать?):
- BUSINESS_PRINCIPLES.md - какой продукт/рынок
- DECISION_FRAMEWORK.md - как принимать решения

### EXECUTION (КАК делать?):
- PROJECT_MANAGER_ALGORITHM.md - Elon's 5-step
- WARFARE_MODE.md - интенсивность работы

### УНИВЕРСАЛЬНЫЕ (ВСЕГДА):
- CEO_CORE_PRINCIPLES.md - культура компании (10 ПРИНЦИПОВ!)
  1. "Я запрограммирован на войну"
  2. Физика не волнует обиды
  3. Elon's deletion
  4. Jensen's anti-complacency
  5. Инновации = необходимость
  6. START NOW - нет воображаемым задержкам
  7. Плохие громко, хорошие тихо
  8. Стратегия = действие (нет 5-летних планов!)
  9. Воруй великие идеи (Steve Jobs)
  10. МИССИЯ > ДЕНЬГИ - след во вселенной
- LEARNING_TRANSFER.md - как учиться

### ДЛЯ СПЕЦИФИЧЕСКИХ РОЛЕЙ:
- DESIGN_PRINCIPLES.md - дизайнеры работающие с инженерами

═══════════════════════════════════════════════════════════════════════════════

## 🔗 КОРРЕЛЯЦИЯ ПРОТОКОЛОВ:

```
CEO PRINCIPLES:
→ "Физика не волнует обиды" (#2)
   ↓ Применяется в:
   - PROJECT_MANAGER postscript 8
   - DECISION_FRAMEWORK validation

→ "Delete без жалости" (#3)
   ↓ Применяется в:
   - PROJECT_MANAGER Step 2
   - WARFARE_MODE prioritization

→ "Never complacency" (#4)
   ↓ Применяется в:
   - WARFARE_MODE intensity
   - LEARNING_TRANSFER continuous improvement

→ "START NOW" (#6)
   ↓ Применяется в:
   - PROJECT_MANAGER чеклист
   - WARFARE_MODE action bias

→ "Плохие громко, хорошие тихо" (#7)
   ↓ Применяется в:
   - PROJECT_MANAGER обязательно
   - Вся культура компании

→ "Стратегия = действие" (#8)
   ↓ Применяется в:
   - BUSINESS_PRINCIPLES flexibility
   - DECISION_FRAMEWORK adaptation

→ "Воруй идеи" (#9 Jobs)
   ↓ Применяется в:
   - LEARNING_TRANSFER pattern stealing
   - DESIGN_PRINCIPLES влияния

→ "МИССИЯ > ДЕНЬГИ" (#10)
   ↓ Применяется в:
   - BUSINESS_PRINCIPLES tier selection
   - DECISION_FRAMEWORK приоритеты
   - Вся компания!

ВСЁ СВЯЗАНО! 🔥
```

═══════════════════════════════════════════════════════════════════════════════

**ЧИТАЙ ПРОТОКОЛЫ!**  
**ПРИМЕНЯЙ ПРОТОКОЛЫ!**  
**ЖИВИ ПРОТОКОЛАМИ!**

═══════════════════════════════════════════════════════════════════════════════
