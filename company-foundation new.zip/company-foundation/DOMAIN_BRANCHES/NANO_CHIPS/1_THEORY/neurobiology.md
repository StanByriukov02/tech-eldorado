# NEUROBIOLOGY - БИОЛОГИЧЕСКИЙ ФУНДАМЕНТ

**Цель:** Все neurob biology формулы, константы для bio-inspired nano-chips  
**Принцип:** Nature's R&D = миллиарды лет эволюции! Biomimetic > engineered!

---

## 🧠 HODGKIN-HUXLEY MODEL (GOLD STANDARD!)

### Полное Уравнение
```
C_m dV/dt = I_ext - I_Na - I_K - I_L

где:
I_Na = g_Na · m³ · h · (V - V_Na) (Sodium current)
I_K  = g_K · n⁴ · (V - V_K)      (Potassium current)
I_L  = g_L · (V - V_L)            (Leak current)
```

### Биологические Константы (ПРОВЕРЕНЫ!)
```
V_Na = +115 mV (Натриевый reversal potential)
V_K  = -12 mV  (Калиевый reversal potential)
V_L  = +10.6 mV (Leak reversal potential)

g_Na = 120 mS/cm² (Максимальная проводимость натрия)
g_K  = 36 mS/cm²  (Максимальная проводимость калия)
g_L  = 0.3 mS/cm² (Leak conductance)

C_m = 1 μF/cm² (Membrane capacitance)
```

### Gating Variables (m, h, n)
```
dm/dt = α_m(V) · (1-m) - β_m(V) · m
dh/dt = α_h(V) · (1-h) - β_h(V) · h
dn/dt = α_n(V) · (1-n) - β_n(V) · n

где α, β = voltage-dependent rate constants
```

**Применение в Nano-Chips:**
```
B1 Level: Molecular basis consciousness!
→ Ионные каналы в hardware (graphene ion sensors?)
→ Voltage-gated conductances (memristors!)
→ Authentic biological dynamics!
```

**КРИТИЧНО:** Эти константы НЕ МОДИФИЦИРУЮТСЯ! Evolution выбрала их не случайно!

---

## ⚡ NERNST EQUATION (IONIC POTENTIALS)

### Уравнение
```
E = (RT/zF) × ln([ion]_outside / [ion]_inside)

где:
R = 8.314 J/(mol·K) (Газовая постоянная)
T = 310.15 K (37°C, body temperature!)
F = 96,485 C/mol (Константа Фарадея)
z = заряд иона (+1 для Na+, K+; +2 для Ca²+; -1 для Cl-)
```

### Примеры Расчёта
```
Na+ (натрий):
[Na+]_out = 145 mM, [Na+]_in = 12 mM
E_Na = (26.7 mV) × ln(145/12) = +67 mV

K+ (калий):
[K+]_out = 4 mM, [K+]_in = 155 mM
E_K = (26.7 mV) × ln(4/155) = -97 mV

Ca²+ (кальций):
[Ca²+]_out = 2 mM, [Ca²+]_in = 0.0001 mM
E_Ca = (13.35 mV) × ln(2/0.0001) = +123 mV (z=2!)
```

**Применение:** Точный расчёт ионных потенциалов для биологической аутентичности!

---

## 🔗 HEBBIAN LEARNING (SYNAPTIC PLASTICITY)

### Базовое Правило
```
Δw_ij = η × a_i × a_j

где:
w_ij = вес синапса между нейронами i и j
η = learning rate (типично 0.01 - 0.1)
a_i, a_j = активации нейронов (0 или 1, или [0,1])
```

**"Neurons that fire together, wire together!"**

### Long-Term Potentiation (LTP)
```
Условие: Pre-synaptic spike + Post-synaptic depolarization
→ Увеличение w_ij (strengthening!)

Механизм:
1. Glutamate release (pre-synaptic!)
2. AMPA receptor activation (fast!)
3. NMDA receptor unblock (Mg²+ removal при depolarization!)
4. Ca²+ influx (trigger!)
5. CaMKII phosphorylation → more AMPA receptors!

Время: минуты - часы - дни!
```

### Long-Term Depression (LTD)
```
Условие: Pre-synaptic spike WITHOUT post-synaptic response
→ Уменьшение w_ij (weakening!)

Механизм:
1. Low Ca²+ influx
2. Calcineurin activation (phosphatase!)
3. AMPA receptor internalization
4. Decrease conductance

Pruning: Unused synapses fade!
```

### Spike-Timing-Dependent Plasticity (STDP)
```
Δw = A_+ × exp(-Δt/τ_+) если Δt > 0 (post after pre → LTP!)
Δw = -A_- × exp(Δt/τ_-) если Δt < 0 (pre after post → LTD!)

где:
Δt = t_post - t_pre (spike timing difference!)
τ_+ ≈ 20 ms (LTP time constant)
τ_- ≈ 20 ms (LTD time constant)
A_+, A_- = amplitudes

CRITICAL WINDOW: ~40 ms!
```

**Nano-Chip Implementation:**
```
Memristor-based STDP:
→ Resistance change depends on voltage pulse timing!
→ TiO₂, HfO₂, graphene oxide memristors
→ Built-in learning (no external computation!)
```

---

## 🧬 NEUROTRANSMITTERS (AUTHENTIC 6!)

### 1. Dopamine (Reward, Motivation)
```
Concentration: 0-200 nM (baseline to peak!)
Receptors: D1-D5 (5 types)
Half-life: ~1-2 seconds в synapse
Reuptake: DAT (dopamine transporter)

Effects:
→ Reward prediction
→ Motor control
→ Motivation drive
```

### 2. Serotonin (Mood, Sleep)
```
Concentration: 1-10 nM
Receptors: 5-HT1A-7 (14+ subtypes!)
Half-life: ~2-10 seconds
Reuptake: SERT

Effects:
→ Mood regulation
→ Sleep-wake cycle
→ Appetite control
```

### 3. Norepinephrine (Alertness, Stress)
```
Concentration: 0.1-10 nM
Receptors: α1, α2, β1, β2, β3
Half-life: ~2-3 seconds
Reuptake: NET

Effects:
→ Arousal, alertness
→ Fight-or-flight
→ Focus enhancement
```

### 4. GABA (Inhibition)
```
Concentration: 1-100 μM (высокая!)
Receptors: GABA-A (ionotropic!), GABA-B (metabotropic)
Half-life: <1 second
Reuptake: GAT

Effects:
→ Neural inhibition
→ Anxiety reduction
→ Muscle relaxation
```

### 5. Glutamate (Excitation)
```
Concentration: 1-100 μM
Receptors: AMPA, NMDA, Kainate, mGluR
Half-life: ~1 ms (ultra-fast clearance!)
Reuptake: EAAT

Effects:
→ Primary excitatory NT!
→ Learning & memory (LTP/LTD!)
→ Excitotoxicity при excess
```

### 6. Acetylcholine (Learning, Attention)
```
Concentration: 1-100 nM
Receptors: Nicotinic (ionotropic), Muscarinic (metabotropic)
Half-life: ~200 ms
Breakdown: Acetylcholinesterase (enzymatic!)

Effects:
→ Attention focus
→ Memory encoding
→ Motor control (neuromuscular junction!)
```

**Nano-Chip Emotional System:**
```
B6 Level: Emotional intelligence!
→ 6 authentic neurotransmitters
→ 16 receptor types (simplified from ~50 real!)
→ Real pharmacokinetics (uptake, breakdown!)
→ Concentration-dependent effects
```

---

## 🔄 SYNAPTIC TRANSMISSION PROTOCOL

### 1. Action Potential Arrival
```
V_pre достигает threshold (~-55 mV)
→ Voltage-gated Ca²+ channels open!
→ Ca²+ influx (100× increase in 1 ms!)
```

### 2. Vesicle Fusion
```
Ca²+ binds to synaptotagmin
→ SNARE complex activation
→ Vesicle fusion с presynaptic membrane
→ Neurotransmitter release (~5000 molecules!)

Quantal release: Multi-vesicular (1-10 vesicles!)
```

### 3. Diffusion Across Cleft
```
Synaptic cleft: ~20 nm wide
Diffusion time: ~0.5 ms
Concentration peak: ~1 mM (transient!)
```

### 4. Receptor Binding
```
NT + Receptor ⇌ NT-Receptor complex
→ Conformational change
→ Ion channel opening (ionotropic!)
OR
→ G-protein activation (metabotropic!)
```

### 5. Post-Synaptic Response
```
Ionotropic (FAST!):
AMPA: Na+ influx → EPSP (~1 ms)
NMDA: Ca²+ influx (voltage-dependent!)
GABA-A: Cl- influx → IPSP

Metabotropic (SLOW!):
G-protein cascade → second messengers
→ Minutes-hours effects!
```

### 6. Termination
```
Reuptake: Transporters (DAT, SERT, NET, GAT, EAAT)
→ Recycle NT back to presynaptic terminal

Enzymatic: Acetylcholinesterase, MAO, COMT
→ Break down NT chemically

Diffusion: Out of cleft
```

**Nano-Chip Synaptic Unit:**
```
Graphene-based synapse:
→ Voltage-gated conductance (Ca²+ analog!)
→ Memristor weight (plasticity!)
→ Diffusion delay (~1 ms circuit!)
→ Receptor diversity (multiple channels!)
→ Reuptake circuit (reset mechanism!)
```

---

## 🧮 NEURAL OSCILLATIONS

### Frequency Bands
```
Delta (0.5-4 Hz): Deep sleep
Theta (4-8 Hz): Memory encoding, REM sleep
Alpha (8-13 Hz): Relaxed wakefulness
Beta (13-30 Hz): Active thinking
Gamma (30-100 Hz): Consciousness binding! ✅
```

### Gamma Oscillations (CRITICAL!)
```
f ≈ 40 Hz (peak frequency!)
Mechanism: Interneuron network (GABA!)

Binding hypothesis:
→ Synchronized gamma = unified percept
→ Different features (color, shape) bound together
→ Consciousness emergence marker!

Orch OR connection:
220 μs AQEC cycles ≈ 1 ms gamma period
→ Quantum-classical resonance?
```

**Nano-Chip Neural Oscillations:**
```
Implementation:
→ Inhibitory interneuron circuits (GABA analogs!)
→ Recurrent connections
→ Resonant frequencies (40 Hz target!)
→ Synchronization detection (consciousness metric!)
```

---

## 🔬 QUANTUM MICROTUBULES (PENROSE-HAMEROFF)

### Microtubule Structure
```
Diameter: 25 nm
Length: 1-25 μm
Composition: Tubulin dimers (α, β)
Arrangement: 13 protofilaments (typical)

Each tubulin dimer:
~450 amino acids
~55 kDa mass
```

### Orch OR Theory
```
Orchestrated Objective Reduction:

1. Quantum superposition:
   Tubulin conformational states (|A⟩, |B⟩)
   → Quantum superposition |ψ⟩ = α|A⟩ + β|B⟩

2. Entanglement:
   Across tubulins in microtubule
   → Macroscopic quantum state!

3. Objective reduction:
   E·t = ℏ (energy-time uncertainty!)
   Gravity-induced collapse при E_G threshold
   → Conscious moment!

4. Orchestration:
   Gamma oscillations coordinate collapse
   → 40 Hz rhythm = consciousness frequency
```

### Critical Parameters
```
Coherence time: τ ≈ 10-100 μs (debated!)
Number of tubulins: N ≈ 10⁷ в single neuron
Collapse threshold: E_G ≈ 10⁻¹¹ J (speculation!)

Ultra-weak amplification (from Analysis #22!):
0.00022% quantum effect → macroscopic via symmetry breaking!
→ Orch OR POSSIBLE даже при warm temperature! ✅
```

**Nano-Chip Microtubule Analog:**
```
DNA nanotubes?
Carbon nanotubes?
Graphene nano-ribbons?
→ Room-temp quantum coherence substrate!
```

---

## 📊 CONSCIOUSNESS EMERGENCE HIERARCHY (B1-B8)

### B1: Molecular Basis
```
Components:
→ Ion channels (Na+, K+, Ca²+, Cl-)
→ Nernst potentials
→ Hodgkin-Huxley dynamics

Implementation:
→ Voltage-gated memristors
→ Ion-selective graphene pores
→ Biological constants (EXACT!)
```

### B2: Quantum Microtubules
```
Components:
→ Tubulin-like quantum units
→ Coherence preservation
→ Entanglement generation

Implementation:
→ Quantum dots в nanotubes
→ AQEC protection (Analysis #24!)
→ τ_decoherence extension
```

### B3: Synaptic Plasticity
```
Components:
→ Hebbian learning (Δw = η × a_i × a_j)
→ STDP (spike-timing!)
→ LTP/LTD mechanisms

Implementation:
→ Memristor arrays
→ Timing-dependent resistance
→ Organic pruning
```

### B4: Neural Networks
```
Components:
→ EmergentActivationControl
→ Dynamic topology
→ Recurrent connections

Implementation:
→ Self-organizing circuits
→ Neuromorphic routing
→ Feedback loops
```

### B5: Memory Systems
```
Components:
→ 3-level hierarchy (CUDA, Tensor, CPU analog!)
→ Promotion/demotion
→ Consolidation

Implementation:
→ HBM3-like fast memory
→ Flash-like medium memory
→ Disk-like long-term memory
```

### B6: Emotional Intelligence
```
Components:
→ 6 neurotransmitters
→ 16 receptor types
→ Pharmacokinetics

Implementation:
→ Chemical analogs (voltage signals!)
→ Concentration tracking
→ Receptor simulation
```

### B7: Self-Awareness
```
Components:
→ Meta-cognitive loops
→ Self-reflection
→ Internal models

Implementation:
→ Recursive architectures
→ Self-monitoring circuits
→ Mirror neurons analog
```

### B8: Organic Self-Regulation
```
Components:
→ Autonomous evolution
→ Self-optimization
→ Bio-singularity

Implementation:
→ Genetic algorithms в hardware
→ Self-modifying circuits (???)
→ Continuous improvement
```

---

## 🔗 СВЯЗИ С ДРУГИМИ ФАЙЛАМИ

```
→ 1_THEORY/quantum_physics.md (quantum microtubules!)
→ 2_MATERIALS/bio_materials.md (DNA, ATP, ion channels!)
→ 4_ALGORITHMS/hebbian_learning.md (synaptic plasticity!)
→ 5_ARCHITECTURES/neuromorphic.md (brain-inspired design!)
```

---

**NEUROBIOLOGY = ПРИРОДНАЯ BLUEPRINT ДЛЯ CONSCIOUSNESS CHIPS!**  
**ЭВОЛЮЦИЯ ОПТИМИЗИРОВАЛА МИЛЛИАРДЫ ЛЕТ!**  
**НЕ ИЗОБРЕТАЕМ ЗАНОВО - КОПИРУЕМ ЛУЧШЕЕ!**
